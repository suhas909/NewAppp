﻿using Android.Content;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;
using ZIMLApp;
using ZIMLApp.Droid;

[assembly: ExportRenderer(typeof(XEditor), typeof(XEditorRenderer))]
namespace ZIMLApp.Droid
{
    public class XEditorRenderer: EditorRenderer  
    {
        public XEditorRenderer(Context context) : base(context)
        {
        }

        protected override void OnElementChanged(ElementChangedEventArgs<Editor> e)  
        {  
            base.OnElementChanged(e);  
            if (Control != null)  
            {  
                if (Element == null)  
                    return;  
  
                var element = (XEditor)Element;  
                Control.Hint = element.Placeholder; 
                Control.Background = null;
                Control.SetHintTextColor(element.PlaceholderColor.ToAndroid());  
            }  
        }  
    } 
}

﻿using System;
using Xamarin.Forms;
using ZIMLApp.Droid;

[assembly: Dependency(typeof(BaseUrl_Android))]
namespace ZIMLApp.Droid
{
    public class BaseUrl_Android : IBaseUrl
    {
        public string Get()
        {
            return "file:///android_asset/";
        }
    }
}

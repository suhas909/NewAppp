﻿using System;
using Xamarin.Forms;

namespace ZIMLApp
{
    public partial class BorderlessEntry : Entry
    {
        public BorderlessEntry()
        {
        }
    }
}

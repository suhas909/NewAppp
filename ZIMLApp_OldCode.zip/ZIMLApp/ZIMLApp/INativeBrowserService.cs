﻿using System;
namespace ZIMLApp
{
    public interface INativeBrowserService
    {
        void LaunchNativeEmbeddedBrowser(string url);
    }
}

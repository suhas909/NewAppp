﻿using System;
namespace ZIMLApp
{
    public interface IBaseUrl
    {
         string Get();
    }
}

﻿using System;
using Xamarin.Auth;

namespace ZIMLApp
{
    public class AuthenticationState
    {
        public static OAuth2Authenticator Authenticator;
    }
}

﻿using System;
using Plugin.DeviceInfo;
using ZIMLApp.Classes.Utility;
namespace ZIMLApp.Classes.Model
{
    /// Sign in API request parameter
    public class SignInRequestParam :RequestParam
    {
        /// User's email id.
        public string email_id { get; set; }
        /// Password.
        public string password { get; set; }
        /// Device model (optinal).
        public string device_model { get; set; }
        /// Platform iOS or Android.
        public string platform { get; set; }
        /// Platform version (optinal).
        public string platform_version { get; set; }
        /// App version.
        public string app_version { get; set; }
        /// Push id (optinal).
        public string push_id { get; set; }
        /// UUID of the device (optinal).
        public string uuid { get; set; }

        public SignInRequestParam()
        {
            uuid = CrossDeviceInfo.Current.Id;
            app_version = CrossDeviceInfo.Current.AppVersion;
            platform_version = CrossDeviceInfo.Current.Version;
            platform = CrossDeviceInfo.Current.Platform.ToString();
            device_model = CrossDeviceInfo.Current.Model;
        }

		public override string ToString()
		{
            return "user device info: uuid " + uuid + "\n" + "app_version " + app_version + "\n" + "platform_version " + platform_version + "\n" + "platform " + platform + "\n" + "device_model " + device_model;
		}
	}

    /// Sign in detail response model class.
    public class SignInDetail
    {
        /// First name.
        public string first_name { get; set; }
        /// Last name.
        public string last_name { get; set; }
        /// Device id used as access_device_id.
        public string device_id { get; set; }
        /// Access token used as access_auth_key.
        public string access_token { get; set; }
    }

    /// Request OTP API parameter.
    public class RequestOTPParam : RequestParam
    {
        /// Email id.
        public string email_id { get; set; }
        /// For forgot password request, values will be yes if true no if flase.
        public string forgot_password_request { get; set; }

        public RequestOTPParam(string emailstr, bool isForgotPassword)
        {
            email_id = emailstr;
            if (isForgotPassword)
            {
                forgot_password_request = "yes";
            }
            else
            {
                forgot_password_request = "";   
            }

        }
    }

    /// Validate OTP API request parameter.
    public class ValidateOTPParam : RequestParam
    {
        /// Email id.
        public string email_id { get; set; }
        /// OTP id.
        public string otp_id { get; set; }
        /// OTP entered by user.
        public string otp { get; set; }
    }

    /// Create Account API request parameter.
    public class CreateAccountParam : RequestParam
    {
        /// OTP validation token.
        public string otp_successful_validation_token { get; set; }
        /// OAuth id.
        public string oauth_id { get; set; }
        /// OAuth registration token.
        public string oauth_registration_token { get; set; }
        /// Email id.
        public string email_id { get; set; }
        /// Password.
        public string password { get; set; }
        /// First name.
        public string first_name { get; set; }
        /// Last name.
        public string last_name { get; set; }
        /// Device model.
        public string device_model { get; set; }
        /// Platform iOS or Android.
        public string platform { get; set; }
        /// Platform version.
        public string platform_version { get; set; }
        /// App version.
        public string app_version { get; set; }
        /// Push id.
        public string push_id { get; set; }
        /// UUID for the device.
        public string uuid { get; set; }

        public CreateAccountParam()
        {
            uuid = CrossDeviceInfo.Current.Id;
            app_version = CrossDeviceInfo.Current.AppVersion;
            platform_version = CrossDeviceInfo.Current.Version;
            platform = CrossDeviceInfo.Current.Platform.ToString();
            device_model = CrossDeviceInfo.Current.Model;
        }

        public override string ToString()
        {
            return "user device info: uuid " + uuid + "\n" + "app_version " + app_version + "\n" + "platform_version " + platform_version + "\n" + "platform " + platform + "\n" + "device_model " + device_model;
        }
    }

    /// Reset password API request parameter.
    public class ResetPasswordParams : RequestParam
    {
        /// OTP validation token.
        public string otp_successful_validation_token { get; set; }
        /// Email id.
        public string email_id { get; set; }
        /// Password.
        public string password { get; set; }
    }

    /// Change password API request parameter.
    public class ChangePasswordParams : RequestParam
    {
        /// Email id.
        public string email_id { get; set; }
        /// Old password.
        public string password { get; set; }
        /// New password.
        public string new_password { get; set; }
    }

    /// Request OTP detail API response model class.
    public class RequestOTPDetail
    {
        /// OTP id.
        public string otp_id { get; set; }

    }

    /// Validate OTP API resopnse model class.
    public class ValidateOTPDetail
    {
        /// OTP validation token.
        public string otp_successful_validation_token { get; set; }
    }

    /// Create accout API resopnse model class.
    public class CreateAccountDetail
    {
        /// 
        public string device_id { get; set; }
        /// 
        public string access_token { get; set; }
    }

    /// Validate Device id API request parameters. 
    public class ValidateDeviceParams : RequestParam
    {
        /// Push id.
        public string push_id { get; set; }

        public ValidateDeviceParams()
        {
            if (!string.IsNullOrEmpty(Preference.PushId))
            {
                push_id = Preference.PushId;
            }
        }
    }

    /// OAuth login API request parameters used for facebook and google.
    public class OAuthLoginRequestParam : RequestParam
    {
        /// Auth id.
        public string auth_id { get; set; }
        /// Login token.
        public string login_token { get; set; }
        /// Device Model.
        public string device_model { get; set; }
        /// Platform iOS or Android.
        public string platform { get; set; }
        ///  Platform version.
        public string platform_version { get; set; }
        /// App version.
        public string app_version { get; set; }
        /// Push id.
        public string push_id { get; set; }
        /// UUID of the device.
        public string uuid { get; set; }

        public OAuthLoginRequestParam()
        {
            uuid = CrossDeviceInfo.Current.Id;
            app_version = CrossDeviceInfo.Current.AppVersion;
            platform_version = CrossDeviceInfo.Current.Version;
            platform = CrossDeviceInfo.Current.Platform.ToString();
            device_model = CrossDeviceInfo.Current.Model;
        }
    }

    /// OAuth validate API request parameters.
    public class OAuthValidateRequestParam : RequestParam
    {
        /// Auth id.
        public string auth_id { get; set; }
        /// Auth type google or facebook.
        public string auth_type { get; set; }
        /// Access token.
        public string access_token { get; set; }
        /// Email id.
        public string email_id { get; set; }
    }
}

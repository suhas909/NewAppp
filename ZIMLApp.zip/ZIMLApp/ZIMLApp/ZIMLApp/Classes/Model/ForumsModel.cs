﻿using System;
using System.Collections.Generic;
using ZIMLApp.Classes.Utility;
using System.Linq;

namespace ZIMLApp.Classes.Model
{
    /// Fourm List API parameter model class.
    public class ForumListParam : RequestParam
    {
        /// Fourm id.
        public string forum_id { get; set; }
    }

    /// Fourm detail API parameter model class.
    public class ForumDetailParam : RequestParam
    {
        /// Fourm id.
        public string forum_id { get; set; }
        /// Discussion id.
        public string discussion_id { get; set; }
    }

    /// Fourm Sub Unsub API parameter model class.
    public class ForumSubUnsubParam : RequestParam
    {
        /// Fourm id.
        public string forum_id { get; set; }
        /// Discussion id.
        public string discussion_id { get; set; }
    }

    /// Fourm Add discussion API parameter model class.
    public class ForumAddDiscussionParam : RequestParam
    {
        /// Subject for forum.
        public string subject { get; set; }
        /// Message for forum.
        public string message { get; set; }
    }

    /// Fourm Reply on a post API parameter model class.
    public class ForumReplyPostParam : RequestParam
    {
        /// Subject for forum.
        public string subject { get; set; }
        /// Message for forum.
        public string message { get; set; }
        /// Parent id.
        public string parent_id { get; set; }
        /// Discussion id.
        public string discussion_id { get; set; }
    }

    /// Fourm Delete API parameter model class.
    public class ForumDeletePostParam : RequestParam
    {
        /// Post id.
        public string post_id { get; set; }
    }

    /// Fourm Edit post API parameter model class.
    public class ForumEditPostParam : RequestParam
    {
        /// Post id.
        public string post_id { get; set; }
        /// Subject for forum.
        public string subject { get; set; }
        /// Message for forum.
        public string message { get; set; }
    }

    /// Fourm Detail response model class.
    public class ForumDetailResponse
    {
        /// Current time at server.
        public string current_timestamp { get; set; }
        /// Is user subscribed for the forum.
        public bool is_user_subscribed { get; set; }
        /// List of post for a forum.
        public List<ForumDetailItem> posts { get; set; }
    }

    /// Fourm list item model class.
    public class ForumListItem
    {
        /// Forum id.
        public string id { get; set; }
        /// Forum title.
        public string name { get; set; }
        /// Forum started by first name.
        public string started_by_first_name { get; set; }
        /// Forum started by last name.
        public string started_by_last_name { get; set; }
        /// Total post count for the forum.
        public string post_count { get; set; }
        /// Last post date.
        public string last_post_on { get; set; }

        public string StartedBy { get { return started_by_first_name + " " + started_by_last_name; } }

        public string LastPostedTime { get 
            {
                DateTime datetime = CommonClass.FromUnixTime(Convert.ToInt64(last_post_on));
                datetime = datetime.ToLocalTime();
                return datetime.ToString("ddd, dd MMM yyyy, hh:mm tt");
            }
        }

        public string postCount { get { return (Convert.ToInt64(post_count) - 1).ToString(); } }

        public string postName { get{ return name.ToCharArray().First().ToString().ToUpper() + name.Substring(1); }}

    }

    /// Fourm detail item model class.
    public class ForumDetailItem
    {
        /// Forum id.
        public string id { get; set; }
        /// Forum Subject.
        public string subject { get; set; }
        /// Forum message as html string.
        public string message { get; set; }
        /// Parent id for the forum.
        public string parent { get; set; }
        /// User id of the posted by user.
        public string userid { get; set; }
        /// User's first name.
        public string user_first_name { get; set; }
        ///  User's last name.
        public string user_last_name { get; set; }
        /// Created date.
        public string created { get; set; }
        /// Modified date.
        public string modified { get; set; }
        /// Is own post. If the post is posted by the logged in user then the value is true.
        public bool own_post { get; set; }
        /// attachments for the post.
        public List<string> attachments { get; set; }

        public string user_name { get { return user_first_name + " " + user_last_name; } }

        public string getPostedTime()
        {
            DateTime datetime = CommonClass.FromUnixTime(Convert.ToInt64(modified));
            datetime = datetime.ToLocalTime();
            return datetime.ToString("ddd, dd MMM yyyy, hh:mm tt");
        }
    }
}

﻿using System;
using Xamarin.Forms;

namespace ZIMLApp.Classes.Model
{
    /// Master page item model class
    public class MasterPageItem
    {
        /// Title for the item.
        public string Title { get; set; }
        /// Icon source string for the item.
        public string IconSource { get; set; }
        /// Targat type for the item.
        public Type TargetType { get; set; }

        public bool IsShadowEnable { get { return isShadowEnable(); }}

        private bool isShadowEnable()
        {
            if (Device.RuntimePlatform == Device.iOS)
            {
                return false;
            }
            return true;
        }

    }
}

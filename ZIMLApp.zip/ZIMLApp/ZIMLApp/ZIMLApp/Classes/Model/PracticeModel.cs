﻿using System;
using System.Collections.Generic;
namespace ZIMLApp.Classes.Model
{
    
    /// Practice list API request parameters.
    public class PracticeListParam : RequestParam
    {
        /// Contest type
        public string contest_type { get; set; }
    }

    /// Practice detail API request parameters.
    public class PracticeDeatilParam : RequestParam
    {
        /// Is start new attempt, value will be yes/no, default is no.
        public string new_attempt { get; set; } //yes/no : Start new attempt
        /// Quiz id
        public string quiz_id { get; set; }
        /// Attempt id
        public string attempt_id { get; set; }

    }

    /// Practice list response object class.
    public class PracticeListResponse 
    {
        /// Current time of the server.
        public int current_timestamp { get; set; }
        /// List of all Contest types.
        public Dictionary<string, object> contest_types { get; set; }
        /// Selected contest type
        public string selected_contest_type { get; set; }
        /// List of contest in selected contest type.
        public List<Contest> contests { get; set; }
    }

    /// Practice detail response object class.
    public class PracticeDetailResponse
    {
        /// Current time of the server.
        public int current_timestamp { get; set; }
        /// Time limit for the contest.
        public string timelimit { get; set; }
        /// Current attempt object.
        public CurrentAttempt current_attempt { set; get; }
        /// List of all attempts.
        public List<Attempts> attempts { get; set; }

        public int getTotalMinutes()
        {
            var timeSpan = TimeSpan.FromSeconds(Convert.ToInt64(timelimit));

            return (int)Convert.ToInt64(timeSpan.TotalMinutes);
        }

        public string getTimerText()
        {
            var timeSpan = TimeSpan.FromSeconds(Convert.ToInt64(timelimit));

            var totalTimeSpan = TimeSpan.FromSeconds(Convert.ToInt64(timelimit));
            int hr = totalTimeSpan.Hours;
            var minute = totalTimeSpan.Minutes;
            var second = totalTimeSpan.Seconds;

            if (hr != 0 || minute != 0 || minute == 0 && second != 0)
            {
                if (hr == 0)
                    return $"{minute.ToString("00")}:{second.ToString("00")}";
                else
                    return $"{hr}:{minute.ToString("00")}:{second.ToString("00")}";
            }
            else
            {
                return "00:00";
            }
        }

        public string getTime()
        {
            var timeSpan = TimeSpan.FromSeconds(Convert.ToInt64(timelimit));

            if (timeSpan.Hours == 0)
            {
                return timeSpan.Minutes.ToString() + " minutes";
            }
            else if (timeSpan.Hours != 0 && timeSpan.Minutes == 0)
            {
                if (timeSpan.Hours == 1) return timeSpan.Hours.ToString() + " hour";
                else return timeSpan.Hours.ToString() + " hours";
            }
            else
            {
                if (timeSpan.Hours == 1) return timeSpan.Hours.ToString() + " hour " + timeSpan.Minutes.ToString() + " minutes";
                else return timeSpan.Hours.ToString() + " hours " + timeSpan.Minutes.ToString() + " minutes";
            }
        }
    }

    /// Current attempt model class.
    public class CurrentAttempt
    {
        /// Attempt id.
        public int id { set; get; }
        /// List of questions.
        public List<Question> questions { set; get; }
    }

    /// Contest model class for practice.
    public class Contest
    {
        /// Quiz id.
        public string quiz_id { get; set; }
        /// Course id.
        public string course_id { get; set; }
        /// Name for the contest.
        public string name { get; set; }
    }

    /// AMC contest model class.
    public class AMCContest
    {
        /// Contest type.
        public string contest_type { get; set; }
        /// Contest Name.
        public string name { get; set; }

        public AMCContest (string name, string contest_type)
        {
            this.contest_type = contest_type;
            this.name = name;
        }
    }
}

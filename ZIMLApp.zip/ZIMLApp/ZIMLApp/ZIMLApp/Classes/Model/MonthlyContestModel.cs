﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using ZIMLApp.Classes.Utility;

namespace ZIMLApp.Classes.Model
{
    /// Upcoming monthly contest model class.
    public class MonthlyContest
    {
        public string id { get; set; }
        public string title { get; set; }
    }

    /// Previous monthly contest model class.
    public class PreviousContest : MonthlyContest {}

    /// Answer summary model class for monthly contest.
    public class AnswerSummary : INotifyPropertyChanged
    {
        /// Answer propery name.
        public const string answerPropertyName = "answer";
        /// Index of the item.
        public int index { get; set; }
        /// slot for the question.
        public String slot { get; set; }
        /// Sequence for the answer.
        public String sequence { get; set; }
        /// Is answer correct.
        public bool isCorrect = true;
        /// Correct answer.
        public String correctAns { get; set; }
        /// Submitted answer.
        private string answerValue = string.Empty;
        public string answer { 
            get { return answerValue; } 
            set{this.ChangeAndNotify(ref this.answerValue, value, answerPropertyName);} 
        }

        public string SNo { get { return "" + (index + 1); } }

        public string status 
        { 
            get 
            {
                if (string.IsNullOrEmpty(answer)) return "Not answered";
                else return "Answered";
            }
        }
        public string textColor
        {
            get
            {
                if (string.IsNullOrEmpty(answer)) return "#FF0002";
                else return "#4A4A4A";
            }
        }

        public string answerTextColor
        {
            get
            {
                if (isCorrect) return "#65B909";
                else if (answer == "Leave blank (1.5 points)") return "#4A4A4A";
                else return "FF0002";
            }
        }

        public AnswerSummary(int index)
        {
            this.index = index;
            this.slot = (index + 1).ToString();
            this.answer = "";
            sequence = "1";

        }

        public AnswerSummary(int index, string answer)
        {
            this.index = index;
            this.slot = (index + 1).ToString();
            this.answer = answer;
            isCorrect = false;
            sequence = "1";

        }

        public AnswerSummary(int index, string sequence, string answer, bool isCorrect)
        {
            this.index = index;
            this.slot = (index + 1).ToString();
            this.sequence = sequence;
            this.answer = answer;
            this.isCorrect = isCorrect;
        }

        public AnswerSummary(int index, string sequence, string answer)
        {
            this.index = index;
            this.slot = (index + 1).ToString();
            this.sequence = sequence;
            this.answer = answer;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        private bool ChangeAndNotify<T>(ref T property, T value, [CallerMemberName] string propertyName = "")
        {
            if (!EqualityComparer<T>.Default.Equals(property, value))
            {
                property = value;
                NotifyPropertyChanged(propertyName);
                return true;
            }
            return false;
        }

    }

    /// Monthly Contest List API Parameters model class.
    public class MonthlyContestListParam : RequestParam
    {
        /// Is archaived if true returns the previous contest, otherwise return the upcoming contest.
        public string is_archived { get; set; }
    }

    /// Monthly Contest Detail API Parameters model class.
    public class MonthlyContestDetailParam : RequestParam
    {
        /// Quiz id.
        public string quiz_id { get; set; }
        /// Start new attempt, value will be yes/no, default is no.  
        public string start_attempt { get; set; } //yes/no : Start new attempt
    }

    /// Enroll User For Cource API Parameters model class.
    public class EnrollUserForCourceParam : RequestParam
    {
        /// Course id.
        public string course_id { get; set; }
        /// Purchase id.
        public string purchase_id { get; set; }
        /// Product id.
        public string product_id { get; set; }
        /// Transaction date in UTC format.
        public string transaction_date_utc { get; set; }
        /// State of purcahse.
        public string state { get; set; }
        /// Purchase token.
        public string purchase_token { get; set; }
        /// Environment for the purchase Sandbox or live. 
        public string environment { get; set; }
        /// Package name. 
        public string package_name { get; set; }
        /// Use existing subscription value will be yes if user already subscribed and no if it is a new subscription.
        public string use_existing_subscription { get; set; }

    }

    /// Monthly contest list response model class.
    public class MonthlyContestListResponse
    {
        /// Current time of the server.
        public int current_timestamp { get; set; }
        /// List of contest.
        public List<ContestDetail> contests { get; set; }
    }

    /// Monthly contest Detial response model class.
    public class MonthlyContestDetailResponse
    {
        /// Current time of the server.
        public int current_timestamp { get; set; }
        /// Should show answers.
        public bool shouldShowAnswer { get; set; }
        /// List of questions.
        public List<Question> questions { get; set; }
        /// List of attempts.
        public List<Attempts> attempts { get; set; }
        /// Dictionary for answers.
        public Dictionary<string, List<Answer>> answers { get; set; }
    }

    /// Monthly Contest Submit Answer API Parameters model class.
    public class MonthlyContestSubmitAnswerParam : RequestParam
    {
        /// Quiz id.
        public string quiz_id { get; set; }
        /// Attempt id.
        public string attempt_id { get; set; }
        /// Slot for the question.
        public string slot { get; set; }
        /// Answer to submit.
        public string answer { get; set; }
        /// Sequence for the answer.
        public string sequence { get; set; }
    }

    /// Question model class.
    public class Question
    {
        /// Question id.
        public string id { get; set; }
        /// Question text as html string.
        public string questiontext { get; set; }
        /// Qusetion text format.
        public string questiontextformat { get; set; }
        /// General feedback.
        public string generalfeedback { get; set; }
        /// General feedback format.
        public string generalfeedbackformat { get; set; }
        /// Type of question.
        public string type { get; set; }
        /// List of Answers.
        public List<Answer> answers { get; set; }
    }

    /// Attempt model class for monthly contest.
    public class Attempts
    {
        /// Attempt id.
        public string id { get; set; }
        /// Attempt number.
        public string attempt { get; set; }
        /// Attempt unique id.
        public string uniqueid { get; set; }
        /// Start time for attempt.
        public string timestart { get; set; }
        /// Finish time for attempt.
        public string timefinish { get; set; }
        /// List of submitted answers.
        public List<SubmittedAnswer> submitted_answers { get; set; }
        /// Grades for the contest.
        public string sumgrades { get; set; }

        public string date { get { return getDateForPractice(); } }
        public string grade { get { return getGradeForPractice(); } }

        public string getDate()
        {
            DateTime datetime = CommonClass.FromUnixTime(Convert.ToInt64(timestart));

            return datetime.ToLocalTime().ToString("MMMM dd yyyy");
        }

        public string getDateForPractice()
        {
            DateTime datetime = CommonClass.FromUnixTime(Convert.ToInt64(timestart));
            datetime = datetime.ToLocalTime();
            return datetime.ToString("MMMM dd yyyy hh:mm tt");
        }

        public int getTimeTaken()
        {
            DateTime datetimeFinish = CommonClass.FromUnixTime(Convert.ToInt64(timefinish));
            DateTime datetimeStart = CommonClass.FromUnixTime(Convert.ToInt64(timestart));
            var diff = datetimeFinish.Subtract(datetimeStart).TotalMinutes;
            return (Convert.ToInt32(diff));
        }
        public string getGrade()
        {
            int grades = Convert.ToInt32(Convert.ToDecimal(sumgrades));
            return grades + "/100";
        }

        public string getGradeForPractice()
        {
            int grades = Convert.ToInt32(Convert.ToDecimal(sumgrades));
            return "Grade : " + grades;
        }
    }

    /// Submitted Answer model class for monthly contest.
    public class SubmittedAnswer
    {
        /// Slot for the question.
        public string slot { get; set; }
        /// Sequence for the answer.
        public string sequence { get; set; }
        /// Answer to submit.
        public string answer { get; set; }
    }

    /// Answer model for monthly contest.
    public class Answer
    {
        /// Correct answer.
        public string answer { get; set; }
        /// Answer format.
        public string answerformat { get; set; }
        /// Fraction.
        public string fraction { get; set; }
        /// Feedback for answer.
        public string feedback { get; set; }
        /// feedback format.
        public string feedbackformat { get; set; }
    }

    /// Monthly contest Detail model class.
    public class ContestDetail
    {
        /// Quiz id.
        public string quiz_id { get; set; }
        /// Course id.
        public string course_id { get; set; }
        /// Name for the contest.
        public string name { get; set; }
        /// Year month for the contest.
        public string yearmonth { get; set; }
        /// Summary detail for the contest.
        public string summary { get; set; }
        /// Display name for contest.
        public string display_name { get; set; }
        /// Quiz name.
        public string quiz_name { get; set; }
        /// Quiz open date.
        public string timeopen { get; set; }
        /// Quiz close date.
        public string timeclose { get; set; }
        /// Time limit for the contest.
        public string timelimit { get; set; }
        /// User is enrolled for the contest, true if enrolled false if not.
        public bool is_enrolled { get; set; }
        /// List of sections.
        public List<Section> sections { get; set; }

        public string getStartDate()
        {
            DateTime datetime = CommonClass.FromUnixTime(Convert.ToInt64(timeopen));

            return datetime.ToLocalTime().ToString("dd MMMM");
        }

        public string getEndDate()
        {
            DateTime datetime = CommonClass.FromUnixTime(Convert.ToInt64(timeclose));

            return datetime.ToLocalTime().ToString("dd MMMM");
        }

        public string getEndDateFull()
        {
            DateTime datetime = CommonClass.FromUnixTime(Convert.ToInt64(timeclose));
            //datetime = datetime.AddDays(-1);

            return datetime.ToLocalTime().ToString("dddd, dd MMMM yyyy");
        }

        public string getStartDateFull()
        {
            DateTime datetime = CommonClass.FromUnixTime(Convert.ToInt64(timeopen));

            return datetime.ToLocalTime().ToString("dddd, dd MMMM yyyy");
        }

        public string getTime()
        {
            var timeSpan = TimeSpan.FromSeconds(Convert.ToInt64(timelimit));

            if (timeSpan.Hours == 0)
            {
                return timeSpan.Minutes.ToString() + " minutes";
            }
            else if (timeSpan.Hours != 0 && timeSpan.Minutes == 0)
            {
                return timeSpan.Hours.ToString() + " hour";
            }
            else
            {
                return timeSpan.Minutes.ToString() + " minutes";
            }
        }

        public int getTotalMinutes()
        {
            var timeSpan = TimeSpan.FromSeconds(Convert.ToInt64(timelimit));

            return (int)Convert.ToInt64(timeSpan.TotalMinutes);
        }

    }

    /// Section model class.
    public class Section
    {
        /// Section index.
        public string section_index { get; set; }
        /// Section name.
        public string name { get; set; }
        /// Section summary.
        public string summary { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace ZIMLApp.Classes.Model
{
    /// <summary>
    /// App settings item model class.
    /// </summary>
    class AppSettingsItems
    {
        /// Title or name for the settings item.
        public String title { set; get; }
        /// Is Action button visible for the item, default value is false.
        public bool IsActionButtonVisible { set; get; } 
        /// Is Arrow icon visible for the settings item, default value is true.
        public bool IsArrowVisible { set; get; }
        /// Is Notification on for the item, default value is false.
        public bool IsNotificationOn { set; get; }

        public AppSettingsItems()
        {
            IsActionButtonVisible = false;
            IsArrowVisible = true;
            IsNotificationOn = false;
        }
    }
}
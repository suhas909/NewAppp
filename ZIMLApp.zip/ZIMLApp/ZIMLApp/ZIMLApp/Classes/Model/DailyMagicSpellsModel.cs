﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using Newtonsoft.Json;
using ZIMLApp.Classes.Utility;
using System.Linq;
using System.Globalization;
using Xamarin.Forms;

namespace ZIMLApp.Classes.Model
{
    /// <summary>
    /// Request parameter model class. This is the base class for all Request Param classes.
    /// </summary>
    public class RequestParam
    {
        /// <summary>
        /// Gets or sets the access device identifier.
        /// </summary>
        /// <value>The access device identifier.</value>
        public string access_device_id { get; set; }
        /// <summary>
        /// Gets or sets the access auth key.
        /// </summary>
        /// <value>The access auth key.</value>
        public string access_auth_key { get; set; }

        public RequestParam ()
        {
            if (Preference.IsUserLoggedIn == true)
            {
                access_auth_key = Preference.AccessToken;
                access_device_id = Preference.DeviceId;
            }
        }
    }

    /// <summary>
    /// The base class model for json Response returns from the API.
    /// </summary>
    public class ResponseJson
    {
        public string status { get; set; }
        public string message { get; set; }
        public object contents { get; set; }
    }

    /// <summary>
    /// Daily magic spells list API parameter.
    /// </summary>
    public class DailyMagicSpellsListParam : RequestParam
    {
        /// Gets or sets the is archived.
        public string is_archived { get; set; }
    }

    /// <summary>
    /// Daily magic spells detail API parameter.
    /// </summary>
    public class DailyMagicSpellsDetailParam : RequestParam
    {
        /// Gets or sets the quiz identifier.
        public string quiz_id { get; set; }
    }

    /// <summary>
    /// Daily magic spells list model class.
    /// </summary>
    public class DailyMagicSpellsList : ResponseJson
    {   
        /// Gets or sets the records.
        public List<Record> records { get; set; }

        public DailyMagicSpellsList(List<Record> list)
        {
            records = list;
        }
    }

    /// <summary>
    /// Daily magic spell record model class
    /// </summary>
    public class Record
    {
        /// Gets or sets the id for a magic spell.
        public string id { get; set; }
        /// Name for the magic spell.
        public string name { get; set; }
        /// Year and month for the magic spell.
        public string yearmonth { get; set; }

        public override string ToString()
		{
            return name;
		}
	}

    /// <summary>
    /// Question detail model class for daily magic spell.
    /// </summary>
    public class QuestionDetail
    {
        /// Id for the question.
        public string id { get; set; }
        /// Question text as html string.
        public string questiontext { get; set; }
        /// Question text format.
        public string questiontextformat { get; set; }
        /// General feedback or solution for the question.
        public string generalfeedback { get; set; }
        /// General feedback format.
        public string generalfeedbackformat { get; set; }
    }

    /// <summary>
    /// Question detail response model class.
    /// </summary>
    public class QuestionDetailResponse
    {
        /// Question detail object.
        public QuestionDetail details { get; set; }
        /// Answer detail object.
        public AnswerDetail answer { get; set; }
        /// Attempt list.
        public List<Attempt> attempts { get; set; }

    }

    /// <summary>
    /// Answer detail model class for daily magic spell.
    /// </summary>
    public class AnswerDetail
    {
        /// Correct answer for the question.
        public string answer { get; set; }
        /// Answer format.
        public string answerformat { get; set; }
        /// Fraction for the answer.
        public string fraction { get; set; }
        /// Feedback for the answer.
        public string feedback { get; set; }
        /// Feedback format.
        public string feedbackformat { get; set; }
    }

    /// <summary>
    /// Attempt model class.
    /// </summary>
    public class Attempt
    {
        /// Attempt id.
        public string id { get; set; }
        /// Attempt number.
        public string attempt { get; set; }
        /// Unique id for attempt.
        public string uniqueid { get; set; }
        /// Start time for attempt.
        public string timestart { get; set; }
        /// Finish time for attempt.
        public string timefinish { get; set; }
        /// Submitted answer.
        public string submitted_answer { get; set; }
        /// Grades for the attempt.
        public string sumgrades { get; set; }

        public string date { get { return getDate(); } }
        public string status { get { return getStatus(); } }


        public string getDate()
        {   
            DateTime datetime = CommonClass.FromUnixTime(Convert.ToInt64(timefinish));
            datetime = datetime.ToLocalTime();
            return datetime.ToString("MMMM dd yyyy, hh:mm tt");
        }


        public string getStatus()
        {
            int grades = Convert.ToInt32(Convert.ToDecimal(sumgrades));
            if (grades == 0)
            {
                return "Your answer is wrong.";
            }
            else 
            {
                return "Your answer is right.";
            }

        }

        public bool IsShadowEnable { get { return isShadowEnable(); } }

        private bool isShadowEnable()
        {
            if (Device.RuntimePlatform == Device.iOS)
            {
                return false;
            }
            return true;
        }

        public static implicit operator Attempt(Attempts v)
        {
            throw new NotImplementedException();
        }
    }

    /// Submit attempt API parameter model class.
    public class SubmitAttemptParam : RequestParam
    {
        /// Quiz id.
        public string quiz_id { get; set; }
        /// Question id.
        public string question_id { get; set; }
        /// Answer to submmit.
        public string answer { get; set; }
        /// Time taken to attempt the spell.
        public string time_taken { get; set; }
    }

    /// Submit attempt response model class.
    public class SubmitAttemptResponse
    {
        /// attempt id.
        public string attempt_id { get; set; }   
    }

    /// Finish attempt API parameter model class.
    public class FinishAttemptParam : RequestParam
    {
        /// attempt id.
        public string attempt_id { get; set; }
    }

    /// Student model class used to show the Leaderboard page.
    public class Student
    {
        /// First name of the student.
        public string firstname { get; set; }
        /// Last name of the student.
        public string lastname { get; set; }
        /// Total Grades of the student.
        public string gradesum { get; set; }
        /// Position on the leaderboard for the student.
        public string position { get; set; }

        public string name { get { return firstname + " " + lastname; } }
        public string points {
            get 
            {
                int grades = Convert.ToInt32(Convert.ToDecimal(gradesum));
                return grades + " Points";
            }
        }

    }

}

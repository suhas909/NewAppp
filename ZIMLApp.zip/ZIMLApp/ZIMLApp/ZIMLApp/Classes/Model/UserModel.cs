﻿using System;
using System.Collections.Generic;
namespace ZIMLApp.Classes.Model
{
    /// Profile detail API request parameters.
    public class ProfileDetailParam: RequestParam {}

    /// Update profile detail API request parameters.
    public class UpdateProfileParam : RequestParam
    {
        /// First name.
        public string first_name { get; set; }
        /// Last name.
        public string last_name { get; set; }
        /// School name.
        public string school { get; set; }
        /// Grade level.
        public string grade_level { get; set; }
        /// Country code.
        public string country_code { get; set; }
    }

    /// Update profile photo API request parameters.
    public class UpdateProfilePhotoParam : RequestParam
    {
        /// Image file name.
        public string image_file { get; set; }
    }

    /// Profile detail API response model class.
    public class ProfileDetail
    {
        /// Email id.
        public string email_id { get; set; }
        /// First name.
        public string first_name { get; set; }
        /// Last name.
        public string last_name { get; set; }
        /// School name.
        public string school { get; set; }
        /// Grade level.
        public string grade_level { get; set; }
        /// Country.
        public string country { get; set; }
        /// List of total points.
        public Dictionary<String, int> points { get; set; }

        public string GetPoints()
        {
            if (points.ContainsKey("dms_points_2m")) { return  points["dms_points_2m"] + " Points"; }
            else { return ""; }
        }
    }

    /// Update profile photo response model class. 
    public class UpdateProfilePhotoResponse
    {
        /// Status
        public string status { get; set; }
        /// Message
        public string message { get; set; }
        /// Picture URL.
        public string url { get; set; }
        /// File name.
        public string filename { get; set; }
        public string newpicture { get; set; }
        public string id { get; set; }
        public string file { get; set; }
    }

    /// Model class to hold the data for Facebook and Google account detail.
    public class User
    {
       
        /// User type.
        public UserType user_type { get; set; }
        /// User id.
        public string id { get; set; }
        /// Email id.
        public string email_id { get; set; }
        /// First name.
        public string first_name { get; set; }
        /// Last name.
        public string last_name { get; set; }
        /// Profile picture URL.
        public string picture_url { get; set; }
        /// Access token.
        public string access_token { get; set; }

		public override string ToString()
		{
            return "email_id = " + email_id + "\n" + "picture_url = " + picture_url + "\n";
		}
	}


    /// User type enum for social media sign in.
    public enum UserType
    {
        facebook,
        google
    }

    /// Contact detail API response model class.
    public class ContactDetail
    {
        /// Areteem Headquarters address.
        public string address { get; set; }
        /// Telephone number.
        public string telephone { get; set; }
        /// Info Email id.
        public string email { get; set; }
        /// Website URL.
        public string website { get; set; }
        /// WeChat id.
        public string wechat { get; set; }
        /// Facebook share URL.
        public string facebook_share { get; set; }

    }

}

﻿using System;
using Xamarin.Forms;
using Microsoft.VisualBasic;
using System.Runtime.InteropServices;
using System.Collections.Generic;

namespace ZIMLApp.Classes.Utility
{
    // <summary>
    // This class used to hold all the constants which we used throughout the project.
    // </summary>
    public class Constants
    {
     
        // The base URL for the APIs
        //Testing
        //public static string baseURL = "https://zimlapp.areteem.org";
        //Live
        public static string baseURL = "https://ziml.areteem.org";

         //This environment variable used in In-App-Purchase.
        //Testing
        //public static string environment = "sandbox";
        //Live
        public static string environment = "live";

        // The product identifier for monthly contest used in In-App-Purchase.
        public static string productIdMonthlyContest = "com.gyrod.zimlapp.monthlycontest"; //"com.gyrod.zimlapp.contest";

        public static string packageName = "com.GyroD.ZIMLApp";

        ///
        public static string QuizBaseUrl = "https://ziml.areteem.org/mod/quiz/view.php?q=";
        /// 
        public static string dailyMagicSpellsListAPI = baseURL + "/api/dailymagicspells/list.php";
        /// 
        public static string dailyMagicSpellsDetailAPI = baseURL + "/api/dailymagicspells/details.php";
        /// 
        public static string submitAttemptAPI = baseURL + "/api/dailymagicspells/submit-attempt.php";
        /// 
        public static string finishAttemptAPI = baseURL + "/api/dailymagicspells/finish-attempt.php";
        /// 
        public static string leaderboardAPI = baseURL + "/api/dailymagicspells/leaderboard.php";

        /// 
        public static string signInAPI = baseURL + "/api/auth/login.php";
        /// 
        public static string createAccountAPI = baseURL + "/api/auth/create-account.php";
        /// 
        public static string validateOTPAPI = baseURL + "/api/auth/validate-otp.php";
        /// 
        public static string requestOTPAPI = baseURL + "/api/auth/request-otp.php";
        /// 
        public static string resetPasswordAPI = baseURL + "/api/auth/reset-password.php";
        /// 
        public static string validateDeviceAPI = baseURL + "/api/auth/validate-device.php";

        //Login with FB and google
        public static string validateOAuthAPI = baseURL + "/api/auth/validate-oauth.php";

        public static string loginOAuthAPI = baseURL + "/api/auth/login-oauth.php";


        public static string ChangePasswordAPI = baseURL + "/api/auth/change-password.php";


        public static string profileDetailAPI = baseURL + "/api/users/retrieve-profile-details.php";

        public static string updateProfileAPI = baseURL + "/api/users/update-profile.php";

        public static string updateProfilePhotoAPI = baseURL + "/api/users/update-profile-photo.php";

        public static string clearProfilePhotoAPI = baseURL + "/api/users/clear-profile-photo.php";



        public static string monthlyContestDetailAPI = baseURL + "/api/contests/details.php";

        public static string monthlyContestSubmitAnswerAPI = baseURL + "/api/contests/submit-answer.php";

        public static string monthlyContestFinishAttemptAPI = baseURL + "/api/contests/finish-attempt.php";

        public static string monthlyContestListAPI = baseURL + "/api/contests/list.php";

        public static string enrollUserForCourceAPI = baseURL + "/api/contests/enroll.php";

        public static string practiceListAPI = baseURL + "/api/contests/practice.php";

        public static string practiceDetailAPI = baseURL + "/api/contests/practice-details.php";


        public static string forumsAPI = baseURL + "/api/forum/list-forums.php";

        public static string forumListAPI = baseURL + "/api/forum/list-discussions.php";

        public static string forumDetailAPI = baseURL + "/api/forum/discussion-details.php";

        public static string forumSubUnsubAPI = baseURL + "/api/forum/toggle_subscription.php";

        public static string forumAddDiscussionAPI = baseURL + "/api/forum/add-discussion.php";

        public static string forumReplyPostAPI = baseURL + "/api/forum/reply-to-discussion.php";

        public static string forumDeletePostAPI = baseURL + "/api/forum/delete-reply.php";

        public static string forumEditPostAPI = baseURL + "/api/forum/edit-post.php";


        public static string contactUsDetailAPI = baseURL + "/api/contactus/details.php";

        // URLs for pages.
        public static string privacyPolicyPageURL = baseURL + "/api/about/privacy.php";
        public static string termsOfUsePageURL = baseURL + "/api/about/termsofuse.php";
        public static string aboutZIMLPageURL = baseURL + "/api/about/overview.php";
        public static string aboutAreteemPageURL = baseURL + "/api/about/about-areteem-institute.php";


        public static string DISCUSSION_FORUM_ID = "12";

        public static string NEWS_FORUM_ID = "2";


        public static string NetworkErrorTitle = "No internet access";

        public static string NetworkErrorMessage = "Check your Wi-Fi or mobile network and try again.";


        public static string ServerErrorTitle = "Unable to fetch data";

        public static string ServerErrorMessage = "We are not able to reach our server. Please refresh the page.";


        public static string AppName = "ZIMLApp";


        // OAuth
        // For Google login, configure at https://console.developers.google.com/
        public static string iOSClientId = "410933976372-028pmriq6f70qnkn3saul2i9tb2l98nq.apps.googleusercontent.com";

        public static string AndroidClientId = "1080350791337-ijtadkrqv367jllsfkfplgv6slq4i3jo.apps.googleusercontent.com";


        // These values do not need changing
        public static string Scope = "https://www.googleapis.com/auth/userinfo.email";

        public static string AuthorizeUrl = "https://accounts.google.com/o/oauth2/auth";

        public static string AccessTokenUrl = "https://www.googleapis.com/oauth2/v4/token";

        public static string UserInfoUrl = "https://www.googleapis.com/oauth2/v2/userinfo";

        // Set these to reversed iOS/Android client ids, with :/oauth2redirect appended
        public static string iOSRedirectUrl = "com.googleusercontent.apps.705173625703-iqoj1l1l81c19plbc58vifndug1cju0i:/oauth2redirect";

        public static string AndroidRedirectUrl = "com.googleusercontent.apps.1080350791337-ijtadkrqv367jllsfkfplgv6slq4i3jo:/oauth2redirect";





    }
}

﻿using System;
using Plugin.Settings;
using Plugin.Settings.Abstractions;

namespace ZIMLApp.Classes.Utility
{
    public class Preference
    {
        private static ISettings AppSettings
        {
            get
            {
                if (CrossSettings.IsSupported)
                    return CrossSettings.Current;

                return null; // or your custom implementation 
            }
        }

        public static bool IsUserLoggedIn
        {
            get => AppSettings.GetValueOrDefault("IsUserLoggedIn", false);
            set => AppSettings.AddOrUpdateValue("IsUserLoggedIn", value);
        }

        public static bool IsLoginWithEmail
        {
            get => AppSettings.GetValueOrDefault("IsLoginWithEmail", false);
            set => AppSettings.AddOrUpdateValue("IsLoginWithEmail", value);
        }

        public static bool IsProductWalkthroughDone
        {
            get => AppSettings.GetValueOrDefault("IsProductWalkthroughDone", false);
            set => AppSettings.AddOrUpdateValue("IsProductWalkthroughDone", value);
        }

        public static bool IsNotificationAllowed
        {
            get => AppSettings.GetValueOrDefault("IsNotificationAllowed", true);
            set => AppSettings.AddOrUpdateValue("IsNotificationAllowed", value);
        }

        public static string FirstName
        {
            get => AppSettings.GetValueOrDefault("FirstName", "");
            set => AppSettings.AddOrUpdateValue("FirstName", value);
        }

        public static string LastName
        {
            get => AppSettings.GetValueOrDefault("LastName", "");
            set => AppSettings.AddOrUpdateValue("LastName", value);
        }

        public static string EmailId
        {
            get => AppSettings.GetValueOrDefault("EmailId", "");
            set => AppSettings.AddOrUpdateValue("EmailId", value);
        }

        public static string AccessToken
        {
            get => AppSettings.GetValueOrDefault("AccessToken", "");
            set => AppSettings.AddOrUpdateValue("AccessToken", value);
        }

        public static string DeviceId
        {
            get => AppSettings.GetValueOrDefault("DeviceId", "");
            set => AppSettings.AddOrUpdateValue("DeviceId", value);
        }
        public static string PushId
        {
            get => AppSettings.GetValueOrDefault("PushId", "");
            set => AppSettings.AddOrUpdateValue("PushId", value);
        }
        public static string UploadProfileUrl
        {
            get => AppSettings.GetValueOrDefault("UploadProfileUrl", "");
            set => AppSettings.AddOrUpdateValue("UploadProfileUrl", value);
        }

        public static string FacebookShareURL
        {
            get => AppSettings.GetValueOrDefault("FacebookShareURL", "");
            set => AppSettings.AddOrUpdateValue("FacebookShareURL", value);
        }
    }
}

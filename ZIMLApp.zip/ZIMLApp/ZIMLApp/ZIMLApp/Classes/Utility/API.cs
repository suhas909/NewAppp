﻿using System;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using ZIMLApp.Classes.Model;
using System.Net;
namespace ZIMLApp.Classes.Utility
{
    /// <summary>
    /// Error type enum to check the error if it is a network error or any other error.
    /// </summary>
    public enum ErrorType
    {
        Network,
        other
    }
    /// <summary>
    /// A common class to communicate with server APIs
    /// </summary>
    public class API
    {
        /// <summary>
        /// delegate for Success response.
        /// </summary>
        public delegate void Success(object content);
        /// <summary>
        /// delegate for Failure response.
        /// </summary>
        public delegate void Failure(string message, ErrorType errorType);

        /// <summary>
        /// Gets the response from server. This is a common method to call the API.
        /// </summary>
        /// <param name="url"> URL for the API.</param>
        /// <param name="param">Request Parameter.</param>
        /// <param name="success">Success callback block.</param>
        /// <param name="failure">Failure callback block.</param>
        public static async void GetResponseFromServer(string url, RequestParam param, Success success, Failure failure)
        {
            // Check network status  
            if (NetworkCheck.IsInternet())  
            {
                //  https://github.com/xamarin/xamarin-android/issues/6351#issuecomment-932944425
                var clienthandler = Xamarin.Forms.DependencyService.Get<ZIMLApp.Interfaces.IMyOwnNetService>().GetHttpClientHandler();
                var client = new HttpClient( clienthandler);
                var json = JsonConvert.SerializeObject(param);
                Debug.WriteLine("RequestParam"+json);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                try
                {
                    var response = await client.PostAsync(url, content);
                    string responseJsonStr = await response.Content.ReadAsStringAsync(); //Getting response 
                    Debug.WriteLine("response Json -> " + url + "\n" + responseJsonStr);
                    ResponseJson responseJson = new ResponseJson();
                    if (responseJsonStr != "")
                    {
                        responseJson = JsonConvert.DeserializeObject<ResponseJson>(responseJsonStr);
                        if (responseJson.status == "success")
                        {
                            success(responseJson.contents);
                        }
                        else
                        {
                            string message = responseJson.message;
                            failure(message, ErrorType.other);
                        }
                    }

                }
                catch (Exception ex)
                {
                    failure("Somthing went wrong.", ErrorType.other);
                    Debug.WriteLine("error" + ex.Message);
                    Debug.WriteLine("error" +  ex.StackTrace);
                }
            }  
            else
            {
                failure("Please check your internet connection and try again.", ErrorType.Network);
            }
        
        }
    }
}

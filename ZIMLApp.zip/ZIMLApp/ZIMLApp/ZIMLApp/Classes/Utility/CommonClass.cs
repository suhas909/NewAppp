﻿using System;
using System.Text.RegularExpressions;
using Xamarin.Forms;

namespace ZIMLApp.Classes.Utility
{
    /// <summary>
    /// This class contains all the utility methods. All the methods are static and used throughout the project.
    /// </summary>
    public class CommonClass
    {
        /// <summary>
        /// This method create a common webview source to create the loader view.
        /// </summary>
        /// <returns>The loader web view source.</returns>
        public static WebViewSource GetLoaderWebViewSource()
        {
            var source = new HtmlWebViewSource()
            {
                Html = String.Format(@"<html><body style='background: #FFFFFF;'><img src='loader.gif'/></body></html>")
            };
            source.BaseUrl = DependencyService.Get<IBaseUrl>().Get();
            return source;
        }

        /// <summary>
        /// This method used for validate the email string.
        /// </summary>
        /// <returns><c>true</c>, if email string is valid, <c>false</c> otherwise.</returns>
        /// <param name="emailStr">Email string to validate</param>
        public static bool IsEmailValid(string emailStr)
        {
            if (emailStr == null) { return false; }

            if (Regex.Match(emailStr, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$").Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// This method used for validate the password string.
        /// </summary>
        /// <returns><c>true</c>, if password string is valid, <c>false</c> otherwise.</returns>
        /// <param name="password">Password string to validate</param>
        public static bool IsPasswordValid(string password)
        {
            if (password == null) { return false; }

            if (Regex.Match(password, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,15}$").Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// This method used for validate the user name string.
        /// </summary>
        /// <returns><c>true</c>, if valid string for name, <c>false</c> otherwise.</returns>
        /// <param name="name">Name string to validate</param>
        public static bool isValidStringForName(string name)
        {
            if (string.IsNullOrEmpty(name)) { return false; }

            if (Regex.Match(name, @"^[0-9A-Za-z ]+$").Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// This method used to gets the profile photo URL. 
        /// </summary>
        /// <returns>If user logged in this method return a url string otherwise return empty string..</returns>
        public static string getProfilePhotoUrl()
        {
            // Eg:  https://zimlapp.areteem.org/api/images/user-profile.php?access_device_id=33&access_auth_key=I0MIB2iQwE4skqnwcYOAjsbw8yuHori6
            if (string.IsNullOrEmpty(Preference.DeviceId) || string.IsNullOrEmpty(Preference.AccessToken))
            {
                return "";
            }
            string url = Constants.baseURL + "/api/images/user-profile.php?access_device_id=" + Preference.DeviceId + "&access_auth_key=" + Preference.AccessToken;
            return url;
        }

        /// <summary>
        /// This method used to gets the proper HTML Content. As we are showing questions on the webview we need to formate the html which we are getting from the server so that we can show the math symbols. We used MathJax.js (2.7.5) for that purpose.
        /// </summary>
        /// <returns>The formated HTML Content for a question.</returns>
        /// <param name="html">The HTML Content for a question.</param>
        public static string getHTMLContent(string html)
        {

            string htmlData = "<!DOCTYPE html>";
            htmlData = htmlData + "<html>";
            htmlData = htmlData + "<head>";
            htmlData = htmlData + "<link rel='stylesheet' type='text/css' href='style.css'/>";
            htmlData = htmlData + "<meta charset='utf-8'>";
            htmlData = htmlData + "<meta name='viewport' content='width = device-width'>";
            htmlData = htmlData + "<script type='text/x-mathjax-config'> MathJax.Hub.Config({showProcessingMessages:false,showMathMenu: false,messageStyle: 'none',tex2jax: {inlineMath: [['$','$']] }}) </script>";
            htmlData = htmlData + "<script type='text/javascript' async src='https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-MML-AM_CHTML' async></script>";
            htmlData = htmlData + "</head>";
            htmlData = htmlData + "<body>";
            htmlData = htmlData + "<p>";

            htmlData = htmlData + html;
            htmlData = htmlData + "</p>";
            htmlData = htmlData + "</body>";
            htmlData = htmlData + "</html>";

            //string htmlData = "<!DOCTYPE HTML>";
            //htmlData = htmlData + "<html>";
            //htmlData = htmlData + "<head>";
            //htmlData = htmlData + "<meta name='viewport' content='width = device - width'>";
            //htmlData = htmlData + "<script type='text/x-mathjax-config'> MathJax.Hub.Config({showProcessingMessages:false,messageStyle: 'none',tex2jax: {inlineMath: [['$','$']] }}) </script>";
            //htmlData = htmlData + "<script type='text/javascript' async src='https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-MML-AM_CHTML' async></script>";

            //htmlData = htmlData + "</head>";
            //htmlData = htmlData + "<body>";
            //htmlData = htmlData + "<p>";
            //htmlData = htmlData + html;
            //htmlData = htmlData + "</p>";
            //htmlData = htmlData + "</body>";
            //htmlData = htmlData + "</html>";
            return htmlData;
        }

        /// <summary>
        /// Strips the html.
        /// </summary>
        /// <returns>The striped string.</returns>
        /// <param name="input">Input string to strip</param>
        public static string StripHTML(string input)
        {
            //Regex regex = new Regex(@"</?\w+((\s+\w+(\s*=\s*(?:"".*?""|'.*?'|[^'"">\s]+))?)+\s*|\s*)/?>", RegexOptions.Singleline);
            //return regex.Replace(input, String.Empty);

            var newInput = input.Replace("</p><p>", "</p>\n<p>");
            return Regex.Replace(newInput, "<.*?>", String.Empty);

        }
        /// <summary>
        /// Take a long value and convert that value into DateTime object. 
        /// </summary>
        /// <returns>The DateTime object for the given time value.</returns>
        /// <param name="unixTime">A long value to convert into DateTime.</param>
        public static DateTime FromUnixTime(long unixTime)
        {
            return epoch.AddSeconds(unixTime);
        }

        /// <summary>
        /// A DateTime offset which used to convert unix time (A long value) to a DateTime object.
        /// </summary>
        private static readonly DateTime epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
    }
}

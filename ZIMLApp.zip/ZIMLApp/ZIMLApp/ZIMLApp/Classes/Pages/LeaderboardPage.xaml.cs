﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages the Leaderboard page.
    /// </summary>
    public partial class LeaderboardPage : ContentPage
    {
        private List<Student> StudentsList = new List<Student>();

        public LeaderboardPage()
        {
            InitializeComponent();
            LoaderView.IsVisible = false;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            NavigationPage navigationPage = (NavigationPage)((HomePage)Application.Current.MainPage).Detail;
            navigationPage.BarTextColor = Color.Black;
            HomePage home = (HomePage)Application.Current.MainPage;
            if (home != null)
            {
                home.IsGestureEnabled = true;
            }
            GetLeaderboardDetail();
        }

        protected override void OnDisappearing()
        {
            if (Application.Current.MainPage is HomePage)
            {
                base.OnDisappearing();
                HomePage home = (HomePage)Application.Current.MainPage;
                if (home != null)
                {
                    home.IsGestureEnabled = false;
                }
            }

        }
        /// <summary>         /// This method manages the Try again button clicked, And try to reload the data.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void TryAgain_Clicked(object sender, System.EventArgs e)
        {
            LoaderView.IsVisible = true;
            ErrorView.IsVisible = false;
            GetLeaderboardDetail();
        }
        /// <summary>
        /// Gets the leaderboard detail from API.
        /// </summary>
        void GetLeaderboardDetail()
        {
            LoaderView.IsVisible = true;

            API.GetResponseFromServer(Constants.leaderboardAPI, new RequestParam(), (content) =>
            {
                StudentsList = JsonConvert.DeserializeObject<List<Student>>(content.ToString());
                LoaderView.IsVisible = false;
                int i = 1;
                foreach (Student s in StudentsList)
                {
                    s.position = i.ToString("00");
                    i++;
                }
                LeaderboardList.ItemsSource = StudentsList;

            }, (message, errorType) =>
            {
                LoaderView.IsVisible = false;
                ErrorView.IsVisible = true;
                if (errorType == ErrorType.Network)
                {
                    ErrorTitle.Text = Constants.NetworkErrorTitle;
                    ErrorMessage.Text = Constants.NetworkErrorMessage;
                    ActionButton.Text = "Try again";
                }
                else
                {
                    ErrorTitle.Text = Constants.ServerErrorTitle;
                    ErrorMessage.Text = Constants.ServerErrorMessage;
                    ActionButton.Text = "Refresh";
                }
            });
        }
    }
}

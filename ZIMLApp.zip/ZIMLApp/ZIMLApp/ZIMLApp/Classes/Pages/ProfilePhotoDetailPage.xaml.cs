﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Plugin.Media;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;
using Plugin.Media.Abstractions;
//TODO Suhas Picker changes
namespace ZIMLApp.Classes.Pages
{

    /// <summary>
    /// This class manages to show the Profile picture preview page and also manages edit and delete the profile picture.
    /// </summary>
    public partial class ProfilePhotoDetailPage : ContentPage
    {
       // IImagePickerService _imagePickerService;

        public ProfilePhotoDetailPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            NavigationPage.SetBackButtonTitle(this, " ");
            //loaderWebView.Source = CommonClass.GetLoaderWebViewSource();
           // _imagePickerService = DependencyService.Get<IImagePickerService>();
            profileImg.HeightRequest = Application.Current.MainPage.Width;
            profileImg.WidthRequest = Application.Current.MainPage.Width;
            profileImg.Source = CommonClass.getProfilePhotoUrl();
            AddGesture();
        }

		protected override void OnAppearing()
		{
            base.OnAppearing();
            if (Device.RuntimePlatform == Device.Android) 
            {
                LoaderView.IsVisible = false;
            }

            //profileImg.HeightRequest = Application.Current.MainPage.Width;
            //profileImg.WidthRequest = Application.Current.MainPage.Width;
            //profileImg.Source = CommonClass.getProfilePhotoUrl();
		}

        public void AddGesture()
        {
            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += (s, e) =>
            {
                this.Navigation.PopAsync();
            };
            imgBack.GestureRecognizers.Add(tapGestureRecognizer);
            tapGestureRecognizer.NumberOfTapsRequired = 1;

            var tapGestureRecognizerCamera = new TapGestureRecognizer();
            tapGestureRecognizerCamera.Tapped += async (s, e) =>
            {

                if (Device.RuntimePlatform == Device.Android) 
                {
                    LoaderView.IsVisible = true;
                   // var imageSource = await _imagePickerService.PickImageAsync();

                    //if (imageSource != null) // it will be null when user cancel
                    //{
                    //    var stream = await _imagePickerService.ImageSourceUtility.ToJpegStreamAsync(imageSource);

                    //    var array = ReadFully(stream);
                    //    await Upload(array);
                    //    //profileImg.Source = imageSource;
                    //}
                    //else
                    //{
                    //    LoaderView.IsVisible = false;
                    //}
                }
                else
                {
                    var action = await DisplayActionSheet(null, "Cancel", null, "Take Photo", "Choose Photo");
                    switch(action)
                    {
                        case "Take Photo":
                            TakePhoto();
                            break;
                        case "Choose Photo":
                            ChoosePhoto();
                            break;
                    }
                }
            };
            editImg.GestureRecognizers.Add(tapGestureRecognizerCamera);
            tapGestureRecognizerCamera.NumberOfTapsRequired = 1;

            var tapGestureRecognizerClear = new TapGestureRecognizer();
            tapGestureRecognizerClear.Tapped += async (s, e) =>
            {
                bool value = await DisplayAlert(null, "Are you sure you want to remove profile photo?", "Yes", "No");
                if (value)
                {
                    deleteImage();
                }
            };
            deleteImg.GestureRecognizers.Add(tapGestureRecognizerClear);
            tapGestureRecognizerClear.NumberOfTapsRequired = 1;

        }
        /// <summary>
        /// This method used to takes the photo from camera.
        /// </summary>
        async void TakePhoto()
        {
            await CrossMedia.Current.Initialize();
    
            if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakePhotoSupported)
            {
                return;
            }

            var file = await CrossMedia.Current.TakePhotoAsync(new Plugin.Media.Abstractions.StoreCameraMediaOptions());

            if (file == null)
                return;
            
            var source = ImageSource.FromStream(() =>
            {
                var stream = file.GetStream();
                return stream;
            });

            var page = new ImageCropPage() { ImageSourceForCrop = source };
            page.DoneCropping += Page_DoneCropping;

            await Navigation.PushAsync(page); 
        }
        /// <summary>
        /// This method used to choose the photo from the device.
        /// </summary>
        async void ChoosePhoto()
        {
            await CrossMedia.Current.Initialize();

            //if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakePhotoSupported)
            //{
            //    return;
            //}

            var file = await CrossMedia.Current.PickPhotoAsync();

            if (file == null)
                return;

            var source = ImageSource.FromStream(() =>
            {
                var stream = file.GetStream();
                return stream;
            });

            var page = new ImageCropPage() { ImageSourceForCrop = source };
            page.DoneCropping += Page_DoneCropping;

            await Navigation.PushAsync(page);

        }

        async void Page_DoneCropping(object sender, DoneCroppingEventArgs e)
        {
            if (e.stream != null)
            {
                var array = ReadFully(e.stream);
                await Upload(array);
            }
        }



        public static byte[] ReadFully(Stream input)
        {
            byte[] buffer = new byte[16 * 1024];
            using (MemoryStream ms = new MemoryStream())
            {
                int read;
                while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }
                return ms.ToArray();
            }
        }
        /// <summary>
        /// This method used to upload the image data.
        /// </summary>
        /// <param name="image">Image data</param>
        public async Task Upload(byte[] image)
        {
            if (!NetworkCheck.IsInternet())  
            {
                await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage , "Ok");
                LoaderView.IsVisible = false;
                return;
            }

            LoaderView.IsVisible = true;


            using (var httpClient = new HttpClient())
            {
                MultipartFormDataContent multipartFormDataContent = new MultipartFormDataContent();
                var imageContent = new ByteArrayContent(image, 0, image.Length);
                imageContent.Headers.ContentType = MediaTypeHeaderValue.Parse("multipart/form-data");
                multipartFormDataContent.Add(imageContent, "repo_upload_file", "user_profile.jpg");

                StringContent userIdContent = new StringContent(Preference.DeviceId);
                StringContent tokenContent = new StringContent(Preference.AccessToken);
                multipartFormDataContent.Add(userIdContent, "access_device_id");
                multipartFormDataContent.Add(tokenContent, "access_auth_key");

                try
                {
                    var response = await httpClient.PostAsync(Constants.updateProfilePhotoAPI, multipartFormDataContent);
                    var content = response.Content;
                    var jsonString = await content.ReadAsStringAsync();
                    LoaderView.IsVisible = false;
                    Debug.WriteLine($"json response : {jsonString}");

                    UpdateProfilePhotoResponse responseJson = JsonConvert.DeserializeObject<UpdateProfilePhotoResponse>(jsonString);
                    if (responseJson.status == "error")
                    {
                        await DisplayAlert(null, responseJson.message, "Ok");
                    }
                    else
                    {
                        await DisplayAlert(null, "Profile Image updated successfully. Please sign in to see the changes.", "Ok");
                    }
                }
                catch (Exception ex)
                {
                    
                    await DisplayAlert(null, "Somthing went wrong. Please try again later.", "Ok");
                    Debug.WriteLine("error" + ex.Message);
                    Debug.WriteLine("error" + ex.StackTrace);
                    LoaderView.IsVisible = false;
                }
            }
        }
        /// <summary>
        /// This method used to deletes the profile picture.
        /// </summary>
        public void deleteImage()
        {
            LoaderView.IsVisible = true;
            API.GetResponseFromServer(Constants.clearProfilePhotoAPI, new RequestParam(), async (content) => {
                LoaderView.IsVisible = false;
                await DisplayAlert(null, "Profile photo removed successfully. Please sign in to see the changes.", "Ok");
            }, async (message, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
                else { await DisplayAlert(null, message, "Ok"); }
            });
        }
	}
}

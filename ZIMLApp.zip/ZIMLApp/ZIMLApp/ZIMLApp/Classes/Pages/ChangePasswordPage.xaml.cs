﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

using ZIMLApp.Classes.Utility;
using ZIMLApp.Classes.Model;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages the Change Password functionality.
    /// </summary>
    public partial class ChangePasswordPage : ContentPage
    {
        public ChangePasswordPage()
        {
            InitializeComponent();
        }
        /// <summary>
        /// This method calls when Set new password button clicks.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void SetNewPwd_Clicked(object sender, System.EventArgs e)
        {
            if (CheckValidations())
            {
                ChangePasswordParams changePasswordParams = new ChangePasswordParams();
                changePasswordParams.new_password = newPwd.Text;
                changePasswordParams.email_id = Preference.EmailId;
                changePasswordParams.password = currentPwd.Text;
                ChangePassword(changePasswordParams);
            }
        }
        /// <summary>
        /// This method manages Changes password API call.
        /// </summary>
        /// <param name="param">Change password parameters. </param>
        public void ChangePassword(ChangePasswordParams param)
        {
            LoaderView.IsVisible = true;
            API.GetResponseFromServer(Constants.ChangePasswordAPI, param, async (content) =>
            {
                LoaderView.IsVisible = false;
                await DisplayAlert(null, "Password Changed successfully", "Ok");
                await Navigation.PopAsync();

            }, async (message, errorType) =>
            {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
                else if (message.ToLower() == "password mismatch"){await DisplayAlert(null, "Your password was incorrect.", "Ok");}
                else { await DisplayAlert(null, message, "Ok"); }
            });
        }

        /// <summary>
        /// This method Checks the validations which are required for change password.
        /// </summary>
        /// <returns><c>true</c>, if validations was checked, <c>false</c> otherwise.</returns>
        private bool CheckValidations()
        {
            bool returnValue = true;

            if (string.IsNullOrEmpty(currentPwd.Text))
            {
                ErrorCurrentPwd.Text = "Please enter current password";
                returnValue = false;
            }
            else
            {
                ErrorCurrentPwd.Text = "";
            }

            if (string.IsNullOrEmpty(newPwd.Text))
            {
                ErrorNewPwd.Text = "Please enter new password";
                returnValue = false;
            }
            else if (!CommonClass.IsPasswordValid(newPwd.Text))
            {
                ErrorNewPwd.Text = "The password must have at least 8 characters, at least 1 digit(s), at least 1 upper case letter(s), at least 1 lower case letter(s)";
                returnValue = false;
            }
            else
            {
                ErrorNewPwd.Text = "";
            }

            if (string.IsNullOrEmpty(confirmPwd.Text))
            {
                ErrorConfirmPwd.Text = "Please enter confirm password";
                returnValue = false;
            }
            else if (newPwd.Text != confirmPwd.Text)
            {
                ErrorConfirmPwd.Text = "New password and Confirm password doesn't match.";//"Password mismatch";
                returnValue = false;
            }
            else
            {
                ErrorConfirmPwd.Text = "";
            }


            return returnValue;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages to show the Product walkthrough or help page.
    /// </summary>
    public partial class ProductWalkthroughPage : ContentPage
    {
        public bool IsFromHelp = false;
        public ProductWalkthroughPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            CarouselView.ItemsSource = new List<ProductWalkthroughView>(){
                new ProductWalkthroughView("Daily Magic Spells", "One problem a day for great practice. View step by step solutions.", "daily_magic_spell.png"),
                new ProductWalkthroughView("Monthly Contests", "Compete with the world. Level up solving skills while having fun.", "monthly_contests.png"),
                new ProductWalkthroughView("Practice Mode", "Full solution to learn and improve from ZIML & AMC series contests.", "practice.png"),
                new ProductWalkthroughView("Discussion Forum", "Forums for discussion and challenging Weekly Brain Potions.", "forum.png")
            };
        }

		protected override void OnAppearing()
		{
            base.OnAppearing();
            if (IsFromHelp) GetStarted.Text = "Back";
		}

		void GetStarted_Clicked(object sender, System.EventArgs e)
        {
            Preference.IsProductWalkthroughDone = true;
            if (IsFromHelp) Navigation.PopAsync();
            else Application.Current.MainPage = new NavigationPage(new SplashScreenPage()); 
        }
    }
}

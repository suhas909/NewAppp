﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages to show the Practice info page.
    /// </summary>
    public partial class PracticeInfoPage : ContentPage
    {
        public PracticeInfoPage()
        {
            InitializeComponent();
        }
    }
}

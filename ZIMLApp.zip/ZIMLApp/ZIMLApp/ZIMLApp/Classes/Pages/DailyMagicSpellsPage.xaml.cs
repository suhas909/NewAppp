﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using System.Collections.ObjectModel;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Diagnostics;
using System.Text.RegularExpressions;
using Xamarin.Forms.Internals;
using System.Linq;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages to show Daily magic spells list page.
    /// </summary>
    public partial class DailyMagicSpellsPage : ContentPage
    {
        
        private ObservableCollection<MagicSpells> _DMSListdata;
        private MagicSpells _recentMagicSpell;
        private DailyMagicSpellsList dailyMagicSpellsList;

        public DailyMagicSpellsPage()
        {
            InitializeComponent();
            //loaderWebView.Source = CommonClass.GetLoaderWebViewSource();
            NavigationPage.SetBackButtonTitle(this, " ");
            LoaderView.IsVisible = true;
            AddToolbarItems();
            GetDailyMagicSpellsList(new DailyMagicSpellsListParam());
        }

        private void AddToolbarItems()
        {
            var share = new ToolbarItem
            {
                //Command = ViewModel.LoadItemsCommand,
                Icon = "ic_share_black.png",
                Priority = 0

            };
            share.Command = new Command(() =>
            {
                var url = string.Empty;
                // string.IsNullOrEmpty(Preference.FacebookShareURL) ? Constants.baseURL + "/" : Preference.FacebookShareURL
                if (string.IsNullOrEmpty(Preference.FacebookShareURL))
                {
                    url = Constants.baseURL;
                }
                else
                {
                    url = Preference.FacebookShareURL;
                }
                DependencyService.Get<IShare>().Share("Ziml App", "https://ziml.areteem.org/ziml/dailymagicspells.php");
                //DependencyService.Get<IShare>().Share("Ziml App", Constants.QuizBaseUrl+ QuestionId);
            });
            ToolbarItems.Add(share);
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            HomePage home = (HomePage)Application.Current.MainPage;
            NavigationPage navigationPage = (NavigationPage)home.Detail;
            if (home != null && navigationPage.Navigation.NavigationStack.Count == 1)
            {
                home.IsGestureEnabled = true;
            }

        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            HomePage home = (HomePage)Application.Current.MainPage;
            NavigationPage navigationPage = (NavigationPage)home.Detail;
            if (home != null && navigationPage.Navigation.NavigationStack.Count == 1)
            {
                home.IsGestureEnabled = false;
            }
        }
        /// <summary>
        /// This mathod manages the API call for Gets daily magic spells list.
        /// </summary>
        /// <param name="param">Daily magic spells list API parameters.</param>
        public void GetDailyMagicSpellsList(DailyMagicSpellsListParam param)  
        {
            API.GetResponseFromServer(Constants.dailyMagicSpellsListAPI, param, HandleSuccess, HandleFailure);
        }
        /// <summary>
        /// Handles the success for Daily magic spells list API call.
        /// </summary>
        /// <param name="contents">Contents return from the API call.</param>
		void HandleSuccess(object contents)
        {   
            
            List<Record> list = JsonConvert.DeserializeObject<List<Record>>(contents.ToString());
            dailyMagicSpellsList = new DailyMagicSpellsList(list);
            _DMSListdata = new ObservableCollection<MagicSpells>();
            MagicSpells magicSpells;
            foreach (Record record in dailyMagicSpellsList.records)
            {
                Debug.WriteLine("print this -> " + record);
                char[] separators = new char[] { '-' };
                string[] dateName = record.name.Split(separators);

                magicSpells = new MagicSpells();
                magicSpells.Date = dateName[0];
                if (dateName.Length == 2) magicSpells.Name = dateName[1];
                else magicSpells.Name = "";
                magicSpells.DateName = record.name;
                magicSpells.QuestionId = record.id;

                _DMSListdata.Add(magicSpells);

            }
            _recentMagicSpell = _DMSListdata.First();
            Name.Text = _recentMagicSpell.Name;
            Date.Text = _recentMagicSpell.Date;
            _DMSListdata.RemoveAt(0);
            DMSList.ItemsSource = _DMSListdata;
            LoaderView.IsVisible = false;

        }
        /// <summary>
        /// Handles the failure for Daily magic spells list API call.
        /// </summary>
        /// <param name="message">Message related to the failure.</param>
        /// <param name="errorType">Error type.</param>
        void HandleFailure(string message, ErrorType errorType)
        {
            LoaderView.IsVisible = false;
            ErrorView.IsVisible = true;
            if (errorType == ErrorType.Network){
                ErrorTitle.Text = Constants.NetworkErrorTitle;
                ErrorMessage.Text = Constants.NetworkErrorMessage;
                ActionButton.Text = "Try again";
            }
            else {
                ErrorTitle.Text = Constants.ServerErrorTitle;
                ErrorMessage.Text = Constants.ServerErrorMessage;
                ActionButton.Text = "Refresh";
            }
        }
        /// <summary>
        /// This method manages the row selection event and navigate the detail page for related Daily magic spell.
        /// </summary>
        /// <param name="sender">Row object</param>         /// <param name="e">Event arguments.</param>
        async void RowSelected(object sender, System.EventArgs e)
        {
            MagicSpells selectedMagicSpells = (MagicSpells)DMSList.SelectedItem;
            Debug.WriteLine("row selected. " + selectedMagicSpells);
            QuestionPage questionPage = new QuestionPage();
            questionPage.QuestionName = selectedMagicSpells.DateName;
            questionPage.QuestionId = selectedMagicSpells.QuestionId;
            Debug.WriteLine("questionPage " + questionPage);
            await Navigation.PushAsync(questionPage);
        }
        /// <summary>
        /// This button manages the click of start button for recent Daily meagic spell
        /// </summary>
        /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        async void Start_Clicked(object sender, System.EventArgs e)
        {
            QuestionPage questionPage = new QuestionPage();
            questionPage.QuestionName = _recentMagicSpell.DateName;
            questionPage.QuestionId = _recentMagicSpell.QuestionId;
            Debug.WriteLine("questionPage " + questionPage);
            await Navigation.PushAsync(questionPage);
        }

        /// <summary>
        /// This method manages the Try again button clicked, And try to reload the data.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void TryAgain_Clicked(object sender, System.EventArgs e)
        {
            LoaderView.IsVisible = true;
            ErrorView.IsVisible = false;
            GetDailyMagicSpellsList(new DailyMagicSpellsListParam());
        }
    }
    /// <summary>
    /// Daily Magic spell object class.
    /// </summary>
    public class MagicSpells : Object
    {
        public string Name { get; set; }
        public string Date { get; set; }
        public string DateName { get; set; }
        public string QuestionId { get; set; }

        public bool IsShadowEnable { get { return isShadowEnable(); } }

        private bool isShadowEnable()
        {
            if (Device.RuntimePlatform == Device.iOS)
            {
                return false;
            }
            return true;
        }
    }

}

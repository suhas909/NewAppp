﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Utility;
using System.Diagnostics;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages to show the Privacy policy page.
    /// </summary>
    public partial class PrivacyPolicyPage : ContentPage
    {
        public PrivacyPolicyPage()
        {
            NavigationPage.SetBackButtonTitle(this, " ");
            InitializeComponent();
            contentWebView.Source = Constants.privacyPolicyPageURL;
            contentWebView.Navigating += (s, e) =>
            {
                if (e.Url.StartsWith("http") && e.Url != Constants.privacyPolicyPageURL)
                {
                    try
                    {
                        var uri = new Uri(e.Url);
                        Device.OpenUri(uri);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex);
                    }

                    e.Cancel = true;
                }
            };
        }
    }
}

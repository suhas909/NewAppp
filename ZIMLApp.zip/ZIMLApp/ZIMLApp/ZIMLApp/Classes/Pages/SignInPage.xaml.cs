﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using System.Diagnostics;
using ZIMLApp.Classes.Utility;
using Newtonsoft.Json;
using Plugin.FacebookClient;
using Newtonsoft.Json.Linq;
using Xamarin.Auth;
using System.Linq;
using ZIMLApp.Helpers;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages the sign in process in the app. Also manages the social sign-in and sign-up process.
    /// </summary>
    public partial class SignInPage : ContentPage
    {
        Account account;
        
        public SignInPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            initView();
            // Google config
            //var accountStore = Xamarin.Essentials.SecureStorage.
            
            Debug.WriteLine(new SignInRequestParam().ToString());
        }
        private async void initView()
        {
            var accountlist = await SecureStorageAccountStore.FindAccountsForServiceAsync(Constants.AppName);
            account = accountlist.FirstOrDefault();
            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += (s, e) =>
            {
                if (Navigation.NavigationStack.Count > 1)
                {
                    this.Navigation.PopAsync();
                }
                else
                {
                    Application.Current.MainPage = new NavigationPage(new SplashScreenPage());
                }

            };
            imgBack.GestureRecognizers.Add(tapGestureRecognizer);
            tapGestureRecognizer.NumberOfTapsRequired = 1;

            var forgotPwdGR = new TapGestureRecognizer();
            forgotPwdGR.Tapped += (s, e) =>
            {
                this.Navigation.PushModalAsync(new ForgotPasswordPage());
            };
            txtForgotPassword.GestureRecognizers.Add(forgotPwdGR);
            forgotPwdGR.NumberOfTapsRequired = 1;


            var visibilityImgGR = new TapGestureRecognizer();
            visibilityImgGR.Tapped += (s, e) =>
            {
                if (edtPassword.IsPassword == true)
                {
                    edtPassword.IsPassword = false;
                    visibilityImg.Source = "ic_visibility_off.png";
                }
                else
                {
                    edtPassword.IsPassword = true;
                    visibilityImg.Source = "ic_visibility.png";
                }
            };

            visibilityImg.GestureRecognizers.Add(visibilityImgGR);
            visibilityImgGR.NumberOfTapsRequired = 1;

            var facebookImgGR = new TapGestureRecognizer();
            facebookImgGR.Tapped += (s, e) =>
            {

                SignInWithFacebook();

            };
            facebookImg.GestureRecognizers.Add(facebookImgGR);
            facebookImgGR.NumberOfTapsRequired = 1;

            var googleImgGR = new TapGestureRecognizer();
            googleImgGR.Tapped += (s, e) =>
            {

                SignInWithGoogle();

            };
            googleImg.GestureRecognizers.Add(googleImgGR);
            googleImgGR.NumberOfTapsRequired = 1;

            //loaderWebView.Source = CommonClass.GetLoaderWebViewSource();
        }
        /// <summary>
        /// This method manages Sign in with facebook process.
        /// </summary>
        async public void SignInWithFacebook()
        {
            if (!NetworkCheck.IsInternet())
            {
                await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
                return;
            }

            LoaderView.IsVisible = true;
            if (CrossFacebookClient.Current.IsLoggedIn)
            {
                CrossFacebookClient.Current.Logout();
            }
            try
            {
                var jsonData = await CrossFacebookClient.Current.RequestUserDataAsync(new string[] { "id", "email", "first_name", "last_name", "picture" }, new string[] { "email" });
                if (jsonData.Status == FacebookActionStatus.Completed)
                {
                    Debug.WriteLine(jsonData.Data.ToString());
                    Debug.WriteLine("ActiveToken==>" + CrossFacebookClient.Current.ActiveToken);
                    User user = null;
                    var data = JObject.Parse(jsonData.Data);
                    if (data != null)
                    {
                        user = new User();

                        user.user_type = UserType.facebook;
                        user.id = data["id"].ToString();
                        if (data.ContainsKey("email")) user.email_id = data["email"].ToString();
                        user.first_name = data["first_name"].ToString();
                        user.last_name = data["last_name"].ToString();
                        user.picture_url = data["picture"]["data"]["url"].ToString();
                        user.access_token = CrossFacebookClient.Current.ActiveToken;

                    }
                    ValidateAuthWithServer(user);
                }
                else if (jsonData.Status == FacebookActionStatus.Error)
                {
                    LoaderView.IsVisible = false;
                    Debug.WriteLine(jsonData.Message);
                }
                else
                {
                    LoaderView.IsVisible = false;
                }
            }
            catch(Exception e)
            {
                LoaderView.IsVisible = false;
                Debug.WriteLine(e.StackTrace);
            }

        }
        /// <summary>
        /// This method manages Sign in with google process.
        /// </summary>
        public async void SignInWithGoogle()
        {
            if (!NetworkCheck.IsInternet())  
            {
                await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
                return;
            }
            LoaderView.IsVisible = true;
            string clientId = null;
            string redirectUri = null;

            switch (Device.RuntimePlatform)
            {
                case Device.iOS:
                    clientId = Constants.iOSClientId;
                    redirectUri = Constants.iOSRedirectUrl;
                    break;

                case Device.Android:
                    clientId = Constants.AndroidClientId;
                    redirectUri = Constants.AndroidRedirectUrl;
                    break;
            }

            var authenticator = new OAuth2Authenticator(
                clientId,
                null,
                Constants.Scope,
                new Uri(Constants.AuthorizeUrl),
                new Uri(redirectUri),
                new Uri(Constants.AccessTokenUrl),
                null,
                true);

            authenticator.Completed += OnAuthCompleted;
            authenticator.Error += OnAuthError;

            AuthenticationState.Authenticator = authenticator;

            var presenter = new Xamarin.Auth.Presenters.OAuthLoginPresenter();
            presenter.Login(authenticator);
        }

        /// <summary>
        /// Call back on the success for google sign in
        /// </summary>
        async void OnAuthCompleted(object sender, AuthenticatorCompletedEventArgs e)
        {
            var authenticator = sender as OAuth2Authenticator;
            if (authenticator != null)
            {
                authenticator.Completed -= OnAuthCompleted;
                authenticator.Error -= OnAuthError;
            }
            if (e.IsAuthenticated)
            {
                Debug.WriteLine(e.Account.Properties["access_token"]);
                // If the user is authenticated, request their basic user data from Google
                // UserInfoUrl = https://www.googleapis.com/oauth2/v2/userinfo
                var request = new OAuth2Request("GET", new Uri(Constants.UserInfoUrl), null, e.Account);
                var response = await request.GetResponseAsync();
                User user = null;
                if (response != null)
                {
                    // Deserialize the data and store it in the account store
                    // The users email address will be used to identify data in SimpleDB
                    string userJson = await response.GetResponseTextAsync();
                    Debug.WriteLine(userJson);
                    //user = JsonConvert.DeserializeObject<User>(userJson);
                    var data = JObject.Parse(userJson);
                    if (data != null)
                    {
                        user = new User()
                        {
                            user_type = UserType.google,
                            id = data["id"].ToString(),
                            email_id = data["email"].ToString(),
                            first_name = data["given_name"]?.ToString(),
                            last_name = data["family_name"]?.ToString(),
                            picture_url = data["picture"].ToString(),
                            access_token = e.Account.Properties["access_token"]
                        };
                    }

                }

                await SecureStorageAccountStore.SaveAsync(e.Account, Constants.AppName);
                //await store.SaveAsync(account = e.Account, Constants.AppName);
                ValidateAuthWithServer(user);
            }
            else
            {
                LoaderView.IsVisible = false;
            }
        }

        /// <summary>
        /// Call back on the Error for google sign in
        /// </summary>
        void OnAuthError(object sender, AuthenticatorErrorEventArgs e)
        {
            var authenticator = sender as OAuth2Authenticator;
            if (authenticator != null)
            {
                authenticator.Completed -= OnAuthCompleted;
                authenticator.Error -= OnAuthError;
            }
            LoaderView.IsVisible = false;
            Debug.WriteLine("Authentication error: " + e.Message);
        }

        /// <summary>
        /// Validates the auth with server for google and facebook sign in.
        /// </summary>
        /// <param name="user">User object</param>
        public void ValidateAuthWithServer(User user)
        {
            if (user == null) 
            { 
                LoaderView.IsVisible = false;
                return; 
            }
            //if (string.IsNullOrEmpty(user.email_id))
            //{
            //    LoaderView.IsVisible = false;
            //    CreateAccountPage page = new CreateAccountPage();
            //    page.userData = user;
            //    Navigation.PushModalAsync(page);
            //    return;
            //}


            OAuthValidateRequestParam param = new OAuthValidateRequestParam();
            param.auth_id = user.id;
            param.access_token = user.access_token;
            param.email_id = user.email_id;
            if (user.user_type == UserType.facebook) param.auth_type = "facebook";
            else if (user.user_type == UserType.google) param.auth_type = "google";

            API.GetResponseFromServer(Constants.validateOAuthAPI, param, (content) => {
                var data = JObject.Parse(content.ToString());
                if (data != null)
                {
                    if (data.ContainsKey("login_token"))
                        LoginAuthWithServer(user.id, (string)data["login_token"]);
                    else if (string.IsNullOrEmpty(user.email_id) || string.IsNullOrEmpty(user.first_name) || string.IsNullOrEmpty(user.last_name))
                    {
                        LoaderView.IsVisible = false;
                        CreateAccountPage page = new CreateAccountPage();
                        page.userData = user;
                        page.registrationToken = (string)data["registration_token"];
                        Navigation.PushAsync(page);
                    } 
                    else if (data.ContainsKey("registration_token"))
                    {   
                        RegisterAuthWithServer(user, (string)data["registration_token"]); 
                    }
                        
                }
                else
                    LoaderView.IsVisible = false; 

            }, async (message, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network)
                    await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
                else
                    await DisplayAlert(null, message, "Ok");
            });
        }

        /// <summary>
        /// Login the auth with server for google and facebook sign in.
        /// </summary>
        /// <param name="auth_id">Auth identifier.</param>
        /// <param name="login_token">Login token.</param>
        public void LoginAuthWithServer(string auth_id, string login_token)
        {
            OAuthLoginRequestParam param = new OAuthLoginRequestParam()
            {
                auth_id = auth_id,
                login_token = login_token
            };

            API.GetResponseFromServer(Constants.loginOAuthAPI, param, (content) => {
                LoaderView.IsVisible = false;
                SignInDetail signInDetail = JsonConvert.DeserializeObject<SignInDetail>(content.ToString());
                Debug.WriteLine(signInDetail.first_name);
                SaveUserDataToPreference(signInDetail);
                if (!string.IsNullOrEmpty(Preference.PushId))
                    ValidateDeviceId();
                else 
                    Application.Current.MainPage = new HomePage();

            }, async (message, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network)
                    await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
                else
                    await DisplayAlert(null, message, "Ok");
            });
        }

        /// <summary>
        /// Register the auth with server for google and facebook sign up.
        /// </summary>
        /// <param name="user">User.</param>
        /// <param name="registration_token">Registration token.</param>
        public void RegisterAuthWithServer(User user, string registration_token)
        {
            CreateAccountParam param = new CreateAccountParam()
            {
                oauth_id = user.id,
                oauth_registration_token = registration_token,
                email_id = user.email_id,
                first_name = user.first_name,
                last_name = user.last_name,
                otp_successful_validation_token = "",
                password = user.access_token.Substring(10, 32)
            };

            API.GetResponseFromServer(Constants.createAccountAPI, param, (content) => {
                CreateAccountDetail createAccountDetail = JsonConvert.DeserializeObject<CreateAccountDetail>(content.ToString());
                Debug.WriteLine(createAccountDetail.access_token);
                SaveUserDataToPreference(createAccountDetail, user);
                if(!string.IsNullOrEmpty(user.picture_url)) Preference.UploadProfileUrl = user.picture_url;
                LoaderView.IsVisible = false;

                if (!string.IsNullOrEmpty(Preference.PushId))
                    ValidateDeviceId();
                else
                    Application.Current.MainPage = new HomePage();

            }, async (message, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network)
                    await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
                else
                    await DisplayAlert(null, message, "Ok");
            });
        }

        //async public void ShareWithFacebook()
        //{
        //    var imageSource = ImageSource.FromFile("avatar.png");

        //    if (imageSource != null) // it will be null when user cancel
        //    {
        //        var stream = await .ImageSourceUtility.ToJpegStreamAsync(imageSource);
        //        var array = ReadFully(stream);
        //        FacebookSharePhoto photo = new FacebookSharePhoto("Test for demo", byteArray);
        //        FacebookSharePhoto[] photos = new FacebookSharePhoto[] { photo };
        //        FacebookSharePhotoContent photoContent = new FacebookSharePhotoContent(photos);
        //        await CrossFacebookClient.Current.ShareAsync(photoContent);
        //    }

        //}


        /// <summary>         /// This method manages the Sign in button click.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        public void SignIn_Clicked(object sender, System.EventArgs e)
        {
            if (CheckValidations())
            {
                SignInRequestParam param = new SignInRequestParam();
                param.email_id = edtEmail.Text;
                param.password = edtPassword.Text;
                AuthenticateUser(param);
            }
        }

        /// <summary>
        /// Authenticates the user for in app sgin in.
        /// </summary>
        /// <param name="param">Sign In Request API Parameter.</param>
        public void AuthenticateUser(SignInRequestParam param)
        {
            LoaderView.IsVisible = true;
            API.GetResponseFromServer(Constants.signInAPI, param, HandleSuccess, HandleFailure);
        }

        /// <summary>         /// Handles the success for Sign in API call         /// </summary>         /// <param name="contents">Contents object return from the API call.</param>
        void HandleSuccess(object contents)
        {
            SignInDetail signInDetail = JsonConvert.DeserializeObject<SignInDetail>(contents.ToString());
            Debug.WriteLine(signInDetail.first_name);
            LoaderView.IsVisible = false;
            SaveUserDataToPreference(signInDetail);
            Preference.IsLoginWithEmail = true;
            Preference.EmailId = edtEmail.Text;
            if (!string.IsNullOrEmpty(Preference.PushId))
            {
                ValidateDeviceId();
            }
            else {
                Application.Current.MainPage = new HomePage();
            }


        }

        /// <summary>         /// Handles the failure for the API call         /// </summary>         /// <param name="message">Message related to the failure.</param>         /// <param name="errorType">Error type.</param>
        async void HandleFailure(string message, ErrorType errorType)
        {
            LoaderView.IsVisible = false;
            if (errorType == ErrorType.Network)
            {
                await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); 
            }
            else
            {
                if(message.ToLower() == "invalid email" || message.ToLower() == "invalid password")
                {
                    await DisplayAlert(null, "Invalid email or password", "Ok"); 
                }
                else 
                {
                    await DisplayAlert(null, message, "Ok"); 
                }

            }
        }

        /// <summary>
        /// Saves the user data to preference.
        /// </summary>
        /// <param name="signInDetail">Sign in detail.</param>
        public void SaveUserDataToPreference(SignInDetail signInDetail)
        {
            Preference.IsUserLoggedIn = true;
            Preference.FirstName = signInDetail.first_name;
            Preference.LastName = signInDetail.last_name;
            Preference.DeviceId = signInDetail.device_id;
            Preference.AccessToken = signInDetail.access_token;
        }

        /// <summary>
        /// Saves the user data to preference.
        /// </summary>
        /// <param name="createAccountDetail">Create account detail.</param>
        /// <param name="user">User object</param>
        public void SaveUserDataToPreference(CreateAccountDetail createAccountDetail, User user)
        {
            Preference.IsUserLoggedIn = true;
            Preference.FirstName = user.first_name;
            Preference.LastName = user.last_name;
            Preference.DeviceId = createAccountDetail.device_id;
            Preference.AccessToken = createAccountDetail.access_token;
        }


        /// <summary>
        /// Checks the validations.
        /// </summary>
        /// <returns><c>true</c>, if validations was checked, <c>false</c> otherwise.</returns>
        private bool CheckValidations()
        {
            bool returnValue = true;
            if (string.IsNullOrEmpty(edtEmail.Text))
            {
                ErrorEmailLb.Text = "Please enter an email id";
                returnValue = false;
            }
            else if (!CommonClass.IsEmailValid(edtEmail.Text))
            {
                ErrorEmailLb.Text = "Please enter a valid email id";
                returnValue = false;
            }
            else
            {
                ErrorEmailLb.Text = "";
            }

            if (string.IsNullOrEmpty(edtPassword.Text))
            {
                ErrorPassword.Text = "Please enter password";
                returnValue = false;
            }
            else
            {
                ErrorPassword.Text = "";
            }

            return returnValue;
        }

        /// <summary>
        /// Validates the device identifier and Update the push id for the user on server
        /// </summary>
        public void ValidateDeviceId()
        {
            LoaderView.IsVisible = true;
            var param = new ValidateDeviceParams();
            Debug.WriteLine("-----------\n" + param.access_auth_key + "\n" + param.access_device_id + "\n" + param.push_id);
            API.GetResponseFromServer(Constants.validateDeviceAPI, param, HandleSuccessForValidateDeviceId, HandleFailureForValidateDeviceId);
        }

        /// <summary>
        /// Handles the success for validate device identifier.
        /// </summary>
        /// <param name="contents">Contents.</param>
        void HandleSuccessForValidateDeviceId(object contents)
        {
            LoaderView.IsVisible = false;
            Application.Current.MainPage = new HomePage();
        }

        /// <summary>
        /// Handles the failure for validate device identifier.
        /// </summary>
        /// <param name="message">Error Message.</param>
        /// <param name="errorType">Error type.</param>
        async void HandleFailureForValidateDeviceId(string message, ErrorType errorType)
        {
            LoaderView.IsVisible = false;
            if (errorType == ErrorType.Network)
            {
                await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
            }
            else
            {
                await DisplayAlert(null, message, "Ok");
            }
        }

    }
}

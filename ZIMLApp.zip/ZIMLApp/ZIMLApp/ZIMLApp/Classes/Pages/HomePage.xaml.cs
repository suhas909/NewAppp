﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Model;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages the master detail navigation in the App.
    /// </summary>
    public partial class HomePage : MasterDetailPage
    {
        MenuListPage menuListPage;
        public HomePage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            menuListPage = new MenuListPage();
            Master = menuListPage;
            Detail = new NavigationPage(new DashboardPage());

            menuListPage.ListView.ItemSelected += OnItemSelected;
        }

        public HomePage(bool isFromNotification, string QuestionName, string QuestionId)
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            menuListPage = new MenuListPage();
            Master = menuListPage;
            Detail = new NavigationPage(new DailyMagicSpellsPage());
            var navigationPage = (NavigationPage)Detail;
            navigationPage.BarTextColor = Color.Black;
            QuestionPage questionPage = new QuestionPage();
            questionPage.QuestionName = QuestionName;
            questionPage.QuestionId = QuestionId;
            //if (navigationPage != null)
            //{
            //    navigationPage.PushAsync(questionPage);
            //}
            menuListPage.ListView.ItemSelected += OnItemSelected;
        }



        void OnItemSelected (object sender, SelectedItemChangedEventArgs e)
        {
            var item = e.SelectedItem as MasterPageItem;
            if (item != null) {
                Detail = new NavigationPage ((Page)Activator.CreateInstance (item.TargetType));
                //if (item.TargetType == typeof(DailyMagicSpellsPage))
                //{
                //    NavigationPage page = (NavigationPage)Detail;
                   
                //    page.BarTextColor = Color.Black;

                //}
                NavigationPage page = (NavigationPage)Detail;
                page.BarTextColor = Color.Black;
                menuListPage.ListView.SelectedItem = null;
                IsPresented = false;
            }
        }
    }
}

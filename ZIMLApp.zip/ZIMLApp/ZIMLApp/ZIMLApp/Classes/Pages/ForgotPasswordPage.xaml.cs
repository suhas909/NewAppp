﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Utility;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages the functionality for Forgot password.
    /// </summary>
    public partial class ForgotPasswordPage : ContentPage
    {
        public ForgotPasswordPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            initView();
        }

        private void initView()
        {
            //loaderWebView.Source = CommonClass.GetLoaderWebViewSource();

            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += (s, e) =>
            {
                this.Navigation.PopModalAsync();
            };
            imgBack.GestureRecognizers.Add(tapGestureRecognizer);
            tapGestureRecognizer.NumberOfTapsRequired = 1;
        }
        /// <summary>         /// This method manages the Send button click.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        async void Send_Clicked(object sender, System.EventArgs e)
        {
            if (CheckValidations())
            {
                VerifyOTPPage verifyOTPPage = new VerifyOTPPage();
                verifyOTPPage.emailId = edtEmail.Text;
                verifyOTPPage.isFromCreateAccount = false;
                await this.Navigation.PushModalAsync(verifyOTPPage);
            }
        }
        /// <summary>
        /// Checks the validations.
        /// </summary>
        /// <returns><c>true</c>, if validations was checked, <c>false</c> otherwise.</returns>
        private bool CheckValidations()
        {
            bool returnValue = true;
            if (string.IsNullOrEmpty(edtEmail.Text))
            {
                ErrorEmailLb.Text = "Please enter an email id";
                returnValue = false;
            }
            else if (!CommonClass.IsEmailValid(edtEmail.Text))
            {
                ErrorEmailLb.Text = "Please enter a valid email id";
                returnValue = false;
            }
            else
            {
                ErrorEmailLb.Text = "";
            }
            return returnValue;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Newtonsoft.Json;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;
using System.Diagnostics;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages News and Announcement detail page.
    /// </summary>
    public partial class NewsDetailPage : ContentPage
    {
        public ForumListItem forumListItem;
        public List<ForumDetailItem> forumDetailList = new List<ForumDetailItem>();
        public int currentIndex = 0;

        public NewsDetailPage()
        {
            InitializeComponent();
            LoaderView.IsVisible = true;
            messageWebView.Navigating += (s, e) =>
            {
                if (e.Url.StartsWith("http"))
                {
                    try
                    {
                        var uri = new Uri(e.Url);
                        Device.OpenUri(uri);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex);
                    }

                    e.Cancel = true;
                }
            };
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            if (forumListItem != null)
            {
                Title = forumListItem.postName;
                GetForumDetail();
            }

        }
        /// <summary>         /// This method manages the Try again button clicked, and try to reload the data.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void TryAgain_Clicked(object sender, System.EventArgs e)
        {
            LoaderView.IsVisible = true;
            ErrorView.IsVisible = false;
            GetForumDetail();
        }
        /// <summary>
        /// This method used to set the data on view.
        /// </summary>
        /// <param name="html">Text to set on view</param>
        /// <param name="post_id">Post identifier.</param>
        public void setDataOnView(string html, string post_id)
        {
            string htmlstr = WebUtility.HtmlDecode(html);
            string baseurl = getBaseUrlForImages(post_id);
            if (htmlstr.Contains("ziml/pix") && !htmlstr.Contains(Constants.baseURL))
            {
                htmlstr = htmlstr.Replace("/ziml/pix", Constants.baseURL + "/ziml/pix");
            }
            htmlstr = htmlstr.Replace("@@PLUGINFILE@@/", baseurl);
            if (htmlstr.Contains("href=\"/"))
                htmlstr = htmlstr.Replace("href=\"/", "href=\"" + Constants.baseURL + "/");
            else if (htmlstr.Contains("href=/"))
                htmlstr = htmlstr.Replace("href=/", "href=/" + Constants.baseURL + "/");
            string htmlData = CommonClass.getHTMLContent(htmlstr);

            var url = new HtmlWebViewSource { Html = htmlData };
            messageWebView.Source = url;
        }
        /// <summary>
        /// This method used to set the data for the current page.
        /// </summary>
        public void setDataForCurrentIndex()
        {
            setDataOnView(forumDetailList[currentIndex].message, forumDetailList[currentIndex].id);
            numberTxt.Text = "";// "#" + (currentIndex + 1);
            var title = forumDetailList[currentIndex].subject;
            TitleTxt.Text = title.ToCharArray().First().ToString().ToUpper() + title.Substring(1);
            TimeOfPostedTxt.Text = forumDetailList[currentIndex].getPostedTime();
            StartedByTxt.Text = forumDetailList[currentIndex].user_name;

        }

        private string getBaseUrlForImages(string post_id)
        {
            // Eg: https://zimlapp.areteem.org/api/images/forum.php?forum_id=12&post_id=195&filename=Screen%20Shot%202017-08-21%20at%206.07.19%20PM.png

            string baseUrl = Constants.baseURL + "/api/images/forum.php?forum_id=" + Constants.NEWS_FORUM_ID + "&post_id=" + post_id + "&filename=";
            return baseUrl;
        }
        /// <summary>
        /// Gets the News and announcement detail data from the API.
        /// </summary>
        public void GetForumDetail()
        {
            LoaderView.IsVisible = true;

            API.GetResponseFromServer(Constants.forumDetailAPI, new ForumDetailParam() { discussion_id = forumListItem.id, forum_id = Constants.NEWS_FORUM_ID }, (content) =>
            {
                LoaderView.IsVisible = false;
                ForumDetailResponse response = JsonConvert.DeserializeObject<ForumDetailResponse>(content.ToString());

                if (response != null)
                {
                    forumDetailList = response.posts;
                    setDataForCurrentIndex();
                }

            }, (message, errorType) => {
                LoaderView.IsVisible = false;
                ErrorView.IsVisible = true;
                if (errorType == ErrorType.Network)
                {
                    ErrorTitle.Text = Constants.NetworkErrorTitle;
                    ErrorMessage.Text = Constants.NetworkErrorMessage;
                    ActionButton.Text = "Try again";
                }
                else
                {
                    ErrorTitle.Text = Constants.ServerErrorTitle;
                    ErrorMessage.Text = Constants.ServerErrorMessage;
                    ActionButton.Text = "Refresh";
                }

            });
        }
    }
}

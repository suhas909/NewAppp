﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;

namespace ZIMLApp.Classes.Pages
{

    /// <summary>
    /// Product walkthrough content view class.
    /// </summary>
    public partial class ProductWalkthroughView : ContentView
    {
        
        public ProductWalkthroughView()
        {
            InitializeComponent();

        }

        public ProductWalkthroughView(string TitleText, string MessageText, string ImageName) 
        {
            InitializeComponent();
            TitleLb.Text = TitleText;
            MessageLb.Text = MessageText;
            TitleImage.Source = ImageName;
        }
    }
}

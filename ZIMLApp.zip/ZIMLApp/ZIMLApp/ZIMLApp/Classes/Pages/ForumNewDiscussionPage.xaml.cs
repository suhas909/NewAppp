﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;
using System.Net;

namespace ZIMLApp.Classes.Pages
{

    /// <summary>
    /// This class manages to add a new discussion forum page
    /// </summary>
    public partial class ForumNewDiscussionPage : ContentPage
    {
        public bool isForEditing = false;
        public string message = "";
        public string postId = "";
        public string subject = "";
        public string titleStr = "";

        public ForumNewDiscussionPage()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            if (isForEditing)
            {
                Title = titleStr;
                subjectTE.Text = subject;
                replyEditor.Text = message;
                replyEditor.TextColor = Color.Black;
                postBtn.Text = "Save Changes";
            }
        }
        /// <summary>
        /// This method manages Posts button clicks.
        /// </summary>
        /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        async void PostBtn_Clicked(object sender, System.EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(subjectTE.Text))
            {
                await DisplayAlert(null, "Please add a subject.", "Ok");
                return;
            }
            else if (string.IsNullOrWhiteSpace(replyEditor.Text) || replyEditor.Text == "Write your comment here")
            {
                await DisplayAlert(null, "Please add message.", "Ok");
                return;
            }
            string htmlData = CreateHTMLFromString(replyEditor.Text);
            Debug.WriteLine("htmlData==> \n" + htmlData);
            if (isForEditing) EditPost(subjectTE.Text, htmlData);
            else AddNewDiscussion(subjectTE.Text, htmlData);
        }


        string CreateHTMLFromString(string text)
        {

            text = WebUtility.HtmlEncode(text);
            text = text.Replace("\r\n", "\r");
            text = text.Replace("\n", "\r");
            text = text.Replace("\r", "<br>\r\n");
            text = text.Replace("  ", " &nbsp;");
            
            string htmlData = "<p>";
            htmlData = htmlData + text;//WebUtility.HtmlEncode(text);
            //htmlData = htmlData.Replace("\n", "</p><p>");
            htmlData = htmlData + "</p>";
            return htmlData;
        }
        /// <summary>
        /// This method manages API call for Add the new discussion.
        /// </summary>
        /// <param name="subject">Subject for the new discussion</param>
        /// <param name="message">Message for the new discussion</param>
        public void AddNewDiscussion(string subject, string message)
        {
            LoaderView.IsVisible = true;

            var param = new ForumAddDiscussionParam()
            {
                subject = subject,
                message = message,
            };
            API.GetResponseFromServer(Constants.forumAddDiscussionAPI, param, async (content) =>
            {
                LoaderView.IsVisible = false;
                await Navigation.PopAsync();

            }, async (msg, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
                else { await DisplayAlert(null, msg, "Ok"); }
            });
        }
        /// <summary>
        /// This method manages API call for edit the discussion.
        /// </summary>
        /// <param name="subject">Subject for the discussion</param>
        /// <param name="message">Message for the discussion</param>
        public void EditPost(string subject, string message)
        {
            LoaderView.IsVisible = true;

            var param = new ForumEditPostParam()
            {
                subject = subject,
                message = message,
                post_id = postId
            };
            API.GetResponseFromServer(Constants.forumEditPostAPI, param, async (content) =>
            {
                LoaderView.IsVisible = false;
                await Navigation.PopAsync();

            }, async (msg, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
                else { await DisplayAlert(null, msg, "Ok"); }
            });
        }
    }
}

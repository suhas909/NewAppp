﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using Newtonsoft.Json;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages the Edit profile page.
    /// </summary>
    public partial class EditProfilePage : ContentPage
    {
        
        /// <summary>
        /// The grade level list is used to show the dropdown list for the grade selection.
        /// </summary>
        List<string> gradeLevelList = new List<string>()
        {
            "1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","Post High School"
        };
        List<string> countryList = new List<string>();



        public EditProfilePage()
        {
            InitializeComponent();
            //loaderWebView.Source = CommonClass.GetLoaderWebViewSource();
            gradePicker.ItemsSource = gradeLevelList;

            countryList = countryDict.Values.ToList();
            CountryPicker.ItemsSource = countryList;
            LoaderView.IsVisible = true;
            NavigationPage.SetHasNavigationBar(this, false);
            AddGesture();
            GetUserProfileDetail(new ProfileDetailParam());
            imgProfilePic.Source = CommonClass.getProfilePhotoUrl();
        }

        public void AddGesture()
        {
            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += (s, e) => {
                this.Navigation.PopAsync();
            };
            imgBack.GestureRecognizers.Add(tapGestureRecognizer);
            tapGestureRecognizer.NumberOfTapsRequired = 1;

            var tapGestureRecognizerCamera = new TapGestureRecognizer();
            tapGestureRecognizerCamera.Tapped += async (s, e) =>
            {

                await Navigation.PushAsync(new ProfilePhotoDetailPage());

            };
            imgCamera.GestureRecognizers.Add(tapGestureRecognizerCamera);
            tapGestureRecognizerCamera.NumberOfTapsRequired = 1;
        }


        /// <summary>
        /// Gets the user profile detail.
        /// </summary>
        /// <param name="param">Profile details API parameters.</param>
        public void GetUserProfileDetail(ProfileDetailParam param)
        {
            LoaderView.IsVisible = true;
            API.GetResponseFromServer(Constants.profileDetailAPI, param, HandleSuccess, HandleFailure);
        }
        /// <summary>         /// Handles the success for Profile Detail API call.         /// </summary>         /// <param name="contents">Contents object return from the API call.</param>
        void HandleSuccess(object contents)
        {
            ProfileDetail profileDetail = JsonConvert.DeserializeObject<ProfileDetail>(contents.ToString());
            Debug.WriteLine(profileDetail.first_name);
            txtemail.Text = profileDetail.email_id;
            edtFirstName.Text = profileDetail.first_name;
            edtLastName.Text = profileDetail.last_name;
            edtSchool.Text = profileDetail.school;
            if (!string.IsNullOrEmpty(profileDetail.grade_level))
            {
                int selectedGread = Convert.ToInt32(profileDetail.grade_level) - 1;
                gradePicker.SelectedItem = gradeLevelList[selectedGread];
            }
            if (!string.IsNullOrEmpty(profileDetail.country))
            {
                string selectedCountry = countryDict[profileDetail.country];
                CountryPicker.SelectedItem = selectedCountry;
            }


            LoaderView.IsVisible = false;
        }
        /// <summary>         /// Handles the failure for the API calls.         /// </summary>         /// <param name="message">Message related to the failure.</param>         /// <param name="errorType">Error type.</param>
        async void HandleFailure(string message, ErrorType errorType)
        {
            LoaderView.IsVisible = false;
            if (errorType == ErrorType.Network)
            {
                await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
            }
            else
            {
                await DisplayAlert(null, message, "Ok");
            }
        }
        /// <summary>
        /// This method manages the click of update profile button.
        /// </summary>
        /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void Update_Profile_Clicked(object sender, System.EventArgs e)
        {
            if (CheckValidations())
            {
                UpdateProfileParam param = new UpdateProfileParam();
                param.first_name = edtFirstName.Text;
                param.last_name = edtLastName.Text;
                param.school = edtSchool.Text;
                int selectedIndex = gradeLevelList.IndexOf((string)gradePicker.SelectedItem) + 1;
                if (selectedIndex >= 1)
                {
                    param.grade_level = selectedIndex.ToString();  
                }
                string countryCode = countryDict.FirstOrDefault(x => x.Value == CountryPicker.SelectedItem).Key;
                if (countryCode == null)
                {
                    param.country_code = "";
                }
                else
                {
                    param.country_code = countryCode;
                }

                UpdateUserProfile(param);
            }
        }
        /// <summary>
        /// This method manages the update profile API call.
        /// </summary>
        /// <param name="param">Update profile API Parameter.</param>
        public void UpdateUserProfile(UpdateProfileParam param)
        {
            LoaderView.IsVisible = true;
            API.GetResponseFromServer(Constants.updateProfileAPI, param, HandleUpdateProfileSuccess, HandleFailure);
        }
        /// <summary>
        /// Handles the success for update profile API call
        /// </summary>
        /// <param name="contents">Contents object return from the API call.</param>
        async void HandleUpdateProfileSuccess(object contents)
        {
            //ProfileDetail profileDetail = JsonConvert.DeserializeObject<ProfileDetail>(contents.ToString());
            //Debug.WriteLine(profileDetail.first_name);
            LoaderView.IsVisible = false;
            await DisplayAlert(null, "Profile updated successfully.", "Ok");
            SaveUserDataToPreference();

        }
        /// <summary>
        /// Checks the validations.
        /// </summary>
        /// <returns><c>true</c>, if validations was checked, <c>false</c> otherwise.</returns>
        private bool CheckValidations()
        {
            bool returnValue = true;
            if (string.IsNullOrEmpty(edtFirstName.Text))
            {
                ErrorFirstName.Text = "Please enter first name";
                returnValue = false;
            }
            else if (!CommonClass.isValidStringForName(edtFirstName.Text))
            {
                ErrorFirstName.Text = "Spacial characters are not allowed";
                returnValue = false;
            }
            else
            {
                ErrorFirstName.Text = "";
            }

            if (string.IsNullOrEmpty(edtLastName.Text))
            {
                ErrorLastName.Text = "Please enter last name";
                returnValue = false;
            }
            else if (!CommonClass.isValidStringForName(edtLastName.Text))
            {
                ErrorLastName.Text = "Spacial characters are not allowed";
                returnValue = false;
            }
            else
            {
                ErrorLastName.Text = "";
            }

            return returnValue;
        }

        /// <summary>
        /// Saves the user data to preference.
        /// </summary>
        public void SaveUserDataToPreference()
        {
            Preference.FirstName = edtFirstName.Text;
            Preference.LastName = edtLastName.Text;
        }
        /// <summary>
        /// The countries list with their country code.
        /// </summary>
        public Dictionary<string, string> countryDict = new Dictionary<string, string>()
        {
            {"AF","Afghanistan"},
            {"AL", "Albania"},
            {"DZ", "Algeria"},
            {"AS", "American Samoa"},
            {"AD", "Andorra"},
            {"AO", "Angola"},
            {"AI", "Anguilla"},
            {"AQ", "Antarctica"},
            {"AG", "Antigua And Barbuda"},
            {"AR", "Argentina"},
            {"AM", "Armenia"},
            {"AW", "Aruba"},
            {"AU", "Australia"},
            {"AT", "Austria"},
            {"AZ", "Azerbaijan"},
            {"BS", "Bahamas"},
            {"BH", "Bahrain"},
            {"BD", "Bangladesh"},
            {"BB", "Barbados"},
            {"BY", "Belarus"},
            {"BE", "Belgium"},
            {"BZ", "Belize"},
            {"BJ", "Benin"},
            {"BM", "Bermuda"},
            {"BT", "Bhutan"},
            {"BO", "Bolivia"},
            {"BA", "Bosnia And Herzegovina"},
            {"BW", "Botswana"},
            {"BV", "Bouvet Island"},
            {"BR", "Brazil"},
            {"IO", "British Indian Ocean Territory"},
            {"BN", "Brunei Darussalam"},
            {"BG", "Bulgaria"},
            {"BF", "Burkina Faso"},
            {"BI", "Burundi"},
            {"KH", "Cambodia"},
            {"CM", "Cameroon"},
            {"CA", "Canada"},
            {"CV", "Cape Verde"},
            {"KY", "Cayman Islands"},
            {"CF", "Central African Republic"},
            {"TD", "Chad"},
            {"CL", "Chile"},
            {"CN", "China"},
            {"CX", "Christmas Island"},
            {"CC", "Cocos (keeling) Islands"},
            {"CO", "Colombia"},
            {"KM", "Comoros"},
            {"CG", "Congo"},
            {"CD", "Congo, The Democratic Republic Of The"},
            {"CK", "Cook Islands"},
            {"CR", "Costa Rica"},
            {"CI", "Cote D'ivoire"},
            {"HR", "Croatia"},
            {"CU", "Cuba"},
            {"CY", "Cyprus"},
            {"CZ", "Czech Republic"},
            {"DK", "Denmark"},
            {"DJ", "Djibouti"},
            {"DM", "Dominica"},
            {"DO", "Dominican Republic"},
            {"TP", "East Timor"},
            {"EC", "Ecuador"},
            {"EG", "Egypt"},
            {"SV", "El Salvador"},
            {"GQ", "Equatorial Guinea"},
            {"ER", "Eritrea"},
            {"EE", "Estonia"},
            {"ET", "Ethiopia"},
            {"FK", "Falkland Islands (malvinas)"},
            {"FO", "Faroe Islands"},
            {"FJ", "Fiji"},
            {"FI", "Finland"},
            {"FR", "France"},
            {"GF", "French Guiana"},
            {"PF", "French Polynesia"},
            {"TF", "French Southern Territories"},
            {"GA", "Gabon"},
            {"GM", "Gambia"},
            {"GE", "Georgia"},
            {"DE", "Germany"},
            {"GH", "Ghana"},
            {"GI", "Gibraltar"},
            {"GR", "Greece"},
            {"GL", "Greenland"},
            {"GD", "Grenada"},
            {"GP", "Guadeloupe"},
            {"GU", "Guam"},
            {"GT", "Guatemala"},
            {"GN", "Guinea"},
            {"GW", "Guinea-bissau"},
            {"GY", "Guyana"},
            {"HT", "Haiti"},
            {"HM", "Heard Island And Mcdonald Islands"},
            {"VA", "Holy See (vatican City State)"},
            {"HN", "Honduras"},
            {"HK", "Hong Kong"},
            {"HU", "Hungary"},
            {"IS", "Iceland"},
            {"IN", "India"},
            {"ID", "Indonesia"},
            {"IR", "Iran, Islamic Republic Of"},
            {"IQ", "Iraq"},
            {"IE", "Ireland"},
            {"IL", "Israel"},
            {"IT", "Italy"},
            {"JM", "Jamaica"},
            {"JP", "Japan"},
            {"JO", "Jordan"},
            {"KZ", "Kazakstan"},
            {"KE", "Kenya"},
            {"KI", "Kiribati"},
            {"KP", "Korea, Democratic People's Republic Of"},
            {"KR", "Korea, Republic Of"},
            {"KV", "Kosovo"},
            {"KW", "Kuwait"},
            {"KG", "Kyrgyzstan"},
            {"LA", "Lao People's Democratic Republic"},
            {"LV", "Latvia"},
            {"LB", "Lebanon"},
            {"LS", "Lesotho"},
            {"LR", "Liberia"},
            {"LY", "Libyan Arab Jamahiriya"},
            {"LI", "Liechtenstein"},
            {"LT", "Lithuania"},
            {"LU", "Luxembourg"},
            {"MO", "Macau"},
            {"MK", "Macedonia, The Former Yugoslav Republic Of"},
            {"MG", "Madagascar"},
            {"MW", "Malawi"},
            {"MY", "Malaysia"},
            {"MV", "Maldives"},
            {"ML", "Mali"},
            {"MT", "Malta"},
            {"MH", "Marshall Islands"},
            {"MQ", "Martinique"},
            {"MR", "Mauritania"},
            {"MU", "Mauritius"},
            {"YT", "Mayotte"},
            {"MX", "Mexico"},
            {"FM", "Micronesia, Federated States Of"},
            {"MD", "Moldova, Republic Of"},
            {"MC", "Monaco"},
            {"MN", "Mongolia"},
            {"MS", "Montserrat"},
            {"ME", "Montenegro"},
            {"MA", "Morocco"},
            {"MZ", "Mozambique"},
            {"MM", "Myanmar"},
            {"NA", "Namibia"},
            {"NR", "Nauru"},
            {"NP", "Nepal"},
            {"NL", "Netherlands"},
            {"AN", "Netherlands Antilles"},
            {"NC", "New Caledonia"},
            {"NZ", "New Zealand"},
            {"NI", "Nicaragua"},
            {"NE", "Niger"},
            {"NG", "Nigeria"},
            {"NU", "Niue"},
            {"NF", "Norfolk Island"},
            {"MP", "Northern Mariana Islands"},
            {"NO", "Norway"},
            {"OM", "Oman"},
            {"PK", "Pakistan"},
            {"PW", "Palau"},
            {"PS", "Palestinian Territory, Occupied"},
            {"PA", "Panama"},
            {"PG", "Papua New Guinea"},
            {"PY", "Paraguay"},
            {"PE", "Peru"},
            {"PH", "Philippines"},
            {"PN", "Pitcairn"},
            {"PL", "Poland"},
            {"PT", "Portugal"},
            {"PR", "Puerto Rico"},
            {"QA", "Qatar"},
            {"RE", "Reunion"},
            {"RO", "Romania"},
            {"RU", "Russian Federation"},
            {"RW", "Rwanda"},
            {"SH", "Saint Helena"},
            {"KN", "Saint Kitts And Nevis"},
            {"LC", "Saint Lucia"},
            {"PM", "Saint Pierre And Miquelon"},
            {"VC", "Saint Vincent And The Grenadines"},
            {"WS", "Samoa"},
            {"SM", "San Marino"},
            {"ST", "Sao Tome And Principe"},
            {"SA", "Saudi Arabia"},
            {"SN", "Senegal"},
            {"RS", "Serbia"},
            {"SC", "Seychelles"},
            {"SL", "Sierra Leone"},
            {"SG", "Singapore"},
            {"SK", "Slovakia"},
            {"SI", "Slovenia"},
            {"SB", "Solomon Islands"},
            {"SO", "Somalia"},
            {"ZA", "South Africa"},
            {"GS", "South Georgia And The South Sandwich Islands"},
            {"ES", "Spain"},
            {"LK", "Sri Lanka"},
            {"SD", "Sudan"},
            {"SR", "Suriname"},
            {"SJ", "Svalbard And Jan Mayen"},
            {"SZ", "Swaziland"},
            {"SE", "Sweden"},
            {"CH", "Switzerland"},
            {"SY", "Syrian Arab Republic"},
            {"TW", "Taiwan, Province Of China"},
            {"TJ", "Tajikistan"},
            {"TZ", "Tanzania, United Republic Of"},
            {"TH", "Thailand"},
            {"TG", "Togo"},
            {"TK", "Tokelau"},
            {"TO", "Tonga"},
            {"TT", "Trinidad And Tobago"},
            {"TN", "Tunisia"},
            {"TR", "Turkey"},
            {"TM", "Turkmenistan"},
            {"TC", "Turks And Caicos Islands"},
            {"TV", "Tuvalu"},
            {"UG", "Uganda"},
            {"UA", "Ukraine"},
            {"AE", "United Arab Emirates"},
            {"GB", "United Kingdom"},
            {"US", "United States"},
            {"UM", "United States Minor Outlying Islands"},
            {"UY", "Uruguay"},
            {"UZ", "Uzbekistan"},
            {"VU", "Vanuatu"},
            {"VE", "Venezuela"},
            {"VN", "Viet Nam"},
            {"VG", "Virgin Islands, British"},
            {"VI", "Virgin Islands, U.s."},
            {"WF", "Wallis And Futuna"},
            {"EH", "Western Sahara"},
            {"YE", "Yemen"},
            {"ZM", "Zambia"},
            {"ZW", "Zimbabwe"},
        };
    }

}

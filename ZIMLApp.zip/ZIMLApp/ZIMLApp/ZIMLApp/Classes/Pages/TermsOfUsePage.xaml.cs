﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Utility;
using System.Diagnostics;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages to show Terms of use page.
    /// </summary>
    public partial class TermsOfUsePage : ContentPage
    {
        public TermsOfUsePage()
        {
            NavigationPage.SetBackButtonTitle(this, " ");
            InitializeComponent();
            contentWebView.Source = Constants.termsOfUsePageURL;
            contentWebView.Navigating += (s, e) =>
            {
                if (e.Url.StartsWith("http") && e.Url != Constants.termsOfUsePageURL)
                {
                    try
                    {
                        var uri = new Uri(e.Url);
                        Device.OpenUri(uri);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex);
                    }

                    e.Cancel = true;
                }
            };
        }
    }
}

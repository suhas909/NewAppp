﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;
using System.Diagnostics;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Linq;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages the Create account page and responsible for In-app Sign up. 
    /// </summary>
    public partial class CreateAccountPage : ContentPage
    {
        /// <summary>
        /// The User class object, it contains the value if the user comes from social sign up and some information like email id or name are missing.
        /// </summary>
        public User userData;
        /// <summary>
        ///  Registration token also used in case of social sign up.
        /// </summary>
        public string registrationToken;

        public CreateAccountPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            initView();

        }

        public void initView()
        {
            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += (s, e) =>
            {
                this.Navigation.PopAsync();
            };
            imgBack.GestureRecognizers.Add(tapGestureRecognizer);
            tapGestureRecognizer.NumberOfTapsRequired = 1;

            var visibilityImgGR = new TapGestureRecognizer();
            visibilityImgGR.Tapped += (s, e) =>
            {
                if (edtPassword.IsPassword == true)
                {
                    edtPassword.IsPassword = false;
                    visibilityImg.Source = "ic_visibility_off.png";
                }
                else
                {
                    edtPassword.IsPassword = true;
                    visibilityImg.Source = "ic_visibility.png";
                }
            };
            visibilityImg.GestureRecognizers.Add(visibilityImgGR);
            visibilityImgGR.NumberOfTapsRequired = 1;

            //loaderWebView.Source = CommonClass.GetLoaderWebViewSource();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            CheckForSocialSignup();
        }

        private void CheckForSocialSignup()
        {
            if (userData != null)
            {
                edtPassword.IsVisible = false;
                visibilityImg.IsVisible = false;
                edtFirstName.Text = userData.first_name;
                edtLastName.Text = userData.last_name;
                if (!string.IsNullOrEmpty(userData.email_id))
                {
                    edtEmail.Text = userData.email_id;
                    edtEmail.IsEnabled = false;
                }
            }
        }
        /// <summary>
        /// This method manages the Create account button click.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        async public void Create_Account_Clicked(object sender, System.EventArgs e)
        {
            if (CheckValidations())
            {
                if (userData == null)
                {
                    VerifyOTPPage verifyOTPPage = new VerifyOTPPage();
                    verifyOTPPage.emailId = edtEmail.Text;
                    verifyOTPPage.password = edtPassword.Text;
                    verifyOTPPage.firstName = edtFirstName.Text;
                    verifyOTPPage.lastName = edtLastName.Text;
                    await this.Navigation.PushModalAsync(verifyOTPPage);
                }
                else if (!string.IsNullOrEmpty(userData.email_id))
                {
                    RegisterAuthWithServer();
                }
                else
                {
                    VerifyOTPPage verifyOTPPage = new VerifyOTPPage();
                    verifyOTPPage.emailId = edtEmail.Text;
                    verifyOTPPage.firstName = edtFirstName.Text;
                    verifyOTPPage.lastName = edtLastName.Text;
                    verifyOTPPage.password = userData.access_token.Substring(10, 32);
                    verifyOTPPage.registrationToken = registrationToken;//(string)data["registration_token"];
                    verifyOTPPage.oauthId = userData.id;
                    if (!string.IsNullOrEmpty(userData.picture_url)) verifyOTPPage.picture_url = userData.picture_url;
                    await this.Navigation.PushModalAsync(verifyOTPPage);
                    //LoaderView.IsVisible = false;
                }
            }
        }
        /// <summary>
        /// This method manages the API call for Create account for Social sign up.
        /// </summary>
        public void RegisterAuthWithServer()
        {
            LoaderView.IsVisible = true;
            CreateAccountParam param = new CreateAccountParam()
            {
                oauth_id = userData.id,
                oauth_registration_token = registrationToken,
                email_id = edtEmail.Text,
                first_name = edtFirstName.Text,
                last_name = edtLastName.Text,
                otp_successful_validation_token = "",
                password = userData.access_token.Substring(10, 32)
            };

            API.GetResponseFromServer(Constants.createAccountAPI, param, (content) =>
            {
                CreateAccountDetail createAccountDetail = JsonConvert.DeserializeObject<CreateAccountDetail>(content.ToString());
                Debug.WriteLine(createAccountDetail.access_token);
                SaveUserDataToPreference(createAccountDetail);
                if (!string.IsNullOrEmpty(userData.picture_url)) Preference.UploadProfileUrl = userData.picture_url;
                LoaderView.IsVisible = false;
                if (!string.IsNullOrEmpty(Preference.PushId))
                    ValidateDeviceId();
                else
                    Application.Current.MainPage = new HomePage();

            }, async (message, errorType) =>
            {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network)
                    await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
                else
                    await DisplayAlert(null, message, "Ok");
            });
        }
        /// <summary>
        /// This method saves the user data to preference.
        /// </summary>
        /// <param name="createAccountDetail">Create account details to save in preference.</param>
        public void SaveUserDataToPreference(CreateAccountDetail createAccountDetail)
        {
            Preference.IsUserLoggedIn = true;
            Preference.FirstName = edtFirstName.Text;
            Preference.LastName = edtLastName.Text;
            Preference.DeviceId = createAccountDetail.device_id;
            Preference.AccessToken = createAccountDetail.access_token;
        }
        /// <summary>
        /// This method manages the API call for Validates device identifier.
        /// </summary>
        public void ValidateDeviceId()
        {
            LoaderView.IsVisible = true;
            var param = new ValidateDeviceParams();
            Debug.WriteLine("-----------\n" + param.access_auth_key + "\n" + param.access_device_id + "\n" + param.push_id);
            API.GetResponseFromServer(Constants.validateDeviceAPI, param, HandleSuccessForValidateDeviceId, HandleFailureForValidateDeviceId);
        }
        /// <summary>
        /// Handles the success for validate device identifier.
        /// </summary>
        /// <param name="contents">Contents object return from the API call.</param>
        void HandleSuccessForValidateDeviceId(object contents)
        {
            LoaderView.IsVisible = false;
            Application.Current.MainPage = new HomePage();
        }
        /// <summary>
        /// Handles the failure for validate device identifier.
        /// </summary>
        /// <param name="message">Message related to the failure.</param>
        /// <param name="errorType">Error type.</param>
        async void HandleFailureForValidateDeviceId(string message, ErrorType errorType)
        {
            LoaderView.IsVisible = false;
            if (errorType == ErrorType.Network)
            {
                await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
            }
            else
            {
                await DisplayAlert(null, message, "Ok");
            }
        }
        /// <summary>
        /// Checks the validations.
        /// </summary>
        /// <returns><c>true</c>, if validations was checked, <c>false</c> otherwise.</returns>
        private bool CheckValidations()
        {
            bool returnValue = true;
            if (string.IsNullOrEmpty(edtEmail.Text))
            {
                ErrorEmailLb.Text = "Please enter an email id";
                returnValue = false;
            }
            else if (!CommonClass.IsEmailValid(edtEmail.Text))
            {
                ErrorEmailLb.Text = "Please enter a valid email id";
                returnValue = false;
            }
            else
            {
                ErrorEmailLb.Text = "";
            }
            if (userData == null)
            {
                if (string.IsNullOrEmpty(edtPassword.Text))
                {
                    PasswordErrorLb.Text = "Please enter password";
                    returnValue = false;
                }
                else if (!CommonClass.IsPasswordValid(edtPassword.Text))
                {
                    PasswordErrorLb.Text = "The password must have at least 8 characters, at least 1 digit(s), at least 1 upper case letter(s), at least 1 lower case letter(s)";
                    returnValue = false;
                }
                else
                {
                    PasswordErrorLb.Text = "";
                }
            }

            if (string.IsNullOrEmpty(edtFirstName.Text))
            {
                FirstNameErrorLb.Text = "Please enter first name";
                returnValue = false;
            }
            else if (!CommonClass.isValidStringForName(edtFirstName.Text))
            {
                FirstNameErrorLb.Text = "Spacial characters are not allowed";
                returnValue = false;
            }
            else
            {
                FirstNameErrorLb.Text = "";
            }

            if (string.IsNullOrEmpty(edtLastName.Text))
            {
                LastNameErrorLb.Text = "Please enter last name";
                returnValue = false;
            }
            else if (!CommonClass.isValidStringForName(edtLastName.Text))
            {
                LastNameErrorLb.Text = "Spacial characters are not allowed";
                returnValue = false;
            }
            else
            {
                LastNameErrorLb.Text = "";
            }

            return returnValue;
        }



    }
}

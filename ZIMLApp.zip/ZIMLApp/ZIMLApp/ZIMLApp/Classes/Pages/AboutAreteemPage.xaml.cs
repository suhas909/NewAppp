﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Utility;
using System.Diagnostics;

namespace ZIMLApp.Classes.Pages
{

    /// <summary>
    /// This class is used to show the About Areteem Institute details.
    /// </summary>
    public partial class AboutAreteemPage : ContentPage
    {
        public AboutAreteemPage()
        {
            InitializeComponent();
            contentWebView.Source = Constants.aboutAreteemPageURL;
            contentWebView.Navigating += (s, e) =>
            {
                if (e.Url.StartsWith("http") && e.Url != Constants.aboutAreteemPageURL)
                {
                    try
                    {
                        var uri = new Uri(e.Url);
                        Device.OpenUri(uri);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex);
                    }

                    e.Cancel = true;
                }
            };
        }
    }
}

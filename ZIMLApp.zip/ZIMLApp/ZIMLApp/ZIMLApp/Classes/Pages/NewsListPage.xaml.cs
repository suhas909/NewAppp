﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages to show the News and Announcement list page.
    /// </summary>
    public partial class NewsListPage : ContentPage
    {
        List<ForumListItem> forumList = new List<ForumListItem>();

        public NewsListPage()
        {
            InitializeComponent();
            Title = "News and Announcements";
            NavigationPage.SetBackButtonTitle(this, " ");
            LoaderView.IsVisible = true;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            NavigationPage navigationPage = (NavigationPage)((HomePage)Application.Current.MainPage).Detail;
            navigationPage.BarTextColor = Color.Black;
            HomePage home = (HomePage)Application.Current.MainPage;
            if (home != null)
            {
                home.IsGestureEnabled = true;
            }
            GetForumList();
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            if (Application.Current.MainPage is HomePage)
            {
                HomePage home = (HomePage)Application.Current.MainPage;
                if (home != null)
                {
                    home.IsGestureEnabled = false;
                }
            }
        }

        /// <summary>         /// This method manages the List item click event. And navigate to the detail page for the related item.         /// </summary>         /// <param name="sender">List item object</param>         /// <param name="e">Event arguments.</param>
        void ListItem_Tapped(object sender, System.EventArgs e)
        {
            var item = (ForumListItem)forumsListView.SelectedItem;
            Navigation.PushAsync(new NewsDetailPage() { forumListItem = item });
        }
        /// <summary>         /// This method manages the Try again button clicked, and try to reload the data.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void TryAgain_Clicked(object sender, System.EventArgs e)
        {
            LoaderView.IsVisible = true;
            ErrorView.IsVisible = false;
            GetForumList();
        }
        /// <summary>
        /// Gets the News forums list from the API.
        /// </summary>
        public void GetForumList()
        {
            LoaderView.IsVisible = true;

            API.GetResponseFromServer(Constants.forumListAPI, new ForumListParam() { forum_id = Constants.NEWS_FORUM_ID }, (content) =>
            {
                LoaderView.IsVisible = false;
                var response = JsonConvert.DeserializeObject<List<ForumListItem>>(content.ToString());

                if (response != null)
                {
                    response.Reverse();
                    forumList = response;
                    forumsListView.ItemsSource = forumList;
                }

            }, (message, errorType) => {
                LoaderView.IsVisible = false;
                ErrorView.IsVisible = true;
                if (errorType == ErrorType.Network)
                {
                    ErrorTitle.Text = Constants.NetworkErrorTitle;
                    ErrorMessage.Text = Constants.NetworkErrorMessage;
                    ActionButton.Text = "Try again";
                }
                else
                {
                    ErrorTitle.Text = Constants.ServerErrorTitle;
                    ErrorMessage.Text = Constants.ServerErrorMessage;
                    ActionButton.Text = "Refresh";
                }

            });
        }
    }
}

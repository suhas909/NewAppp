﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Utility;
using System.Diagnostics;

namespace ZIMLApp.Classes.Pages
{

    /// <summary>
    /// This class is used to show the About ZIML (Zoom International Math League) details.
    /// </summary>
    public partial class AboutZIMLPage : ContentPage
    {
        public AboutZIMLPage()
        {
            InitializeComponent();
            contentWebView.Source = Constants.aboutZIMLPageURL;
            contentWebView.Navigating += (s, e) =>
            {
                if (e.Url.StartsWith("http") && e.Url != Constants.aboutZIMLPageURL)
                {
                    try
                    {
                        var uri = new Uri(e.Url);
                        Device.OpenUri(uri);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex);
                    }

                    e.Cancel = true;
                }
            };
        }
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages to show the list of discussion forums.
    /// </summary>
    public partial class ForumsListPage : ContentPage
    {

        List<ForumListItem> forumList = new List<ForumListItem>();

        public ForumsListPage()
        {
            InitializeComponent();
            Title = "Forum";
            NavigationPage.SetBackButtonTitle(this, " ");
            if (Preference.IsUserLoggedIn)
            {
                AddToolbarItem();
            }
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            NavigationPage navigationPage = (NavigationPage)((HomePage)Application.Current.MainPage).Detail;
            navigationPage.BarTextColor = Color.Black;
            HomePage home = (HomePage)Application.Current.MainPage;
            if (home != null)
            {
                home.IsGestureEnabled = true;
            }
            GetForumList();
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            if (Application.Current.MainPage is HomePage)
            {
                HomePage home = (HomePage)Application.Current.MainPage;
                if (home != null)
                {
                    home.IsGestureEnabled = false;
                }
            }
        }

        void AddToolbarItem()
        {
            var addDiscussionBtn = new ToolbarItem
            {
                Icon = "Add.png",
                Text = "add",
                Priority = 0
            };

            addDiscussionBtn.Clicked +=  (s, e) => {
                Navigation.PushAsync(new ForumNewDiscussionPage());
            };

            ToolbarItems.Add(addDiscussionBtn);
        }

        /// <summary>         /// This method manages the List item click event and navigate to the details page for the related forum.         /// </summary>         /// <param name="sender">List item object</param>         /// <param name="e">Event arguments.</param>
        void ListItem_Tapped(object sender, System.EventArgs e)
        {
            var item = (ForumListItem)forumsListView.SelectedItem;
            Navigation.PushAsync(new ForumDetailPage(){forumListItem = item});
        }
        /// <summary>         /// This method manages the Try again button clicked, And try to reload the data.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void TryAgain_Clicked(object sender, System.EventArgs e)
        {
            LoaderView.IsVisible = true;
            ErrorView.IsVisible = false;
            GetForumList();
        }
        /// <summary>
        /// This method used to call the discussion forum list API.
        /// </summary>
        public void GetForumList()
        {
            LoaderView.IsVisible = true;

            API.GetResponseFromServer(Constants.forumListAPI, new ForumListParam() { forum_id = Constants.DISCUSSION_FORUM_ID }, (content) =>
            {
                LoaderView.IsVisible = false;
                var response = JsonConvert.DeserializeObject<List<ForumListItem>>(content.ToString());

                if (response != null)
                {
                    response.Reverse();
                    forumList = response;
                    forumsListView.ItemsSource = forumList;
                    forumsListView.ScrollTo(((IList)forumsListView.ItemsSource)[0], ScrollToPosition.Start, false);
                }

            }, (message, errorType) => {
                LoaderView.IsVisible = false;
                ErrorView.IsVisible = true;
                if (errorType == ErrorType.Network)
                {
                    ErrorTitle.Text = Constants.NetworkErrorTitle;
                    ErrorMessage.Text = Constants.NetworkErrorMessage;
                    ActionButton.Text = "Try again";
                }
                else
                {
                    ErrorTitle.Text = Constants.ServerErrorTitle;
                    ErrorMessage.Text = Constants.ServerErrorMessage;
                    ActionButton.Text = "Refresh";
                }

            });
        }
    }
}

﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;
using Plugin.FirebasePushNotification;
using System.Diagnostics;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// Settings page view model class.
    /// </summary>
    public class SettingsPageViewModel
    {
        public bool IsShadowEnable { get { return isShadowEnable(); } }

        public bool isShadowEnable()
        {
            if (Device.RuntimePlatform == Device.iOS)
            {
                return false;
            }
            return true;
        }
    }

    /// <summary>
    /// This class manages the Settings page of the Application
    /// </summary>
    public partial class SettingsPage : ContentPage
    {
        public SettingsPage()
        {
            InitializeComponent();
            BindingContext = new SettingsPageViewModel();
            NavigationPage.SetBackButtonTitle(this, " ");

            Title = "Settings";
            LoadData();
            AddGesture();

        }
        protected override void OnAppearing()
        {
            base.OnAppearing();
            if (!Preference.IsUserLoggedIn)
            {
                 txtUser.Text = "Guest User";
                indecatorImg.IsVisible = false;
            }
            else
            {
                txtUser.Text = Preference.FirstName + " " + Preference.LastName;
                profileImage.Source = CommonClass.getProfilePhotoUrl();
            }
            HomePage home = (HomePage)Application.Current.MainPage;
            if (home != null)
            {
                home.IsGestureEnabled = true;
            }
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            if (Application.Current.MainPage.GetType() == typeof(HomePage)) {
                HomePage home = (HomePage)Application.Current.MainPage;
                if (home != null)
                {
                    home.IsGestureEnabled = false;
                }
            }
        }

        void AddGesture()
        {
            if (Preference.IsUserLoggedIn)
            {
                var tapGestureRecognizer = new TapGestureRecognizer();
                tapGestureRecognizer.Tapped += (s, e) =>
                {
                    this.Navigation.PushAsync(new EditProfilePage());
                };
                tapGestureRecognizer.NumberOfTapsRequired = 1;
                ProfileLayout.GestureRecognizers.Add(tapGestureRecognizer);
            }
        }

        void LoadData()
        {
            var appSettingsList = new List<AppSettingsItems>();
            //appSettingsList.Add(new AppSettingsItems()
            //{
            //    title = "Change email"
            //});
            bool IsNotificationOn = false;
            if (Preference.IsNotificationAllowed)
            {
                IsNotificationOn = true;
            }

            if (Preference.IsLoginWithEmail)
            {
                appSettingsList.Add(new AppSettingsItems()
                {
                    title = "Change Password"
                        
                });
            }


            //appSettingsList.Add(new AppSettingsItems()
            //{
            //    title = "Subscription"
            //});
            if (Preference.IsUserLoggedIn)
            {
                appSettingsList.Add(new AppSettingsItems()
                {
                    title = "Notifications",
                    IsArrowVisible = false,
                    IsActionButtonVisible = true,
                    IsNotificationOn = IsNotificationOn
                });

                appSettingsList.Add(new AppSettingsItems()
                {
                    title = "Sign out",
                    IsArrowVisible = false
                        
                });   
            }
            else
            {
                appSettingsList.Add(new AppSettingsItems()
                {
                    title = "Sign in"
                }); 
            }
            appSettingListView.ItemsSource = appSettingsList;
            appSettingListView.HeightRequest = 50 * appSettingsList.Count + 4;

            var aboutZimlList = new List<AppSettingsItems>();

            aboutZimlList.Add(new AppSettingsItems()
            {
                title = "About Areteem"
            });
            aboutZimlList.Add(new AppSettingsItems()
            {
                title = "About ZIML"
            });
            aboutZimlList.Add(new AppSettingsItems()
            {
                title = "Contact us"
            });
            aboutZimlList.Add(new AppSettingsItems()
            {
                title = "Help"
            });

            aboutZimlListView.ItemsSource = aboutZimlList;
            aboutZimlListView.HeightRequest = 50 * aboutZimlList.Count + 4;
        }

        async void Notification_Toggled(object sender, Xamarin.Forms.ToggledEventArgs e)
        {
            if (sender.GetType() == typeof(Xamarin.Forms.Switch))
            {
                Xamarin.Forms.Switch s = (Xamarin.Forms.Switch)sender;
                if (s.IsToggled)
                {
                    Debug.WriteLine("IsToggled true");
                    //TODO SUhas has done canges
                  
                     CrossFirebasePushNotification.Current.RegisterForPushNotifications();
                    Preference.IsNotificationAllowed = true;
                }
                else
                {
                    Debug.WriteLine("IsToggled false");
                    CrossFirebasePushNotification.Current.UnregisterForPushNotifications();
                    Preference.IsNotificationAllowed = false;

                }
            }
        }

        async void App_Settings_Item_Tapped(object sender, Xamarin.Forms.ItemTappedEventArgs e)
        {
            AppSettingsItems appSettingsItems = (AppSettingsItems)appSettingListView.SelectedItem;
            if (appSettingsItems.title == "Sign out")
            {
                bool value = await DisplayAlert(null, "Are you sure you want to sign out?", "Yes", "No");
                if (value)
                {
                    Preference.IsUserLoggedIn = false;
                    Preference.IsLoginWithEmail = false;
                    Preference.AccessToken = "";
                    Preference.FirstName = "";
                    Preference.LastName = "";
                    Preference.UploadProfileUrl = "";

                    Application.Current.MainPage = new NavigationPage(new SplashScreenPage());
                }
            }
            else if (appSettingsItems.title == "Sign in")
            {
                Application.Current.MainPage = new NavigationPage(new SplashScreenPage());
            }
            else if (appSettingsItems.title == "Change Password")
            {
                await this.Navigation.PushAsync(new ChangePasswordPage());
            }

        }


        void About_Ziml_Item_Tapped(object sender, Xamarin.Forms.ItemTappedEventArgs e)
        {
            AppSettingsItems appSettingsItems = (AppSettingsItems)aboutZimlListView.SelectedItem;
            if (appSettingsItems.title == "About Areteem")
            {
                this.Navigation.PushAsync(new AboutAreteemPage());
            }
            else if (appSettingsItems.title == "About ZIML")
            {
                this.Navigation.PushAsync(new AboutZIMLPage());
            }

            else if (appSettingsItems.title == "Contact us")
            {
                this.Navigation.PushAsync(new ContactUsDetailPage());
            }
            else if (appSettingsItems.title == "Help")
            {
                this.Navigation.PushAsync(new ProductWalkthroughPage(){IsFromHelp = true});
            }
        }


    }
}

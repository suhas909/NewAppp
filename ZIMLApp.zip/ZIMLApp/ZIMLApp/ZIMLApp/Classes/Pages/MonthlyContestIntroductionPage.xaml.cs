﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Newtonsoft.Json;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// Quiz status enum.
    /// </summary>
    public enum QuizStatus
    {
        Not_Started,
        On_Going,
        Result_Pending,
        Result_Open
    }
    /// <summary>
    /// This class used to manages Monthly contest introduction page.
    /// </summary>
    public partial class MonthlyContestIntroductionPage : ContentPage
    {
        public QuizStatus quizStatus = QuizStatus.Not_Started;

        public string time = "1 hour";
        public string date = "Sunday, 3 June 2018, 11:59 PM";

        public ContestDetail contestDetail;
        public MonthlyContestDetailResponse detailResponse;
        private bool is_Back_from_Close_Attempt = false;

        public MonthlyContestIntroductionPage()
        {
            InitializeComponent();
            initiaiizeView();
            MessagingCenter.Subscribe<MonthlyContestQusetionPage>(this, "CLOSE_ATTEMPT",  (MonthlyContestQusetionPage obj) =>
            {
                //this.Navigation.PopModalAsync();
                is_Back_from_Close_Attempt = true;
            });
            if (Device.RuntimePlatform == Device.iOS) { Padding = new Thickness(0, 20, 0, 0); }
        }

        public void initiaiizeView()
        {
            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += (s, e) => {
                this.Navigation.PopModalAsync();
            };
            closeImg.GestureRecognizers.Add(tapGestureRecognizer);
            tapGestureRecognizer.NumberOfTapsRequired = 1;
        }

		protected override void OnAppearing()
		{
            base.OnAppearing();
            if (is_Back_from_Close_Attempt == true)
            {
                Navigation.PopModalAsync();
            }
            else
            {
                CheckForContestOpen();
                string html = "The competition has 20 questions and lasts " + contestDetail.getTime() + ". The answer to each question is a number.For example, \"20\", \" - 5\", \"3.14\" are all valid answers while \"20 mph\", \"5 / 2\" are not valid.";
                html = html + "\n\nNote: Once you start the competition you have one hour to complete the test.Please plan your time so you can finish the competition in a single session.";
                html = html + "\n\nAttempts allowed: 1";
                var timeopen = contestDetail.getStartDateFull();
                if (!string.IsNullOrEmpty(timeopen)) { html = html + "\n\nThis quiz opened at " + timeopen + ", 12:01 AM"; }

                FormattedString formattedhtml = new FormattedString();
                formattedhtml.Spans.Add(new Span { Text = html });
                var timeclose = contestDetail.getEndDateFull();
                if (!string.IsNullOrEmpty(timeclose)) { formattedhtml.Spans.Add(new Span { Text = "\n\nThis quiz will close at " + timeclose + ", 11:59 PM", FontAttributes = FontAttributes.None }); }
                formattedhtml.Spans.Add(new Span { Text = "\n\nTime limit: " + contestDetail.getTime() });

                introText.FormattedText = formattedhtml;

                timerTxt.Text = contestDetail.getTotalMinutes().ToString() + ":00";

            }
		}
        /// <summary>
        /// This mathod used to start the timer.
        /// </summary>
        void startTimer()
        {
            var totalMinutes = contestDetail.getTotalMinutes();
            var minute = totalMinutes - 1;
            var second = 60;
            var attempts = detailResponse.attempts;
            if (attempts != null && attempts.Count > 0)
            {
                DateTime startTime = CommonClass.FromUnixTime(Convert.ToInt64(attempts[0].timestart));
                DateTime currentTime = CommonClass.FromUnixTime(detailResponse.current_timestamp);//DateTime.Now.ToUniversalTime(); //Convert.ToDateTime(questions[0].currenttime);
                var diff = currentTime.Subtract(startTime).TotalMinutes;
                int remainingTime = (int)Convert.ToInt64(totalMinutes - diff);
                if (remainingTime < 0)
                {
                    // Do nothing not happen in actual case.
                }
                else if (remainingTime < totalMinutes)
                {
                    minute = remainingTime - 1;
                }
            }

            Device.StartTimer(TimeSpan.FromSeconds(1), () =>
            {
                second--;

                if (second == 0 && minute != 0)
                {
                    second = 59;
                    if (minute != 0)
                        minute--;
                }
                if (minute != 0 || minute == 0 && second != 0)
                {
                    timerTxt.Text = $"{minute.ToString("00")}:{second.ToString("00")}";

                    return true;
                }
                else
                {
                    timerTxt.Text = "00:00";
                    //showTimesUpAlert();
                    return false;
                }

            });
        }

        /// <summary>         /// This method manages the Continue button click and navigate to the Contest page where user can attempt the contest questions.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        async void ContinueClicked(object sender, System.EventArgs e)
        {
            if (quizStatus == QuizStatus.Not_Started)
            {
                bool value = await DisplayAlert("Confirmation", "This quiz has a time limit and is limited to one attempt. You are about to start a new attempt. Do you wish to proceed?", "Start attempt", "Cancel");
                if (value) { GetQuizDeatil(); }
            }
            else
            {
                var page = new MonthlyContestQusetionPage();
                page.contestDetail = contestDetail;
                page.detailResponse = detailResponse;
                await Navigation.PushModalAsync(page, false);
            }
        }

        void CheckForContestOpen()
        {
            DateTime openTime = CommonClass.FromUnixTime(Convert.ToInt64(contestDetail.timeopen));   
            DateTime closeTime = CommonClass.FromUnixTime(Convert.ToInt64(contestDetail.timeclose));
            DateTime currentTime = CommonClass.FromUnixTime(detailResponse.current_timestamp);//DateTime.Now.ToUniversalTime();
            var diffClose = closeTime.Subtract(currentTime).TotalMinutes;
            var diffOpen = currentTime.Subtract(openTime).TotalMinutes;
            if (diffClose < 0 || diffOpen < 0)
            {
                actionBtn.IsVisible = false;
            }
            else
            { 
                if (quizStatus == QuizStatus.Not_Started)
                {
                    actionBtn.Text = "Start Attempt";
                }
                else if (quizStatus == QuizStatus.On_Going)
                {
                    actionBtn.Text = "Continue";
                }

            }
        }
        /// <summary>
        /// Gets the quiz deatil from the API.
        /// </summary>
        public void GetQuizDeatil()
        {
            LoaderView.IsVisible = true;
            MonthlyContestDetailParam param = new MonthlyContestDetailParam();
            param.quiz_id = contestDetail.quiz_id;
            param.start_attempt = "yes";

            API.GetResponseFromServer(Constants.monthlyContestDetailAPI, param, async (content) => {
                MonthlyContestDetailResponse detail = JsonConvert.DeserializeObject<MonthlyContestDetailResponse>(content.ToString());
                LoaderView.IsVisible = false;
                if (detail != null)
                {
                    quizStatus = QuizStatus.On_Going;
                    var page = new MonthlyContestQusetionPage();
                    page.contestDetail = contestDetail;
                    page.detailResponse = detail;
                    await Navigation.PushModalAsync(page, false);
                }
            }, async (message, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
                else { await DisplayAlert(null, message, "Ok"); }

            });
        }
    }
}

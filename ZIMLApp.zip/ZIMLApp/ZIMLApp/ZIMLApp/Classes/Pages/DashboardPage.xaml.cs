﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;

namespace ZIMLApp.Classes.Pages
{

    /// <summary>
    /// This class manages the Dashboard of the app.
    /// </summary>
    public partial class DashboardPage : ContentPage
    {
        public DashboardPage()
        {
            InitializeComponent();
            NavigationPage.SetBackButtonTitle(this, " ");
            AddToolbarItems();
            InitPageData();
            if (string.IsNullOrEmpty(Preference.FacebookShareURL))
            {
                GetFacebookShareURL();
            }
        }

        private void AddToolbarItems()
        {
            //var refresh = new ToolbarItem
            //{
            //    //Command = ViewModel.LoadItemsCommand,
            //    Icon = "ic_notification_black.png",
            //    Priority = 0
            //};
            //ToolbarItems.Add(refresh);

           
        }

        private void InitPageData()
        {
            var masterPageItems = new List<MasterPageItem>();
            masterPageItems.Add(new MasterPageItem
            {
                Title = "Daily Magic Spells",
                IconSource = "daily_home.png",
                TargetType = typeof(DailyMagicSpellsPage)
            });
            masterPageItems.Add(new MasterPageItem
            {
                Title = "Monthly Contests",
                IconSource = "monthly_home.png",
                TargetType = typeof(MonthlyContestPage)
            });
            masterPageItems.Add(new MasterPageItem
            {
                Title = "Practice",
                IconSource = "practice_home.png",
                TargetType = typeof(PracticeListPage)
            });
            masterPageItems.Add(new MasterPageItem
            {
                Title = "Discussion Forum",
                IconSource = "forum_home.png",
                TargetType = typeof(ForumsListPage)
            });
            masterPageItems.Add(new MasterPageItem
            {
                Title = "News and Announcements",
                IconSource = "news_home.png",
                TargetType = typeof(NewsListPage)
            });

            //masterPageItems.Add(new MasterPageItem
            //{
            //    Title = "Subscription detail",
            //    IconSource = "news_home.png",
            //    TargetType = typeof(SubscriptionDetailPage)
            //});

            itemList.ItemsSource = masterPageItems;
        }

		protected override void OnAppearing()
		{
            base.OnAppearing();
            if (Preference.IsUserLoggedIn)
            {
                username.Text = Preference.FirstName + " " + Preference.LastName;
                profileImage.Source = CommonClass.getProfilePhotoUrl();
            }
            else
            {
                username.Text = "Guest User";
            }
            NavigationPage navigationPage = (NavigationPage)((HomePage)Application.Current.MainPage).Detail;
            navigationPage.BarTextColor = Color.Black;
            HomePage home = (HomePage)Application.Current.MainPage;
            if (home != null)
            {
                home.IsGestureEnabled = true;
            }
            GetUserProfileDetail();
            uploadProfilePhotoIfRequired();
		}

		protected override void OnDisappearing()
		{
            base.OnDisappearing();
            HomePage home = (HomePage)Application.Current.MainPage;
            if (home != null)
            {
                home.IsGestureEnabled = false;
            }
		}
        /// <summary>         /// This method manages the list item click event.         /// </summary>         /// <param name="sender">List item object.</param>         /// <param name="e">Event arguments.</param>
		async void ItemSelected(object sender, System.EventArgs e)
        {
            ViewCell cell = (ViewCell)sender;
            cell.IsEnabled = false;
            var item = itemList.SelectedItem as MasterPageItem;
            if (item != null)
            {
                var page = (Page)Activator.CreateInstance (item.TargetType);
                NavigationPage navigationPage = (NavigationPage)((HomePage)Application.Current.MainPage).Detail;
                await Navigation.PushAsync(page);
            }
            cell.IsEnabled = true;
        }
        /// <summary>
        /// Uploads the profile photo if required. This method calls on background if a user sign up from social media, then after sign up we get there profile picture from their social media and upload that on server. 
        /// </summary>
        public async void uploadProfilePhotoIfRequired()
        {
            if (!string.IsNullOrEmpty(Preference.UploadProfileUrl))
            {
                Debug.WriteLine("start downloading");
                var imageData =  await DownloadImageAsync(Preference.UploadProfileUrl);
                if (imageData != null)
                {  
                    Debug.WriteLine("start uploading");
                     UploadProfilePicture(imageData);
                }
            }
        }
        /// <summary>
        /// This method manages the upload of profile picture. 
        /// </summary>
        /// <param name="image">Profile picture image data.</param>
        public async void UploadProfilePicture(byte[] image)
        {
            if (!NetworkCheck.IsInternet())
            {
                //await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
                return;
            }

            using (var httpClient = new HttpClient())
            {
                MultipartFormDataContent multipartFormDataContent = new MultipartFormDataContent();
                var imageContent = new ByteArrayContent(image, 0, image.Length);
                imageContent.Headers.ContentType = MediaTypeHeaderValue.Parse("multipart/form-data");
                multipartFormDataContent.Add(imageContent, "repo_upload_file", "user_profile.jpg");

                StringContent userIdContent = new StringContent(Preference.DeviceId);
                StringContent tokenContent = new StringContent(Preference.AccessToken);
                multipartFormDataContent.Add(userIdContent, "access_device_id");
                multipartFormDataContent.Add(tokenContent, "access_auth_key");

                try
                {
                    var response = await httpClient.PostAsync(Constants.updateProfilePhotoAPI, multipartFormDataContent);
                    var content = response.Content;
                    var jsonString = await content.ReadAsStringAsync();
                    Debug.WriteLine($"json response : {jsonString}");

                    UpdateProfilePhotoResponse responseJson = JsonConvert.DeserializeObject<UpdateProfilePhotoResponse>(jsonString);
                    if (responseJson.status == "error")
                    {
                        //await DisplayAlert(null, responseJson.message, "Ok");
                    }
                    else
                    {
                        //await DisplayAlert(null, "Profile Image updated successfully. Please sign in to see the changes.", "Ok");
                        Preference.UploadProfileUrl = "";
                    }
                }
                catch (Exception ex)
                {
                    //await DisplayAlert(null, "Somthing went wrong. Please try again later.", "Ok");
                    Debug.WriteLine("error" + ex.Message);
                    Debug.WriteLine("error" + ex.StackTrace);
                }

            }
        }
        /// <summary>
        /// Downloads the image from URL.
        /// </summary>
        /// <returns>The image data as byte array.</returns>
        /// <param name="imageUrl">Image URL.</param>
        async Task<byte[]> DownloadImageAsync(string imageUrl)
        {
            try
            {
                using (var httpResponse = await new HttpClient().GetAsync(imageUrl))
                {
                    if (httpResponse.StatusCode == HttpStatusCode.OK)
                    {
                        return await httpResponse.Content.ReadAsByteArrayAsync();
                    }
                    else
                    {
                        //Url is Invalid
                        return null;
                    }
                }
            }
            catch (Exception e)
            {
                //Handle Exception
                return null;
            }
        }
        /// <summary>
        /// Gets the user profile detail.
        /// </summary>
        public void GetUserProfileDetail()
        {
            API.GetResponseFromServer(Constants.profileDetailAPI, new ProfileDetailParam(), HandleSuccess, HandleFailure);
        }
        /// <summary>
        /// Handles the success for profile detail.
        /// </summary>
        /// <param name="contents">Contents object return from the API call.</param>
        void HandleSuccess(object contents)
        {
            ProfileDetail profileDetail = JsonConvert.DeserializeObject<ProfileDetail>(contents.ToString());
            pointsLb.Text = profileDetail.GetPoints();

        }
        /// <summary>         /// Handles the failure for profile detail.         /// </summary>         /// <param name="message">Message related to the failure.</param>         /// <param name="errorType">Error type.</param>
        void HandleFailure(string message, ErrorType errorType)
        {
            //if (errorType == ErrorType.Network)
            //{
            //    await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
            //}
            //else
            //{
            //    await DisplayAlert(null, message, "Ok");
            //}
        }

        void GetFacebookShareURL()
        {
            API.GetResponseFromServer(Constants.contactUsDetailAPI, new RequestParam(), (content) =>
            {
                ContactDetail detail = JsonConvert.DeserializeObject<ContactDetail>(content.ToString());

                Preference.FacebookShareURL = detail.facebook_share;

            }, (message, errorType) =>
            {
                Debug.WriteLine(message);
            });
        }
    }
}

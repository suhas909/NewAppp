﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;
using System.Linq;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages to show the Practice contest details page.
    /// </summary>
    public partial class PracticeDetailPage : ContentPage
    {
        public Contest contest;
        public bool isForSampleZiml = false;
        PracticeDetailResponse detailResponse;
        //private int total_time = 40; //TEMP:TODO
        public string is_new_attempt = "no";
        public string current_attempt_id;
        private bool is_Back_from_Close_Attempt = false;
        private bool is_Stop_Timer = false;

        public DateTime currentTime = DateTime.Now.ToUniversalTime();
        bool is_timer_runing = false;
        private List<Attempts> previousAttemptList = new List<Attempts>();

        public PracticeDetailPage()
        {
            InitializeComponent();
            if (Device.RuntimePlatform == Device.iOS) { Padding = new Thickness(0, 20, 0, 0); }
            MessagingCenter.Subscribe<PracticeQuestionPage>(this, "ATTEMPT_FINISHED", (PracticeQuestionPage obj) =>
            {
                is_Back_from_Close_Attempt = true;
                is_Stop_Timer = true;
            });
            initiaiizeView();
        }

		protected override void OnAppearing()
		{
            base.OnAppearing();
            titleLb.Text = contest.name;
            current_attempt_id = null;
            GetQuizDeatil();
		}

		public void initiaiizeView()
        {
            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += (s, e) => {
                this.Navigation.PopModalAsync();
            };
            closeImg.GestureRecognizers.Add(tapGestureRecognizer);
            tapGestureRecognizer.NumberOfTapsRequired = 1;
        }
        /// <summary>
        /// This method used to start the timer.
        /// </summary>
        void startTimer()
        {
            if (is_timer_runing) return;

            var totalMinutes = detailResponse.getTotalMinutes();
            if (totalMinutes == 0)
            {
                //timerTxt.IsVisible = false;
                return;
            }
            var totalTimeSpan = TimeSpan.FromSeconds(Convert.ToInt64(detailResponse.timelimit));
            totalTimeSpan = totalTimeSpan.Subtract(new TimeSpan(0, 0, 1));
            int hr = totalTimeSpan.Hours;
            var minute = totalTimeSpan.Minutes;
            var second = totalTimeSpan.Seconds;

            List<Attempts> attempts = detailResponse.attempts;
            if (attempts != null && attempts.Count > 0)
            {
                DateTime startTime = CommonClass.FromUnixTime(Convert.ToInt64(attempts.Last().timestart));
                DateTime currentTime = CommonClass.FromUnixTime(detailResponse.current_timestamp);
                var diffSpan = currentTime.Subtract(startTime);
                var remainingTimeSpan = totalTimeSpan.Subtract(diffSpan);
                if (remainingTimeSpan.TotalSeconds < 0)
                {
                    // Do nothing not happen in actual case.
                }
                else if (remainingTimeSpan.TotalMinutes < totalMinutes)
                {
                    remainingTimeSpan = remainingTimeSpan.Subtract(new TimeSpan(0, 0, 1));
                    hr = remainingTimeSpan.Hours;
                    minute = remainingTimeSpan.Minutes;
                    second = remainingTimeSpan.Seconds;
                }
            }

            Device.StartTimer(TimeSpan.FromSeconds(1), () =>
            {
                if (is_Stop_Timer)
                {
                    is_timer_runing = false;
                    is_Stop_Timer = false;
                    return false;
                }
                is_timer_runing = true;
                second--;
                if (second == 0 && minute == 0 && hr != 0)
                {
                    minute = 59;
                    second = 59;
                    if (hr != 0)
                        hr--;
                }
                if (second == 0 && minute != 0)
                {
                    second = 59;
                    if (minute != 0)
                        minute--;
                }
                if (hr != 0 || minute != 0 || minute == 0 && second != 0)
                {
                    if (hr == 0)
                        timerTxt.Text = $"{minute.ToString("00")}:{second.ToString("00")}";
                    else
                        timerTxt.Text = $"{hr}:{minute.ToString("00")}:{second.ToString("00")}";

                    return true;
                }
                else
                {
                    timerTxt.Text = "00:00";
                    is_timer_runing = false;
                    showTimesUpAlert();
                    return false;
                }
            });
        }
        /// <summary>
        /// This method is used to Shows the times up alert if the time is over for the contest.
        /// </summary>
        async void showTimesUpAlert()
        {
            await DisplayAlert(null, "Times up !", "OK");
            FinishAttempt(detailResponse.attempts.Last().id);
        }


        /// <summary>         /// This method manages the start attempt button click and navigate to the contest detail page.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void Handle_Clicked(object sender, System.EventArgs e)
        {
            Navigation.PushModalAsync(new PracticeQuestionPage(){contest = contest, is_new_attempt = is_new_attempt, current_attempt_id = current_attempt_id});
        }


        /// <summary>         /// This method manages the Try again button clicked, and try to reload the data.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void TryAgain_Clicked(object sender, System.EventArgs e)
        {
            LoaderView.IsVisible = true;
            ErrorView.IsVisible = false;
            GetQuizDeatil();
        }

        /// <summary>         /// This method manages the Review button click. And navigate to the attempt summary page for the related list item.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void Review_Clicked(object sender, System.EventArgs e)
        {
            var btn = (Button)sender;
            btn.IsEnabled = false;
            Attempts attempt = previousAttemptList.Find(x => x.id == btn.CommandParameter.ToString());
            GetQuizDeatilForAttempt(attempt);
        }
        /// <summary>
        /// Gets the quiz deatil form the API.
        /// </summary>
        public void GetQuizDeatil()
        {
            LoaderView.IsVisible = true;
            PracticeDeatilParam param = new PracticeDeatilParam();
            param.quiz_id = contest.quiz_id;
            param.new_attempt = "no";

            API.GetResponseFromServer(Constants.practiceDetailAPI, param, (content) => {
                detailResponse = JsonConvert.DeserializeObject<PracticeDetailResponse>(content.ToString());
                LoaderView.IsVisible = false;
                if (detailResponse != null)
                {
                    introText.Text = "Time limit: " + detailResponse.getTime();
                    currentTime = CommonClass.FromUnixTime(detailResponse.current_timestamp);
                    Attempts attempt;
                    bool isAttemptOver = false;
                    if (detailResponse.attempts != null && detailResponse.attempts.Count > 0)
                    {
                        var attemptsList = detailResponse.attempts;
                        attempt = detailResponse.attempts.Last();
                        var totalMinutes = detailResponse.getTotalMinutes();
                        if (attempt.timefinish == "0" )
                        {
                            isAttemptOver = CheckAttemptTimeOver(attempt.timestart, detailResponse.getTotalMinutes());
                            if (totalMinutes != 0 && isAttemptOver == true)
                            {
                                FinishAttempt(attempt.id);
                            }
                            else
                            {
                                if (attemptsList.Count > 0)
                                {
                                    previousAttemptList = new List<Attempts>(attemptsList);
                                    previousAttemptList.RemoveAt(attemptsList.Count - 1);
                                    recentAttemptList.ItemsSource = previousAttemptList;

                                }
                                current_attempt_id = attempt.id;
                                actionBtn.Text = "Continue";
                                is_new_attempt = "no";
                                startTimer();
                            }
                        }
                        else
                        {
                            actionBtn.Text = "Re-attempt Quiz";
                            previousAttemptList = attemptsList;
                            recentAttemptList.ItemsSource = previousAttemptList;
                            is_new_attempt = "yes";
                            timerTxt.Text = detailResponse.getTimerText();
                            if (is_Back_from_Close_Attempt)
                            {
                                is_Back_from_Close_Attempt = false;
                                GetQuizDeatilForAttempt(attempt);

                            }
                        }
                    }
                    else 
                    {
                        actionBtn.Text = "Start Attempt";
                        is_new_attempt = "yes";
                        timerTxt.Text = detailResponse.getTimerText();
                    }
                }
            }, (message, errorType) => {
                LoaderView.IsVisible = false;
                ErrorView.IsVisible = true;
                if (errorType == ErrorType.Network)
                {
                    ErrorTitle.Text = Constants.NetworkErrorTitle;
                    ErrorMessage.Text = Constants.NetworkErrorMessage;
                    ActionButton.Text = "Try again";
                }
                else
                {
                    ErrorTitle.Text = Constants.ServerErrorTitle;
                    ErrorMessage.Text = Constants.ServerErrorMessage;
                    ActionButton.Text = "Refresh";
                }
            });
        }
        /// <summary>
        /// Gets the quiz deatil for a attempt from the API
        /// </summary>
        /// <param name="attempt">Attempt object</param>
        public void GetQuizDeatilForAttempt(Attempts attempt)
        {
            LoaderView.IsVisible = true;
            PracticeDeatilParam param = new PracticeDeatilParam();
            param.quiz_id = contest.quiz_id;
            param.new_attempt = "no";
            param.attempt_id = attempt.id;

            API.GetResponseFromServer(Constants.practiceDetailAPI, param, (content) => {
                detailResponse = JsonConvert.DeserializeObject<PracticeDetailResponse>(content.ToString());
                LoaderView.IsVisible = false;
                if (detailResponse != null && detailResponse.current_attempt != null)
                {
                    Navigation.PushModalAsync(new PracticeResultPage()
                    {
                        contest = contest,
                        questions = detailResponse.current_attempt.questions,
                        attempt = attempt,
                        isForSampleZiml = isForSampleZiml
                    });
                }
            }, (message, errorType) => {
                LoaderView.IsVisible = false;
                ErrorView.IsVisible = true;
                if (errorType == ErrorType.Network)
                {
                    ErrorTitle.Text = Constants.NetworkErrorTitle;
                    ErrorMessage.Text = Constants.NetworkErrorMessage;
                    ActionButton.Text = "Try again";
                }
                else
                {
                    ErrorTitle.Text = Constants.ServerErrorTitle;
                    ErrorMessage.Text = Constants.ServerErrorMessage;
                    ActionButton.Text = "Refresh";
                }
            });
        }
        /// <summary>
        /// This method manages the API call for Finish attempt.
        /// </summary>
        /// <param name="attemptId">Attempt identifier.</param>
        public void FinishAttempt(string attemptId)
        {
            var param = new FinishAttemptParam();
            param.attempt_id = attemptId;
            LoaderView.IsVisible = true;
            API.GetResponseFromServer(Constants.monthlyContestFinishAttemptAPI, param, (content) => {
                GetQuizDeatil();
            },
            async (message, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
                else { await DisplayAlert(null, message, "Ok"); }
            });
        }

        bool CheckAttemptTimeOver(string timestart, int totalMinutes)
        {
            DateTime startTime = CommonClass.FromUnixTime(Convert.ToInt64(timestart));
            //DateTime currentTime = DateTime.Now.ToUniversalTime();
            var diff = currentTime.Subtract(startTime).TotalMinutes;
            int remainingTime = (int)Convert.ToInt64(totalMinutes - diff);
            if (remainingTime < 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}

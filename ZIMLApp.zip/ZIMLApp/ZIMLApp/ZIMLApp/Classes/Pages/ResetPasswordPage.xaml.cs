﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Utility;
using ZIMLApp.Classes.Model;
using Newtonsoft.Json;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages the Reset password functionality.
    /// </summary>
    public partial class ResetPasswordPage : ContentPage
    {
        public string EmailId = "";
        public string otp_successful_validation_token = "";
        public ResetPasswordPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            initView();
        }

        private void initView()
        {
            //loaderWebView.Source = CommonClass.GetLoaderWebViewSource();

            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += (s, e) =>
            {
                this.Navigation.PopModalAsync();
            };
            imgBack.GestureRecognizers.Add(tapGestureRecognizer);
            tapGestureRecognizer.NumberOfTapsRequired = 1;
        }

        /// <summary>         /// This method manages the Set New Password button click.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void SetNewPwd_Clicked(object sender, System.EventArgs e)
        {
            if(CheckValidations())
            {
                ResetPasswordParams resetPasswordParams = new ResetPasswordParams();
                resetPasswordParams.otp_successful_validation_token = otp_successful_validation_token;
                resetPasswordParams.email_id = EmailId;
                resetPasswordParams.password = newPwd.Text;
                ResetPassword(resetPasswordParams);
            }
        }

        /// <summary>
        /// This mathod manages the Reset password API call.
        /// </summary>
        /// <param name="param">Reset Password API Parameter.</param>
        public void ResetPassword(ResetPasswordParams param)
        {
            LoaderView.IsVisible = true;
            API.GetResponseFromServer(Constants.resetPasswordAPI, param, HandleSuccess, HandleFailure);
        }

        /// <summary>         /// Handles the success for reset password API.         /// </summary>         /// <param name="contents">Contents object return from the API call.</param>
        async void HandleSuccess(object contents)
        {
            //SignInDetail signInDetail = JsonConvert.DeserializeObject<SignInDetail>(contents.ToString());
            //Debug.WriteLine(signInDetail.first_name);
            LoaderView.IsVisible = false;
            await DisplayAlert(null, "Password reset, please login to continue.", "Ok");
            Application.Current.MainPage = new SignInPage();
        }

        /// <summary>         /// Handles the failure for the API call         /// </summary>         /// <param name="message">Message related to the failure.</param>         /// <param name="errorType">Error type.</param>
        async void HandleFailure(string message, ErrorType errorType)
        {
            LoaderView.IsVisible = false;
            if (errorType == ErrorType.Network)
            {
                await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
            }
            else
            {
                await DisplayAlert(null, message, "Ok");
            }
        }

        /// <summary>
        /// Checks the validations.
        /// </summary>
        /// <returns><c>true</c>, if validations was checked, <c>false</c> otherwise.</returns>
        private bool CheckValidations()
        {
            bool returnValue = true;

            if (string.IsNullOrEmpty(newPwd.Text))
            {
                ErrorNewPwd.Text = "Please enter new password";
                returnValue = false;
            }
            else if (!CommonClass.IsPasswordValid(newPwd.Text))
            {
                ErrorNewPwd.Text = "The password must have at least 8 characters, at least 1 digit(s), at least 1 upper case letter(s), at least 1 lower case letter(s)";
                returnValue = false;
            }
            else
            {
                ErrorNewPwd.Text = "";
            }

            if (string.IsNullOrEmpty(confirmPwd.Text))
            {
                ErrorConfirmPwd.Text = "Please enter confirm password";
                returnValue = false;
            }
            else if (newPwd.Text != confirmPwd.Text)
            {
                ErrorConfirmPwd.Text = "Password mismatch";
                returnValue = false;
            }
            else
            {
                ErrorConfirmPwd.Text = "";
            }


            return returnValue;
        }
    }
}

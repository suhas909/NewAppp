﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages to show the Practice AMC List page.
    /// </summary>
    public partial class PracticeAMCListPage : ContentPage
    {
        public List<Contest> AMCContestList = new List<Contest>();
        public AMCContest amcContest;

        public PracticeAMCListPage()
        {
            InitializeComponent();
            Title = "Practice";

        }

		protected override void OnAppearing()
		{
            base.OnAppearing();
            practiceDetailListView.ItemsSource = AMCContestList;
            Title = "Practice " + amcContest.name + " Series";
		}
        /// <summary>
        /// This method manages the List item click event. And navigate to the detail page for the related item.
        /// </summary>
        /// <param name="sender">List item object</param>
        /// <param name="e">Event arguments.</param>
        async void Handle_AMCTapped(object sender, Xamarin.Forms.ItemTappedEventArgs e)
        {
            if (!Preference.IsUserLoggedIn)
            {
                await DisplayAlert(null, "Please sign in to attempt practice contest.", "Ok");
                Application.Current.MainPage = new NavigationPage(new SplashScreenPage());
            }
            else
            {
                Contest contestDetail = (Contest)practiceDetailListView.SelectedItem;
                await Navigation.PushModalAsync(new PracticeDetailPage() { contest = contestDetail });
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using Newtonsoft.Json;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;

namespace ZIMLApp.Classes.Pages
{

    /// <summary>
    /// This class manages to show the Practice questions page.
    /// </summary>
    public partial class PracticeQuestionPage : ContentPage
    {
        //public ContestDetail contestDetail;

        public Contest contest;

        public string is_new_attempt = "no";
        public string current_attempt_id;

        List<string> answerOptionList = new List<string>()
        {
            "A","B","C","D","E"
        };

        bool is_timer_runing = false;

        public PracticeDetailResponse detailResponse;

        private int currentIndex = 0;

        private string Question_Type_MCQ = "multichoice";
        private string Question_Type_Numerical = "numerical";

        private List<Question> questions = new List<Question>();
        private List<Attempts> attempts = new List<Attempts>();
        private CurrentAttempt currentAttempt;

        private ObservableCollection<AnswerSummary> answerSummaryList = new ObservableCollection<AnswerSummary>();


        public PracticeQuestionPage()
        {
            InitializeComponent();
            //answerPicker.ItemsSource = answerOptionList;
            if (Device.RuntimePlatform == Device.iOS) { Padding = new Thickness(0, 20, 0, 0); }
            questionWebview.HeightRequest = Application.Current.MainPage.Height - 150;
            initiaiizeView();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            if (contest.name.Contains("AMC 10") || contest.name.Contains("AMC 12")) { answerOptionList.Add("Leave blank (1.5 points)"); }
            answerPicker.ItemsSource = answerOptionList;
            //questions = detailResponse.questions;
            //attempts = detailResponse.attempts;
            //InitSummaryData();
            //startTimer();
            //answerEntry.Text = answerSummaryList[currentIndex].answer;
            //setDataOnView(questions[0].questiontext, questions[0].id);
            //LoaderView.IsVisible = false;
            GetQuizDeatil();
        }

        protected override bool OnBackButtonPressed()
        {
            Device.BeginInvokeOnMainThread(async () => {
                bool value = await DisplayAlert(null, "Are you sure you want close the attempt?", "Yes", "No");
                if (value) { await this.Navigation.PopModalAsync(); }
            });
            return true;
        }

        public void initiaiizeView()
        {
            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += async (s, e) => {
                bool value = await DisplayAlert(null, "Are you sure you want close the attempt?", "Yes", "No");
                if (value)
                {
                    if (Device.RuntimePlatform == Device.Android)
                    {
                        await Navigation.PopModalAsync(false);
                    }
                    else
                    {
                        Navigation.PopModalAsync(false);
                    }

                }
            };
            closeImg.GestureRecognizers.Add(tapGestureRecognizer);
            tapGestureRecognizer.NumberOfTapsRequired = 1;

            var answerPickerTGR = new TapGestureRecognizer();
            answerPickerTGR.Tapped += (s, e) =>
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    if (answerPicker.IsFocused)
                        answerPicker.Unfocus();

                    answerPicker.Focus();
                });
               
            };
            answerPickerImage.GestureRecognizers.Add(answerPickerTGR);
            answerPickerTGR.NumberOfTapsRequired = 1;


            var nextTGR = new TapGestureRecognizer();
            nextTGR.Tapped += NextClicked;
            nextImg.GestureRecognizers.Add(nextTGR);
            nextTGR.NumberOfTapsRequired = 1;

            var previousTGR = new TapGestureRecognizer();
            previousTGR.Tapped += PreviousClicked;
            previousImg.GestureRecognizers.Add(previousTGR);
            previousTGR.NumberOfTapsRequired = 1;

            var summaryTGR = new TapGestureRecognizer();
            summaryTGR.Tapped += ViewSummaryClicked;
            summaryImg.GestureRecognizers.Add(summaryTGR);
            summaryTGR.NumberOfTapsRequired = 1;

            titleTxt.Text = "Question " + (currentIndex + 1);
            previousImg.IsVisible = false;

        }
        /// <summary>
        /// Sets the data on view.
        /// </summary>
        /// <param name="html">Question test</param>
        /// <param name="question_id">Question identifier.</param>
        public void setDataOnView(string html, string question_id)
        {
            string htmlstr = WebUtility.HtmlDecode(html);
            string baseurl = getBaseUrlForImages(question_id);
            htmlstr = htmlstr.Replace("@@PLUGINFILE@@/", baseurl);

            string htmlData = CommonClass.getHTMLContent(htmlstr);
            var url = new HtmlWebViewSource { Html = htmlData };
            questionWebview.Source = url;
        }
        /// <summary>
        /// this method is used to Start the timer.
        /// </summary>
        void startTimer()
        {
            if (is_timer_runing) return;
            var totalMinutes = detailResponse.getTotalMinutes();
            if (totalMinutes == 0)
            {
                timerTxt.IsVisible = false;
                return;
            }
            var totalTimeSpan = TimeSpan.FromSeconds(Convert.ToInt64(detailResponse.timelimit));
            totalTimeSpan = totalTimeSpan.Subtract(new TimeSpan(0, 0, 1));
            int hr = totalTimeSpan.Hours;
            var minute = totalTimeSpan.Minutes; 
            var second = totalTimeSpan.Seconds; 

            if (attempts != null && attempts.Count > 0)
            {
                var remainingTimeSpan = totalTimeSpan;
                if (is_new_attempt == "no")
                {
                    DateTime startTime = CommonClass.FromUnixTime(Convert.ToInt64(attempts.Last().timestart));
                    DateTime currentTime = CommonClass.FromUnixTime(detailResponse.current_timestamp);
                    var diffSpan = currentTime.Subtract(startTime);
                    remainingTimeSpan = totalTimeSpan.Subtract(diffSpan);
                }
                if (remainingTimeSpan.TotalSeconds < 0)
                {
                    // Do nothing not happen in actual case.
                }
                else if (remainingTimeSpan.TotalMinutes < totalMinutes)
                {
                    remainingTimeSpan = remainingTimeSpan.Subtract(new TimeSpan(0, 0, 1));
                    hr = remainingTimeSpan.Hours;
                    minute = remainingTimeSpan.Minutes; 
                    second = remainingTimeSpan.Seconds;
                }
            }

            Device.StartTimer(TimeSpan.FromSeconds(1), () =>
            {
                is_timer_runing = true;
                second--;
                if (second == 0 && minute == 0 && hr != 0)
                {
                    minute = 59;
                    second = 59;
                    if (hr != 0) 
                        hr--;
                }
                if (second == 0 && minute != 0)
                {
                    second = 59;
                    if (minute != 0)
                        minute--;
                }
                if (hr != 0 || minute != 0 || minute == 0 && second != 0)
                {
                    if (hr == 0)
                        timerTxt.Text = $"{minute.ToString("00")}:{second.ToString("00")}";
                    else
                        timerTxt.Text = $"{hr}:{minute.ToString("00")}:{second.ToString("00")}";

                    return true;
                }
                else
                {
                    timerTxt.Text = "00:00";
                    is_timer_runing = false;
                    showTimesUpAlert();
                    return false;
                }

            });
        }
        /// <summary>
        /// Shows the times up alert if the contest time over.
        /// </summary>
        async void showTimesUpAlert()
        {
            await DisplayAlert(null, "Times up !", "OK");
            FinishAttempt(current_attempt_id);
        }
        /// <summary>
        /// Create the summary list data to show the contest summary page.
        /// </summary>
        void InitSummaryData()
        {
            for (int i = 0; i < questions.Count; i++)
            {
                if (is_new_attempt == "yes")
                {
                    answerSummaryList.Add(new AnswerSummary(i));
                }
                else if (attempts.Last().submitted_answers?.Count > 0)
                {
                    var submittedAnswerArr = attempts.Last().submitted_answers;
                    List<SubmittedAnswer> submittedAnswer = submittedAnswerArr.FindAll((obj) => obj.slot == (i + 1).ToString());
                    if (submittedAnswer != null && submittedAnswer.Count > 0)
                    {
                        string sequence = (Convert.ToInt32(submittedAnswer.Last().sequence) + 1).ToString();
                        answerSummaryList.Add(new AnswerSummary(i, sequence, submittedAnswer.Last().answer));
                    }
                    else
                    {
                        answerSummaryList.Add(new AnswerSummary(i));
                    }
                }
                else
                {
                    answerSummaryList.Add(new AnswerSummary(i));
                }

            }
            summaryList.ItemsSource = answerSummaryList;
        }

        void SetDataOnField(int index)
        {
            if (questions[index].type == Question_Type_MCQ)
            {
                PickerAnsView.IsVisible = true;
                EditTextAnsView.IsVisible = false;
                answerPicker.SelectedIndex = -1;
                if (!string.IsNullOrEmpty(answerSummaryList[index].answer))
                {
                    int selectedIndex = (int)Convert.ToInt64(answerSummaryList[index].answer);
                    if (selectedIndex < answerOptionList.Count)
                    {
                        answerPicker.SelectedItem = answerOptionList[selectedIndex];
                    }

                }
            }
            else
            {
                PickerAnsView.IsVisible = false;
                EditTextAnsView.IsVisible = true;
                answerEntry.Text = answerSummaryList[index].answer;
            }
            setDataOnView(questions[index].questiontext, questions[index].id);
        }

        /// <summary>
        /// This method manages the Next button click and move to the next question.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void NextClicked(object sender, System.EventArgs e)
        {
            moveNext();
        }

        // <summary>
        /// This method manages the Previous button click and move to the previous question.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void PreviousClicked(object sender, System.EventArgs e)
        {
            movePrivious();
        }

        /// <summary>
        /// This method manages the submit button click.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void SubmitForQuestionClicked(object sender, System.EventArgs e)
        {
            if (questions[currentIndex].type == Question_Type_MCQ)
            {
                if (answerPicker.SelectedIndex >= 0 && answerSummaryList[currentIndex].answer != answerPicker.SelectedItem.ToString())
                {
                    string selectedIndex = answerOptionList.IndexOf(answerPicker.SelectedItem.ToString()).ToString();
                    SubmitAnswer(current_attempt_id, answerSummaryList[currentIndex].slot, selectedIndex, answerSummaryList[currentIndex].sequence);
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(answerEntry.Text) && answerSummaryList[currentIndex].answer != answerEntry.Text)
                {
                    double ansValue;
                    bool isDoubleVaue = double.TryParse(answerEntry.Text, out ansValue);
                    if (isDoubleVaue) SubmitAnswer(current_attempt_id, answerSummaryList[currentIndex].slot, answerEntry.Text, answerSummaryList[currentIndex].sequence);
                    else DisplayAlert(null, "You must enter a valid number. Do not include a unit in your response.", "Ok");
                }
            }

        }

        /// <summary>
        /// This method manages the submit attempt button click.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void SubmitAttemptClicked(object sender, System.EventArgs e)
        {

            FinishAttempt(current_attempt_id);
        }

        /// <summary>
        /// This method manages the View summary button click and show the summary page on click.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void ViewSummaryClicked(object sender, System.EventArgs e)
        {
            if (summaryView.IsVisible == false)
            {
                showSummaryView();
            }
        }


        /// <summary>
        /// This method manages the Summary cell item click and show question related to that cell item.
        /// </summary>
        /// <param name="sender">List item object</param>
        /// <param name="e">Event arguments.</param>
        void SummaryCellTapped(object sender, System.EventArgs e)
        {
            AnswerSummary answer = (AnswerSummary)summaryList.SelectedItem;
            int index = answerSummaryList.IndexOf(answer);
            currentIndex = index;
            hideSummaryView();
        }

        /// <summary>
        /// This method used to move to the next question.
        /// </summary>
        void moveNext()
        {
            if (currentIndex < questions.Count - 1)
            {
                currentIndex++;
                //setDataOnView(questions[currentIndex].questiontext, questions[currentIndex].id);
                titleTxt.Text = "Question " + (currentIndex + 1);
                //answerEntry.Text = answerSummaryList[currentIndex].answer;
                previousImg.IsVisible = true;
                progressBar.Progress = (currentIndex + 1.0) / questions.Count;
                SetDataOnField(currentIndex);
            }
            else
            {
                showSummaryView();
            }
        }

        /// <summary>
        /// This method used to move to the previous question.
        /// </summary>
        void movePrivious()
        {
            if (summaryView.IsVisible == true)
            {
                hideSummaryView();
            }
            else
            {
                currentIndex--;
                //setDataOnView(questions[currentIndex].questiontext, questions[currentIndex].id);
                titleTxt.Text = "Question " + (currentIndex + 1);
                //answerEntry.Text = answerSummaryList[currentIndex].answer;
                progressBar.Progress = (currentIndex + 1.0) / questions.Count;
                if (currentIndex == 0) previousImg.IsVisible = false;
                SetDataOnField(currentIndex);
            }

        }

        /// <summary>
        /// This method show the summary view page.
        /// </summary>
        void showSummaryView()
        {
            questionView.IsVisible = false;
            summaryView.IsVisible = true;
            nextImg.IsVisible = false;
            previousImg.IsVisible = true;
            titleTxt.Text = "Question Summary";
        }

        /// <summary>
        /// This method is used to hides the summary view.
        /// </summary>
        void hideSummaryView()
        {
            questionView.IsVisible = true;
            summaryView.IsVisible = false;
            nextImg.IsVisible = true;
            if (currentIndex == 0) previousImg.IsVisible = false;
            //setDataOnView(questions[currentIndex].questiontext, questions[currentIndex].id);
            titleTxt.Text = "Question " + (currentIndex + 1);
            //answerEntry.Text = answerSummaryList[currentIndex].answer;
            progressBar.Progress = (currentIndex + 1.0) / questions.Count;
            SetDataOnField(currentIndex);
        }

        private string getBaseUrlForImages(string question_id)
        {
            // Eg: https://zimlapp.areteem.org/api/images/question.php?quiz_id=906&question_id=7522&filename=%5B180601%5D.png&filearea=questiontext

            string baseUrl = Constants.baseURL + "/api/images/question.php?quiz_id=" + contest.quiz_id + "&question_id=" + question_id + "&filearea=questiontext&filename=";
            //string baseUrl = "https://zimlapp.areteem.org/api/images/question.php?quiz_id=" + "851" + "&question_id=" + question_id + "&filearea=questiontext&filename=";
            return baseUrl;
        }

        void TryAgain_Clicked(object sender, System.EventArgs e)
        {
            LoaderView.IsVisible = true;
            ErrorView.IsVisible = false;
            GetQuizDeatil();
        }
        /// <summary>
        /// Gets the Practice quiz deatil from API.
        /// </summary>
        public void GetQuizDeatil()
        {
            LoaderView.IsVisible = true;
            PracticeDeatilParam param = new PracticeDeatilParam();
            param.quiz_id = contest.quiz_id;
            param.new_attempt = is_new_attempt;
            if (current_attempt_id != null)
            {
                param.attempt_id = current_attempt_id;
            }

            API.GetResponseFromServer(Constants.practiceDetailAPI, param, (content) => {
                detailResponse = JsonConvert.DeserializeObject<PracticeDetailResponse>(content.ToString());
                LoaderView.IsVisible = false;
                if (detailResponse != null && detailResponse.current_attempt != null)
                {
                    currentAttempt = detailResponse.current_attempt;
                    current_attempt_id = currentAttempt.id.ToString();
                    questions = currentAttempt.questions;
                    attempts = detailResponse.attempts;
                    InitSummaryData();
                    startTimer();
                    SetDataOnField(currentIndex);

                }
            }, (message, errorType) => {
                LoaderView.IsVisible = false;
                ErrorView.IsVisible = true;
                if (errorType == ErrorType.Network)
                {
                    ErrorTitle.Text = Constants.NetworkErrorTitle;
                    ErrorMessage.Text = Constants.NetworkErrorMessage;
                    ActionButton.Text = "Try again";
                }
                else
                {
                    ErrorTitle.Text = Constants.ServerErrorTitle;
                    ErrorMessage.Text = Constants.ServerErrorMessage;
                    ActionButton.Text = "Refresh";
                }
            });
        }

        /// <summary>
        /// This method manages the call for submit answer API.
        /// </summary>
        /// <param name="attempt_id">Attempt identifier.</param>
        /// <param name="slot">Slot number for the question</param>
        /// <param name="answer">Answer text</param>
        /// <param name="sequence">Sequence for the answer.</param>
        public void SubmitAnswer(string attempt_id, string slot, string answer, string sequence)
        {
            LoaderView.IsVisible = true;
            MonthlyContestSubmitAnswerParam param = new MonthlyContestSubmitAnswerParam();
            param.quiz_id = contest.quiz_id;
            param.attempt_id = attempt_id;
            param.slot = slot;
            param.answer = answer;
            param.sequence = sequence;

            API.GetResponseFromServer(Constants.monthlyContestSubmitAnswerAPI, param, (content) => {
                //MonthlyContestDetailResponse detail = JsonConvert.DeserializeObject<MonthlyContestDetailResponse>(content.ToString());
                LoaderView.IsVisible = false;
                var answerSummary = answerSummaryList[currentIndex];
                answerSummary.answer = answer;
                answerSummary.sequence = (Convert.ToInt32(sequence) + 1).ToString();
                answerSummaryList[currentIndex] = answerSummary;

                answerEntry.Text = "";
                answerPicker.SelectedIndex = -1;
                moveNext();
            }, async (message, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network)
                    await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
                else
                    await DisplayAlert(null, message, "Ok");
            });
        }

        /// <summary>
        /// This method manages the call for Finish attempt API.
        /// </summary>
        /// <param name="attemptId">Attempt identifier.</param>
        public void FinishAttempt(string attemptId)
        {
            var param = new FinishAttemptParam();
            param.attempt_id = attemptId;
            LoaderView.IsVisible = true;
            API.GetResponseFromServer(Constants.monthlyContestFinishAttemptAPI, param, (content) => {
                MessagingCenter.Send<PracticeQuestionPage>(this, "ATTEMPT_FINISHED");

                Navigation.PopModalAsync(false);
                LoaderView.IsVisible = false;

            },
            async (message, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
                else { await DisplayAlert(null, message, "Ok"); }
            });
        }
    }
}

﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using System.Collections.ObjectModel;
using ZIMLApp.Classes.Utility;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Net;
using System.Linq;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages to show the Monthly contest qusetion page.
    /// </summary>
    public partial class MonthlyContestQusetionPage : ContentPage
    {
        public ContestDetail contestDetail;
        public MonthlyContestDetailResponse detailResponse;

        private int currentIndex = 0;

        private List<Question> questions = new List<Question>();
        private List<Attempts> attempts = new List<Attempts>();

        private ObservableCollection<AnswerSummary> answerSummaryList = new ObservableCollection<AnswerSummary>();

        public MonthlyContestQusetionPage()
        {
            InitializeComponent();
            //loaderWebView.Source = CommonClass.GetLoaderWebViewSource();
            if (Device.RuntimePlatform == Device.iOS) { Padding = new Thickness(0, 20, 0, 0); }
            initiaiizeView();
            LoaderView.IsVisible = true;
            questionWebview.HeightRequest = Application.Current.MainPage.Height - 150;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            questions = detailResponse.questions;
            attempts = detailResponse.attempts;
            InitSummaryData();
            startTimer();
            answerEntry.Text = answerSummaryList[currentIndex].answer;
            setDataOnView(questions[0].questiontext, questions[0].id);
            LoaderView.IsVisible = false;
            //GetQuizDeatil();
        }

        protected override bool OnBackButtonPressed()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                bool value = await DisplayAlert(null, "Are you sure you want close the attempt?", "Yes", "No");
                if (value) { await this.Navigation.PopModalAsync(); }
            });
            return true;
        }

        public void initiaiizeView()
        {
            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += async (s, e) =>
            {
                bool value = await DisplayAlert(null, "Are you sure you want close the attempt?", "Yes", "No");
                if (value)
                {
                    if (Device.RuntimePlatform == Device.Android)
                    {
                        MessagingCenter.Send<MonthlyContestQusetionPage>(this, "CLOSE_ATTEMPT");
                        await Navigation.PopModalAsync(false);
                    }
                    else
                    {
                        Navigation.PopModalAsync(false);
                        Navigation.PopModalAsync(false);
                    }

                }
            };
            closeImg.GestureRecognizers.Add(tapGestureRecognizer);
            tapGestureRecognizer.NumberOfTapsRequired = 1;

            var nextTGR = new TapGestureRecognizer();
            nextTGR.Tapped += NextClicked;
            nextImg.GestureRecognizers.Add(nextTGR);
            nextTGR.NumberOfTapsRequired = 1;

            var previousTGR = new TapGestureRecognizer();
            previousTGR.Tapped += PreviousClicked;
            previousImg.GestureRecognizers.Add(previousTGR);
            previousTGR.NumberOfTapsRequired = 1;

            var summaryTGR = new TapGestureRecognizer();
            summaryTGR.Tapped += ViewSummaryClicked;
            summaryImg.GestureRecognizers.Add(summaryTGR);
            summaryTGR.NumberOfTapsRequired = 1;

            titleTxt.Text = "Question " + (currentIndex + 1);
            previousImg.IsVisible = false;

        }
        /// <summary>
        /// Sets the data on view.
        /// </summary>
        /// <param name="html">Question text</param>
        /// <param name="question_id">Question identifier.</param>
        public void setDataOnView(string html, string question_id)
        {
            string htmlstr = WebUtility.HtmlDecode(html);
            string baseurl = getBaseUrlForImages(question_id);
            htmlstr = htmlstr.Replace("@@PLUGINFILE@@/", baseurl);

            string htmlData = CommonClass.getHTMLContent(htmlstr);

            var url = new HtmlWebViewSource { Html = htmlData };
            questionWebview.Source = url;
        }
        /// <summary>
        /// This method used to start the timer.
        /// </summary>
        void startTimer()
        {
            var totalMinutes = contestDetail.getTotalMinutes();
            var minute = totalMinutes - 1;
            var second = 60;

            if (attempts != null && attempts.Count > 0)
            {
                DateTime startTime = CommonClass.FromUnixTime(Convert.ToInt64(attempts[0].timestart));
                DateTime currentTime = CommonClass.FromUnixTime(detailResponse.current_timestamp);//DateTime.Now.ToUniversalTime(); //Convert.ToDateTime(questions[0].currenttime);
                var diff = currentTime.Subtract(startTime).TotalMinutes;
                int remainingTime = (int)Convert.ToInt64(totalMinutes - diff);
                if (remainingTime < 0)
                {
                    // Do nothing not happen in actual case.
                }
                else if (remainingTime < totalMinutes)
                {
                    minute = remainingTime - 1;
                }
            }

            Device.StartTimer(TimeSpan.FromSeconds(1), () =>
            {
                second--;

                if (second == 0 && minute != 0)
                {
                    second = 59;
                    if (minute != 0)
                        minute--;
                }
                if (minute != 0 || minute == 0 && second != 0)
                {
                    timerTxt.Text = $"{minute.ToString("00")}:{second.ToString("00")}";

                    return true;
                }
                else
                {
                    timerTxt.Text = "00:00";
                    showTimesUpAlert();
                    return false;
                }

            });
        }
        /// <summary>
        /// Shows the times up alert if the time is over for the contest
        /// </summary>
        async void showTimesUpAlert()
        {
            await DisplayAlert(null, "Times up !", "OK");
            FinishAttempt(attempts[0].id);
        }
        /// <summary>
        /// Create the summary list data to show the contest summary page.
        /// </summary>
        void InitSummaryData()
        {
            for (int i = 0; i < questions.Count; i++)
            {
                if (attempts[0].submitted_answers?.Count > 0)
                {
                    var submittedAnswerArr = attempts[0].submitted_answers;
                    List<SubmittedAnswer> submittedAnswer = submittedAnswerArr.FindAll((obj) => obj.slot == (i + 1).ToString());
                    if (submittedAnswer != null && submittedAnswer.Count > 0)
                    {
                        string sequence = (Convert.ToInt32(submittedAnswer.Last().sequence) + 1).ToString();
                        answerSummaryList.Add(new AnswerSummary(i, sequence, submittedAnswer.Last().answer));
                    }
                    else
                    {
                        answerSummaryList.Add(new AnswerSummary(i));
                    }
                }
                else
                {
                    answerSummaryList.Add(new AnswerSummary(i));
                }

            }
            summaryList.ItemsSource = answerSummaryList;
        }
        /// <summary>         /// This method manages the Next button click and move to the next question.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void NextClicked(object sender, System.EventArgs e)
        {
            moveNext();
        }
        /// <summary>
        /// This method manages the Previous button click and move to the previous question.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void PreviousClicked(object sender, System.EventArgs e)
        {
            movePrivious();
        }
        /// <summary>
        /// This method manages the submit button click.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void SubmitForQuestionClicked(object sender, System.EventArgs e)
        {
            if (!string.IsNullOrEmpty(answerEntry.Text) && answerSummaryList[currentIndex].answer != answerEntry.Text)
            {
                double ansValue;
                bool isDoubleVaue = double.TryParse(answerEntry.Text, out ansValue);
                if (isDoubleVaue) SubmitAnswer(attempts[0].id, answerSummaryList[currentIndex].slot, answerEntry.Text, answerSummaryList[currentIndex].sequence);
                else DisplayAlert(null, "You must enter a valid number. Do not include a unit in your response.", "Ok");
            }
        }
        /// <summary>
        /// This method manages the submit attempt button click.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void SubmitAttemptClicked(object sender, System.EventArgs e)
        {

            FinishAttempt(attempts[0].id);
        }

        /// <summary>
        /// This method manages the View summary button click and show the summary page on click.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void ViewSummaryClicked(object sender, System.EventArgs e)
        {
            if (summaryView.IsVisible == false)
            {
                showSummaryView();
            }
        }

        /// <summary>
        /// This method manages the Summary cell item click and show question related to that cell item.
        /// </summary>
        /// <param name="sender">List item object</param>
        /// <param name="e">Event arguments.</param>
        void SummaryCellTapped(object sender, System.EventArgs e)
        {
            AnswerSummary answer = (AnswerSummary)summaryList.SelectedItem;
            int index = answerSummaryList.IndexOf(answer);
            currentIndex = index;
            hideSummaryView();
        }
        /// <summary>
        /// This method used to move to the next question.
        /// </summary>
        void moveNext()
        {
            if (currentIndex < questions.Count - 1)
            {
                currentIndex++;
                setDataOnView(questions[currentIndex].questiontext, questions[currentIndex].id);
                titleTxt.Text = "Question " + (currentIndex + 1);
                answerEntry.Text = answerSummaryList[currentIndex].answer;
                previousImg.IsVisible = true;
                progressBar.Progress = (currentIndex + 1.0) / questions.Count;
            }
            else
            {
                showSummaryView();
            }
        }

        /// <summary>
        /// This method used to move to the previous question.
        /// </summary>
        void movePrivious()
        {
            if (summaryView.IsVisible == true)
            {
                hideSummaryView();
            }
            else
            {
                currentIndex--;
                setDataOnView(questions[currentIndex].questiontext, questions[currentIndex].id);
                titleTxt.Text = "Question " + (currentIndex + 1);
                answerEntry.Text = answerSummaryList[currentIndex].answer;
                progressBar.Progress = (currentIndex + 1.0) / questions.Count;
                if (currentIndex == 0) previousImg.IsVisible = false;
            }

        }

        /// <summary>
        /// This method show the summary view page.
        /// </summary>
        void showSummaryView()
        {
            questionView.IsVisible = false;
            summaryView.IsVisible = true;
            nextImg.IsVisible = false;
            previousImg.IsVisible = true;
            titleTxt.Text = "Question summary";
        }


        /// <summary>
        /// This method is used to hides the summary view.
        /// </summary>
        void hideSummaryView()
        {
            questionView.IsVisible = true;
            summaryView.IsVisible = false;
            nextImg.IsVisible = true;
            if (currentIndex == 0) previousImg.IsVisible = false;
            setDataOnView(questions[currentIndex].questiontext, questions[currentIndex].id);
            titleTxt.Text = "Question " + (currentIndex + 1);
            answerEntry.Text = answerSummaryList[currentIndex].answer;
            progressBar.Progress = (currentIndex + 1.0) / questions.Count;
        }

        private string getBaseUrlForImages(string question_id)
        {
            // Eg: https://zimlapp.areteem.org/api/images/question.php?quiz_id=906&question_id=7522&filename=%5B180601%5D.png&filearea=questiontext

            string baseUrl = Constants.baseURL + "/api/images/question.php?quiz_id=" + contestDetail.quiz_id + "&question_id=" + question_id + "&filearea=questiontext&filename=";
            return baseUrl;
        }

        //void TryAgain_Clicked(object sender, System.EventArgs e)
        //{
        //    LoaderView.IsVisible = true;
        //    ErrorView.IsVisible = false;
        //    GetQuizDeatil();
        //}

        //public void GetQuizDeatil()
        //{
        //    LoaderView.IsVisible = true;
        //    MonthlyContestDetailParam param = new MonthlyContestDetailParam(); 
        //    param.quiz_id = contestDetail.quiz_id;

        //    API.GetResponseFromServer(Constants.monthlyContestDetailAPI, param, (content) => {
        //        MonthlyContestDetailResponse detail = JsonConvert.DeserializeObject<MonthlyContestDetailResponse>(content.ToString());
        //        LoaderView.IsVisible = false;
        //        if (detail != null)
        //        {
        //            questions = detail.questions;
        //            attempts = detail.attempts;
        //            InitSummaryData();
        //            startTimer();
        //            answerEntry.Text = answerSummaryList[currentIndex].answer;
        //            setDataOnView(questions[0].questiontext, questions[0].id);

        //        }
        //    }, async (message, errorType) => {
        //        LoaderView.IsVisible = false;
        //        ErrorView.IsVisible = true;
        //        if (errorType == ErrorType.Network)
        //        {
        //            ErrorTitle.Text = Constants.NetworkErrorTitle;
        //            ErrorMessage.Text = Constants.NetworkErrorMessage;
        //            ActionButton.Text = "Try again";
        //        }
        //        else
        //        {
        //            ErrorTitle.Text = Constants.ServerErrorTitle;
        //            ErrorMessage.Text = Constants.ServerErrorMessage;
        //            ActionButton.Text = "Refresh";
        //        }
        //    });
        //}

        /// <summary>
        /// This method manages the call for submit answer API.
        /// </summary>
        /// <param name="attempt_id">Attempt identifier.</param>
        /// <param name="slot">Slot number for the question</param>
        /// <param name="answer">Answer text</param>
        /// <param name="sequence">Sequence for the answer.</param>
        public void SubmitAnswer(string attempt_id, string slot, string answer, string sequence)
        {
            LoaderView.IsVisible = true;
            MonthlyContestSubmitAnswerParam param = new MonthlyContestSubmitAnswerParam();
            param.quiz_id = contestDetail.quiz_id; ;
            param.attempt_id = attempt_id;
            param.slot = slot;
            param.answer = answer;
            param.sequence = sequence;

            API.GetResponseFromServer(Constants.monthlyContestSubmitAnswerAPI, param, (content) =>
            {
                //MonthlyContestDetailResponse detail = JsonConvert.DeserializeObject<MonthlyContestDetailResponse>(content.ToString());
                LoaderView.IsVisible = false;
                var answerSummary = answerSummaryList[currentIndex];
                answerSummary.answer = answer;
                answerSummary.sequence = (Convert.ToInt32(sequence) + 1).ToString();
                answerSummaryList[currentIndex] = answerSummary;

                answerEntry.Text = "";
                moveNext();
            }, async (message, errorType) =>
            {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network)
                    await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
                else
                    await DisplayAlert(null, message, "Ok");
            });
        }
        /// <summary>
        /// This method manages the call for Finish attempt API.
        /// </summary>
        /// <param name="attemptId">Attempt identifier.</param>
        public void FinishAttempt(string attemptId)
        {
            var param = new FinishAttemptParam();
            param.attempt_id = attemptId;
            LoaderView.IsVisible = true;
            API.GetResponseFromServer(Constants.monthlyContestFinishAttemptAPI, param, (content) =>
            {
                if (Device.RuntimePlatform == Device.Android)
                {
                    MessagingCenter.Send<MonthlyContestQusetionPage>(this, "CLOSE_ATTEMPT");
                    Navigation.PopModalAsync(false);
                }
                else
                {
                    Navigation.PopModalAsync(false);
                    Navigation.PopModalAsync(false);
                }

                LoaderView.IsVisible = false;

            },
            async (message, errorType) =>
            {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
                else { await DisplayAlert(null, message, "Ok"); }
            });
        }
    }
}

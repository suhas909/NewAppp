﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Plugin.InAppBilling;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages Monthly contest detail page.
    /// </summary>
    public partial class MonthlyContestDetailPage : ContentPage
    {
        //public QuizStatus quizStatus = QuizStatus.Not_Started;
        //public Attempts attempt;
        /// <summary>
        /// The contest detail.
        /// </summary>
        public ContestDetail contestDetail;


        private MonthlyContestDetailResponse detail;
        private InAppBillingPurchase inAppBillingPurchase;
        private bool IsPurchasing = false;

        public MonthlyContestDetailPage()
        {
            InitializeComponent();
            NavigationPage.SetBackButtonTitle(this, " ");
            LoaderView.IsVisible = true;
        }

        public void initiaiizeView()
        {
            Title = contestDetail.quiz_name; 
            setDataOnView();
        }

		protected override void OnAppearing()
		{
            base.OnAppearing();
            initiaiizeView();
            LoaderView.IsVisible = false;
            if (contestDetail.is_enrolled)
            {
                actionBtn.Text = "Continue";
            }
            else
            {
                actionBtn.Text = "Subscribe";
                CheckForSubscription();
            }
		}
        /// <summary>
        /// Checks for subscription. If user already subscribed for the contest then update on the server.
        /// </summary>
        public async void CheckForSubscription()
        {
            LoaderView.IsVisible = true;
            if (!await WasItemPurchased(Constants.productIdMonthlyContest)) {
                LoaderView.IsVisible = false; 
            }
        }
         /// <summary>
         /// Sets the data on view.
         /// </summary>
		public void setDataOnView()
        {
            string titleSection1 = contestDetail.sections[0].name;
            if (string.IsNullOrEmpty(titleSection1))
            {
                titleSection1 = contestDetail.display_name;
            }
            string detailSection1 = contestDetail.sections[0].summary;
            if (string.IsNullOrEmpty(detailSection1))
            {
                detailSection1 = "";
            }

            string titleSection2 = contestDetail.sections[1].name;
            if (string.IsNullOrEmpty(titleSection2))
            {
                titleSection2 = contestDetail.getStartDate() + " - " + contestDetail.getEndDate();
            }
            string detailSection2 = contestDetail.sections[1].summary;
            detailSection2 = Regex.Replace(detailSection2, @"<a\b[^>]+>([^<]*(?:(?!</a)<[^<]*)*)</a>", "$1");
            if (string.IsNullOrEmpty(detailSection2))
            {
                detailSection2 = "";
            }

            string htmlData = "<!DOCTYPE HTML>";
            htmlData = htmlData + "<html>";
            htmlData = htmlData + "<body>";
            htmlData = htmlData + "<h3>" + titleSection1 +  "</h3>";
            htmlData = htmlData + "<p>" + detailSection1 + "</p>";
            htmlData = htmlData + "<h3>" + titleSection2 + "</h3>";
            htmlData = htmlData + "<p>" + detailSection2 + "</p>";
            htmlData = htmlData + "</body>";
            htmlData = htmlData + "</html>";
            Debug.WriteLine(htmlData);
            var url = new HtmlWebViewSource
            {
                Html = htmlData
            };
            webView.Source = url;


        }
        /// <summary>         /// This method manages the Start attempt/Subscribe button click.
        /// If user already subscribed, then it navigate to the contest information page.
        /// If not subscribed, then it will go for the subscription purchase process.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
         void StartAttemptClicked(object sender, System.EventArgs e)
        {
            if (contestDetail.is_enrolled)
            {
                GetQuizDeatil();
            }
            else
            {
                if (Device.RuntimePlatform == Device.iOS)
                {
                    Navigation.PushAsync(new SubscriptionDetailPage(){ contestDetail = contestDetail });
                }
                else
                {
                    PurchaseItem();
                }

            }
        }
        /// <summary>         /// This method manages the Try again button clicked, and try to reload the data.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void TryAgain_Clicked(object sender, System.EventArgs e)
        {
            LoaderView.IsVisible = true;
            ErrorView.IsVisible = false;
            if (contestDetail.is_enrolled)
            {
                GetQuizDeatil();
            }
            else if (inAppBillingPurchase == null)
            {
                if (Device.RuntimePlatform == Device.iOS)
                {
                    Navigation.PushAsync(new SubscriptionDetailPage(){ contestDetail = contestDetail });
                }
                else
                {
                    PurchaseItem();
                }
            }
            else
            {
                EnrollUserForCource(inAppBillingPurchase, false);
            }

        }
        /// <summary>
        /// Gets the quiz deatil From API. 
        /// </summary>
        public void GetQuizDeatil()
        {
            LoaderView.IsVisible = true;
            MonthlyContestDetailParam param = new MonthlyContestDetailParam();
            param.quiz_id = contestDetail.quiz_id;
            param.start_attempt = "no";

            API.GetResponseFromServer(Constants.monthlyContestDetailAPI, param, async (content) => {
                detail = JsonConvert.DeserializeObject<MonthlyContestDetailResponse>(content.ToString());
                LoaderView.IsVisible = false;
                if (detail != null)
                {
                    var quizStatus = QuizStatus.Not_Started;
                    Attempts attempt;
                    bool isAttemptOver = false;
                    if (detail.attempts != null && detail.attempts.Count > 0)
                    {
                        attempt = detail.attempts[0];
                        if (attempt.timefinish == "0")
                        {
                            quizStatus = QuizStatus.On_Going;
                            isAttemptOver = CheckAttemptTimeOver(attempt.timestart, contestDetail.getTotalMinutes());
                            if (isAttemptOver == true)
                            {
                                FinishAttempt(attempt.id, contestDetail);
                            }
                        }
                        else
                        {
                            quizStatus = QuizStatus.Result_Open;
                        }
                    }
                    if (isAttemptOver == true)
                    {
                        return;
                    }
                    else if (quizStatus == QuizStatus.Not_Started || quizStatus == QuizStatus.On_Going)
                    {
                        var introPage = new MonthlyContestIntroductionPage();
                        introPage.quizStatus = quizStatus;
                        introPage.contestDetail = contestDetail;
                        introPage.detailResponse = detail;
                        await Navigation.PushModalAsync(introPage);
                    }
                    else
                    {
                        var resultPage = new MonthlyContestResultPage();
                        resultPage.quizStatus = quizStatus;
                        //resultPage.Title = this.Title;
                        resultPage.contestDetail = contestDetail;
                        resultPage.detailResponse = detail;
                        await Navigation.PushAsync(resultPage);
                    }
                }
            }, (message, errorType) => {
                LoaderView.IsVisible = false;
                ErrorView.IsVisible = true;
                if (errorType == ErrorType.Network)
                {
                    ErrorTitle.Text = Constants.NetworkErrorTitle;
                    ErrorMessage.Text = Constants.NetworkErrorMessage;
                    ActionButton.Text = "Try again";
                }
                else
                {
                    ErrorTitle.Text = Constants.ServerErrorTitle;
                    ErrorMessage.Text = Constants.ServerErrorMessage;
                    ActionButton.Text = "Refresh";
                }

            });
        }

        bool CheckAttemptTimeOver(string timestart, int totalMinutes)
        {
            DateTime startTime = CommonClass.FromUnixTime(Convert.ToInt64(timestart));
            //DateTime currentTime = DateTime.Now.ToUniversalTime();
            DateTime currentTime = CommonClass.FromUnixTime(detail.current_timestamp);
            var diff = currentTime.Subtract(startTime).TotalMinutes;
            int remainingTime = (int)Convert.ToInt64(totalMinutes - diff);
            if (remainingTime < 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void FinishAttempt(string attemptId, ContestDetail contestDetail)
        {
            var param = new FinishAttemptParam();
            param.attempt_id = attemptId;
            LoaderView.IsVisible = true;
            API.GetResponseFromServer(Constants.monthlyContestFinishAttemptAPI, param, (content) => {
                GetQuizDeatil();
            },
            async (message, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
                else { await DisplayAlert(null, message, "Ok"); }
            });
        }

        //public void GetQuizDeatil()
        //{
        //    LoaderView.IsVisible = true;
        //    MonthlyContestDetailParam param = new MonthlyContestDetailParam();
        //    param.quiz_id = contestDetail.quiz_id;
        //    param.start_attempt = "no";

        //    API.GetResponseFromServer(Constants.monthlyContestDetailAPI, param, async (content) => {
        //        detail = JsonConvert.DeserializeObject<MonthlyContestDetailResponse>(content.ToString());
        //        LoaderView.IsVisible = false;
        //        if (detail != null)
        //        {
        //            var introPage = new MonthlyContestIntroductionPage();
        //            introPage.quizStatus = this.quizStatus;
        //            introPage.contestDetail = contestDetail;
        //            introPage.detailResponse = detail;

        //            await Navigation.PushModalAsync(introPage);
        //            Navigation.RemovePage(this);
        //        }
        //    }, (message, errorType) => {
        //        LoaderView.IsVisible = false;
        //        ErrorView.IsVisible = true;
        //        if (errorType == ErrorType.Network)
        //        {
        //            ErrorTitle.Text = Constants.NetworkErrorTitle;
        //            ErrorMessage.Text = Constants.NetworkErrorMessage;
        //            ActionButton.Text = "Try again";
        //        }
        //        else
        //        {
        //            ErrorTitle.Text = Constants.ServerErrorTitle;
        //            ErrorMessage.Text = Constants.ServerErrorMessage;
        //            ActionButton.Text = "Refresh";
        //        }

        //    });
        //}

        /// <summary>
        /// This method calls the Enroll API and enroll the user for cource.
        /// </summary>
        /// <param name="purchase">Purchase Detail object</param>
        /// <param name="use_existing_subscription">If set to <c>true</c> use existing subscription.</param>
        public void EnrollUserForCource(InAppBillingPurchase purchase, bool use_existing_subscription)
        {
            LoaderView.IsVisible = true;
            EnrollUserForCourceParam param = new EnrollUserForCourceParam();
            param.course_id = contestDetail.course_id;
            param.product_id = purchase.ProductId;
            param.purchase_id = purchase.Id;
            param.purchase_token = purchase.PurchaseToken;
            param.transaction_date_utc = purchase.TransactionDateUtc.ToString();
            param.state = purchase.State.ToString();
            param.environment = Constants.environment;
            param.package_name = Constants.packageName;
            if (use_existing_subscription) { param.use_existing_subscription = "yes"; }
            else { param.use_existing_subscription = "no"; }

            API.GetResponseFromServer(Constants.enrollUserForCourceAPI, param, (content) => {
                //detail = JsonConvert.DeserializeObject<MonthlyContestDetailResponse>(content.ToString());
                //LoaderView.IsVisible = false;
                contestDetail.is_enrolled = true;
                GetQuizDeatil();

            }, async (message, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
                else if (message == "No live subscription" || message == "Original Transaction Id linked to another user")
                { 
                    if (IsPurchasing) { await DisplayAlert(null, "A user is already subscribed with this purchase id, please use another id for subscription.", "Ok"); }
                }
                else { await DisplayAlert(null, message, "Ok"); }
            });
        }
        /// <summary>
        /// This method manages the in-app purchase process for the subscription.
        /// </summary>
        async void PurchaseItem()
        {
            IsPurchasing = true;
            var productId = Constants.productIdMonthlyContest;
            var billing = CrossInAppBilling.Current;
            try
            {
                LoaderView.IsVisible = true;

                if (await WasItemPurchased(productId))
                {
                    return;
                }

                //var connected = await billing.ConnectAsync(ItemType.Subscription);
                var connected = await billing.ConnectAsync();
                if (!connected)
                {
                    //we are offline or can't connect, don't try to purchase
                    LoaderView.IsVisible = false;
                    return;
                }

                //check purchases
                var purchase = await billing.PurchaseAsync(productId, ItemType.Subscription, "test purchase");

                //possibility that a null came through.
                if (purchase == null)
                {
                    //did not purchase
                    LoaderView.IsVisible = false;

                }
                else if (purchase.State == PurchaseState.Purchased || (purchase.State == PurchaseState.PaymentPending && purchase.AutoRenewing == true))
                {
                    inAppBillingPurchase = purchase;
                    Debug.WriteLine("Id = " + purchase.Id);
                    Debug.WriteLine("ProductId = " + purchase.ProductId);
                    Debug.WriteLine("TransactionDateUtc = " + purchase.TransactionDateUtc);
                    Debug.WriteLine("AutoRenewing = " + purchase.AutoRenewing);
                    Debug.WriteLine("PurchaseToken = " + purchase.PurchaseToken);
                    Debug.WriteLine("State = " + purchase.State);
                    Debug.WriteLine("ConsumptionState = " + purchase.ConsumptionState);

                    //var msg = "Id = " + purchase.Id
                    //                            + "\n ProductId = " + purchase.ProductId
                    //                            + "\n TransactionDateUtc = " + purchase.TransactionDateUtc
                    //                            + "\n AutoRenewing = " + purchase.AutoRenewing
                    //                            + "\n State = " + purchase.State
                    //                            + "\n ConsumptionState = " + purchase.ConsumptionState
                    //                            + "\n PurchaseToken = " + purchase.PurchaseToken;
                    //await DisplayAlert(null, msg, "ok");
                    EnrollUserForCource(purchase, false);
                }
                else 
                {
                    LoaderView.IsVisible = false;
                }

            }
            catch (InAppBillingPurchaseException purchaseEx)
            {
                var message = string.Empty;
                switch (purchaseEx.PurchaseError)
                {
                    case PurchaseError.AppStoreUnavailable:
                        message = "Currently the app store seems to be unavailble. Try again later.";
                        break;
                    case PurchaseError.BillingUnavailable:
                        message = "Billing seems to be unavailable, please try again later.";
                        break;
                    case PurchaseError.PaymentInvalid:
                        message = "Payment seems to be invalid, please try again.";
                        break;
                    case PurchaseError.PaymentNotAllowed:
                        message = "Payment does not seem to be enabled/allowed, please try again.";
                        break;
                }

                LoaderView.IsVisible = false;
                //Decide if it is an error we care about
                if (string.IsNullOrWhiteSpace(message))
                    return;
                await DisplayAlert(null, message, "Ok");
                Debug.WriteLine(message);
            }
            catch (Exception ex)
            {
                LoaderView.IsVisible = false;
                await DisplayAlert(null, "Somthing went wrong.", "Ok");
                //Something else has gone wrong, log it
                Debug.WriteLine("Issue connecting: " + ex);
            }
            finally
            {
                LoaderView.IsVisible = false;
                await billing.DisconnectAsync();
            }
        }
        /// <summary>
        /// This method used to check the valid subscription available for that user.
        /// </summary>
        /// <returns>This returns true if user already subscribed and subscription is not expired.</returns>
        /// <param name="productId">Product identifier.</param>
        async Task<bool> WasItemPurchased(string productId)
        {
            
            var billing = CrossInAppBilling.Current;
            try
            {
                //TODO: SUhas has done changes
                //var connected = await billing.ConnectAsync(ItemType.Subscription);
                var connected = await billing.ConnectAsync();

                if (!connected)
                {
                    //Couldn't connect
                    return false;
                }

                //check purchases
                var purchases = await billing.GetPurchasesAsync(ItemType.Subscription);

                //check for null just incase
                if (purchases?.Any(p => p.ProductId == productId) ?? false)
                {
                    
                    var purchase = purchases.Where(p => p.ProductId == productId).First();
                    if ((purchase.State == PurchaseState.Purchased && !string.IsNullOrEmpty(purchase.PurchaseToken)) || (purchase.State == PurchaseState.PaymentPending && purchase.AutoRenewing == true))
                    {
                        inAppBillingPurchase = purchase;

                        Debug.WriteLine("Id = " + purchase.Id);
                        Debug.WriteLine("ProductId = " + purchase.ProductId);
                        Debug.WriteLine("TransactionDateUtc = " + purchase.TransactionDateUtc);
                        Debug.WriteLine("AutoRenewing = " + purchase.AutoRenewing);
                        Debug.WriteLine("PurchaseToken = " + purchase.PurchaseToken);
                        Debug.WriteLine("State = " + purchase.State);
                        Debug.WriteLine("ConsumptionState = " + purchase.ConsumptionState);

                        //var msg = "Id = " + purchase.Id
                        //                            + "\n ProductId = " + purchase.ProductId
                        //                            + "\n TransactionDateUtc = " + purchase.TransactionDateUtc
                        //                            + "\n AutoRenewing = " + purchase.AutoRenewing
                        //                            + "\n State = " + purchase.State
                        //                            + "\n ConsumptionState = " + purchase.ConsumptionState
                        //                            + "\n PurchaseToken = " + purchase.PurchaseToken;
                        //await DisplayAlert(null, msg, "ok");
                        EnrollUserForCource(purchase, true);
                        //Purchase restored
                        return true;
                    }
                    else
                        return false;
                    
                    //return true;
                }
                else
                {
                    //no purchases found
                    return false;
                }
            }
            catch (InAppBillingPurchaseException purchaseEx)
            {
                //Billing Exception handle this based on the type
                Debug.WriteLine("Error: " + purchaseEx);
            }
            catch (Exception ex)
            {
                //Something has gone wrong
                Debug.WriteLine("Error: " + ex);
            }
            finally
            {
                await billing.DisconnectAsync();
            }

            return false;
        }
    }
}
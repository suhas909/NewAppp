﻿using System;
using System.Collections.Generic;
using System.Net;
using Xamarin.Forms;
using ZIMLApp.Classes.Utility;
using ZIMLApp.Classes.Model;
using Newtonsoft.Json;
using System.Linq;
using System.Diagnostics;

namespace ZIMLApp.Classes.Pages
{

    /// <summary>
    /// This class manages the Discussion Forum Detail Page.
    /// </summary>
    public partial class ForumDetailPage : ContentPage
    {
        /// <summary>
        /// The forum list item detail object.
        /// </summary>
        public ForumListItem forumListItem;
        /// <summary>
        /// The forum detail list contains the comments and reply.
        /// </summary>
        public List<ForumDetailItem> forumDetailList = new List<ForumDetailItem>();
        /// <summary>
        /// The index of current page.
        /// </summary>
        public int currentIndex = 0;
        private bool is_subscribed = false;
        private string currentTimeStr;

        public ForumDetailPage()
        {
            InitializeComponent();
            NavigationPage.SetBackButtonTitle(this, " ");
            initiaiizeView();
            if (Preference.IsUserLoggedIn)
            {
                AddToolbarItem();
            }
            else
            {
                replyBtn.IsVisible = false;
                deleteBtn.IsVisible = false;
                editBtn.IsVisible = false;
                postNewCommentBtn.IsVisible = false;
            }
            LoaderView.IsVisible = true;
            //InitData();

        }

		protected override void OnAppearing()
		{
            base.OnAppearing();
            if (forumListItem != null)
            {
                Title = MakeStringForTitle(forumListItem.postName);
                //setDataForCurrentIndex();
                GetForumDetail();
            }

		}

        void AddToolbarItem()
        {
            this.ToolbarItems.Clear();
            var moreBtn = new ToolbarItem
            {
                Icon = "More.png",
                Text = "More",
                Priority = 0,
                Order = ToolbarItemOrder.Primary
                    
            };
            moreBtn.Clicked += (s, e) => {
                if (subUnsubTxt.IsVisible == true) subUnsubTxt.IsVisible = false;
                else subUnsubTxt.IsVisible = true;
            };
            ToolbarItems.Add(moreBtn);
        }

        public void initiaiizeView()
        {
            var nextTGR = new TapGestureRecognizer();
            nextTGR.Tapped += NextClicked;
            nextLayout.GestureRecognizers.Add(nextTGR);
            nextTGR.NumberOfTapsRequired = 1;

            var previousTGR = new TapGestureRecognizer();
            previousTGR.Tapped += PreviousClicked;
            previousLayout.GestureRecognizers.Add(previousTGR);
            previousTGR.NumberOfTapsRequired = 1;

            var firstTGR = new TapGestureRecognizer();
            firstTGR.Tapped += FirstClicked;
            firstLayout.GestureRecognizers.Add(firstTGR);
            firstTGR.NumberOfTapsRequired = 1;

            var lastTGR = new TapGestureRecognizer();
            lastTGR.Tapped += LastClicked;
            lastLayout.GestureRecognizers.Add(lastTGR);
            lastTGR.NumberOfTapsRequired = 1;

            var showParentTGR = new TapGestureRecognizer();
            showParentTGR.Tapped += ShowParentClicked;
            showParentBtn.GestureRecognizers.Add(showParentTGR);
            showParentTGR.NumberOfTapsRequired = 1;

            var editTGR = new TapGestureRecognizer();
            editTGR.Tapped += EditClicked;
            editBtn.GestureRecognizers.Add(editTGR);
            editTGR.NumberOfTapsRequired = 1;

            var deleteTGR = new TapGestureRecognizer();
            deleteTGR.Tapped += DeleteClicked;
            deleteBtn.GestureRecognizers.Add(deleteTGR);
            deleteTGR.NumberOfTapsRequired = 1;

            var replyTGR = new TapGestureRecognizer();
            replyTGR.Tapped += ReplyClicked;
            replyBtn.GestureRecognizers.Add(replyTGR);
            replyTGR.NumberOfTapsRequired = 1;

            var subUnsubTGR = new TapGestureRecognizer();
            subUnsubTGR.Tapped += SubUnsubClicked;
            subUnsubTxt.GestureRecognizers.Add(subUnsubTGR);
            subUnsubTGR.NumberOfTapsRequired = 1;

            messageWebView.Navigating += (s, e) =>
            {
                if (e.Url.StartsWith("http"))
                {
                    try
                    {
                        var uri = new Uri(e.Url);
                        Device.OpenUri(uri);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex);
                    }

                    e.Cancel = true;
                }
            };

        }
        /// <summary>
        /// This method used to set the message data on the field.
        /// </summary>
        /// <param name="html">Html text to show as message or comment.</param>
        /// <param name="post_id">Post identifier.</param>
		public void setDataOnView(string html, string post_id)
        {
            string htmlstr = WebUtility.HtmlDecode(html);
            string baseurl = getBaseUrlForImages(post_id);
            htmlstr = htmlstr.Replace("@@PLUGINFILE@@/", baseurl);
            if (htmlstr.Contains("href=\"/"))
                htmlstr = htmlstr.Replace("href=\"/", "href=\"" + Constants.baseURL + "/");
            else if (htmlstr.Contains("href=/"))
                htmlstr = htmlstr.Replace("href=/", "href=/" + Constants.baseURL + "/");
            string htmlData = CommonClass.getHTMLContent(htmlstr);

            var url = new HtmlWebViewSource { Html = htmlData };
            messageWebView.Source = url;
        }
        /// <summary>
        /// This method used to set the data for current page. 
        /// </summary>
        public void setDataForCurrentIndex()
        {
            setDataOnView(forumDetailList[currentIndex].message, forumDetailList[currentIndex].id);
            numberTxt.Text = "#" + (currentIndex + 1);
            var title = forumDetailList[currentIndex].subject;
            TitleTxt.Text = title.ToCharArray().First().ToString().ToUpper() + title.Substring(1);
            TimeOfPostedTxt.Text = forumDetailList[currentIndex].getPostedTime();
            StartedByTxt.Text = forumDetailList[currentIndex].user_name;
            slotLb.Text = (currentIndex + 1) + " OF " + forumDetailList.Count.ToString();
            if (Preference.IsUserLoggedIn && forumDetailList[currentIndex].own_post && isEditingEnable(forumDetailList[currentIndex].created))
            {
                //deleteBtn.IsVisible = true;
                editBtn.IsVisible = true;
            }
            else
            {
                //deleteBtn.IsVisible = false;
                editBtn.IsVisible = false;
            }
            deleteBtn.IsVisible = false;

            if (currentIndex == 0)
            {
                previousLayout.Opacity = 0.6;
                firstLayout.Opacity = 0.6;
                showParentBtn.IsVisible = false;
            }
            else 
            {
                previousLayout.Opacity = 1;
                firstLayout.Opacity = 1;
                showParentBtn.IsVisible = true;
            }
            if (currentIndex == forumDetailList.Count - 1)
            {
                nextLayout.Opacity = 0.6;
                lastLayout.Opacity = 0.6;
            }
            else
            {
                nextLayout.Opacity = 1;
                lastLayout.Opacity = 1;
            }

            if (forumDetailList[currentIndex].attachments != null && forumDetailList[currentIndex].attachments.Count > 0)
            {
                AddAttachmentForCurrentPost();
            } else {
                attachmentView.Children.Clear();   
            }
        }
        /// <summary>
        /// This method is used to check that the editing for comment or reply is enabled or not.
        /// </summary>
        /// <returns><c>true</c>, if editing enabled, <c>false</c> otherwise.</returns>
        /// <param name="createdTimeStr">Created time for that comment or reply.</param>
        bool isEditingEnable(string createdTimeStr)
        {
            if (currentTimeStr == null) return false;
            DateTime createdTime = CommonClass.FromUnixTime(Convert.ToInt64(createdTimeStr));
            DateTime currentTime = CommonClass.FromUnixTime(Convert.ToInt64(currentTimeStr));
            var diff = currentTime.Subtract(createdTime).TotalMinutes;
            if (diff < 30) return true;
            else return false;
        }
        /// <summary>
        /// This method is used to restructure the Forum detail list.
        /// </summary>
        void SortTheForumArray ()
        {
            var tempArr = new List<ForumDetailItem>();
            foreach (var item in forumDetailList)
            {
                if (!tempArr.Contains(item)) tempArr.Add(item);
                var listOfChildren = forumDetailList.FindAll((obj) => obj.parent == item.id);
                int parentIndex = tempArr.IndexOf(item);
                foreach (var child in listOfChildren)
                {
                    tempArr.Insert(++parentIndex, child);
                }

            }
            forumDetailList = tempArr;
        }
        /// <summary>         /// This method manages the Try again button clicked, And try to reload the data.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void TryAgain_Clicked(object sender, System.EventArgs e)
        {
            LoaderView.IsVisible = true;
            ErrorView.IsVisible = false;
            GetForumDetail();
        }

        /// <summary>         /// This method manages Next button clicks and load the next page data.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void NextClicked(object sender, System.EventArgs e)
        {
            
            if (currentIndex < forumDetailList.Count - 1)
            {
                currentIndex++;
                setDataForCurrentIndex();
            }
        }
        /// <summary>
        /// This method manages Previous button clicks and load the Previous page data.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void PreviousClicked(object sender, System.EventArgs e)
        {
            if (currentIndex > 0)
            {
                currentIndex--;
                setDataForCurrentIndex();
            }
        }
        /// <summary>
        /// This method manages First button clicks and move on the first page.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void FirstClicked(object sender, EventArgs e)
        {
            if (currentIndex > 0)
            {
                currentIndex = 0;
                setDataForCurrentIndex();
            }

        }
        /// <summary>
        /// This method manages Last button clicks and move on the last page.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void LastClicked(object sender, EventArgs e)
        {
            if (currentIndex < forumDetailList.Count - 1)
            {
                currentIndex = forumDetailList.Count - 1;
                setDataForCurrentIndex(); 
            }
        }
        /// <summary>
        /// This method manages Show Parent button clicks and show the parent comment.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void ShowParentClicked(object sender, System.EventArgs e)
        {
            var parentId = forumDetailList[currentIndex].parent;
            if (parentId != "0") {
                var parentObj = forumDetailList.Find((ForumDetailItem obj) => obj.id == parentId);
                var index = forumDetailList.IndexOf(parentObj);
                currentIndex = index;
                setDataForCurrentIndex();
            }
        }
        /// <summary>
        /// This method manages Edit button clicks and navigate to the edit comment page
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void EditClicked(object sender, System.EventArgs e)
        {
            var editPage = new ForumNewDiscussionPage()
            {
                subject = forumDetailList[currentIndex].subject,
                message = CommonClass.StripHTML(forumDetailList[currentIndex].message),
                titleStr = Title,
                postId = forumDetailList[currentIndex].id,
                isForEditing = true,
            };
            Navigation.PushAsync(editPage);
        }

        void DeleteClicked(object sender, EventArgs e)
        {
            //var postId = forumDetailList[currentIndex].id;
            //DeleteReply(postId);
        }
        /// <summary>
        /// This method manages Reply button clicks and navigate to the reply page
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void ReplyClicked(object sender, EventArgs e)
        {
            var replyPage = new ForumReplyPage()
            {
                parent_id = forumDetailList[currentIndex].id,
                discussion_id = forumListItem.id,
                subject = getReplySubjectText(forumDetailList[currentIndex].subject),
                summery = CommonClass.StripHTML(forumDetailList[currentIndex].message),
                titleStr = Title,
                username = forumDetailList[currentIndex].user_name
            };
            Navigation.PushAsync(replyPage);
        }
        /// <summary>
        /// This method manages Subscribe and unsubscribe button clicks.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void SubUnsubClicked(object sender, EventArgs e)
        {
            SubUnsubUserForDiscussion();
        }
        /// <summary>
        /// This method manages Post new comment button clicks and navigate to the new comment screen.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void PostNewComment_Clicked(object sender, System.EventArgs e)
        {
            var replyPage = new ForumReplyPage()
            {
                parent_id = forumDetailList[0].id,
                discussion_id = forumListItem.id,
                subject = getReplySubjectText(forumDetailList[0].subject),
                summery = CommonClass.StripHTML(forumDetailList[0].message),
                titleStr = Title,
                username = forumDetailList[currentIndex].user_name
            };
            Navigation.PushAsync(replyPage);
        }

        private string getBaseUrlForImages(string post_id)
        {
            // Eg: https://zimlapp.areteem.org/api/images/forum.php?forum_id=12&post_id=195&filename=Screen%20Shot%202017-08-21%20at%206.07.19%20PM.png

            string baseUrl =  Constants.baseURL + "/api/images/forum.php?forum_id=" + Constants.DISCUSSION_FORUM_ID + "&post_id=" + post_id + "&filename=";
            return baseUrl;
        }

        private string getAttachmentURL(string post_id, string fileName)
        {
            // Eg: https://zimlapp.areteem.org/api/images/forum.php?forum_id=12&post_id=196&filename=AMC82017Answers.pdf&is_attachment=yes

            string baseUrl = Constants.baseURL + "/api/images/forum.php?forum_id=" + Constants.DISCUSSION_FORUM_ID + "&post_id=" + post_id + "&filename=" + fileName + "&is_attachment=yes";
            return baseUrl;
        }

        private string getReplySubjectText(string subject)
        {
            if (subject.Contains("Re:"))
            {
                return subject;
            }
            else
            {
                return "Re: " + subject;
            }
        }



        private void AddAttachmentForCurrentPost()
        {
            attachmentView.Children.Clear();

            var attechmentListToShow = new List<string>(forumDetailList[currentIndex].attachments);

            foreach (string filename in forumDetailList[currentIndex].attachments)
            {
                if (forumDetailList[currentIndex].message.Contains(filename))
                {
                    attechmentListToShow.Remove(filename);
                }
            }

            if (attechmentListToShow.Count == 0) { return; }
                          
            foreach (string filename in attechmentListToShow)
            {
                var fileLayout = new StackLayout()
                {
                    Orientation = StackOrientation.Horizontal,
                    Margin = new Thickness(16, 0, 0, 0)
                };

                var image = new Image()
                {
                    Source = "attachment.png",
                    HorizontalOptions = LayoutOptions.Start
                };

                var fileNameLb = new Label()
                {
                    Text = filename,
                    FontSize = 14,
                    TextColor = Color.FromHex("#1C4277"),
                    HorizontalOptions = LayoutOptions.Fill,
                    HorizontalTextAlignment = TextAlignment.Start

                };
                fileLayout.Children.Add(image);
                fileLayout.Children.Add(fileNameLb);
                attachmentView.Children.Add(fileLayout);
                var fileTGR = new TapGestureRecognizer();
                fileTGR.Tapped += (sender, e) => {
                    var url = getAttachmentURL(forumDetailList[currentIndex].id, filename);
                    if (Device.RuntimePlatform == Device.iOS)
                    {
                        Navigation.PushAsync(new ForumShowAttachments() { url = url, titleTxt = filename });
                    }
                    else
                    {
                        var service = DependencyService.Get<INativeBrowserService>();
                        {
                            if (service == null) return;

                            service.LaunchNativeEmbeddedBrowser(url);
                        };
                    }
                };
                fileLayout.GestureRecognizers.Add(fileTGR);
                fileTGR.NumberOfTapsRequired = 1;

            }
        }
        /// <summary>
        /// This method manages the forum detail API call.
        /// </summary>
        public void GetForumDetail()
        {
            LoaderView.IsVisible = true;

            API.GetResponseFromServer(Constants.forumDetailAPI, new ForumDetailParam() { discussion_id = forumListItem.id, forum_id = Constants.DISCUSSION_FORUM_ID}, (content) =>
            {
                LoaderView.IsVisible = false;
                ForumDetailResponse response = JsonConvert.DeserializeObject<ForumDetailResponse>(content.ToString());

                if (response != null)
                {
                    forumDetailList = response.posts;
                    SortTheForumArray();
                    is_subscribed = response.is_user_subscribed;
                    currentTimeStr = response.current_timestamp;
                    if (is_subscribed == true) subUnsubTxt.Text = "Unsubscribe";
                    else subUnsubTxt.Text = "Subscribe";
                    setDataForCurrentIndex();
                    Title = MakeStringForTitle(forumDetailList[0].subject);

                }

            }, (message, errorType) => {
                LoaderView.IsVisible = false;
                ErrorView.IsVisible = true;
                if (errorType == ErrorType.Network)
                {
                    ErrorTitle.Text = Constants.NetworkErrorTitle;
                    ErrorMessage.Text = Constants.NetworkErrorMessage;
                    ActionButton.Text = "Try again";
                }
                else
                {
                    ErrorTitle.Text = Constants.ServerErrorTitle;
                    ErrorMessage.Text = Constants.ServerErrorMessage;
                    ActionButton.Text = "Refresh";
                }

            });
        }
        /// <summary>
        /// This mathod manages Subscribe or unsubscribe the user for discussion.
        /// </summary>
        public void SubUnsubUserForDiscussion()
        {
            LoaderView.IsVisible = true;

            API.GetResponseFromServer(Constants.forumSubUnsubAPI, new ForumSubUnsubParam() { discussion_id = forumListItem.id, forum_id = Constants.DISCUSSION_FORUM_ID }, async (content) =>
            {
                LoaderView.IsVisible = false;

                is_subscribed = !is_subscribed;
                if (is_subscribed == true) 
                {
                    subUnsubTxt.Text = "Unsubscribe"; 
                    await DisplayAlert(null, "Subscribed successfully", "Ok");

                }
                else {
                    subUnsubTxt.Text = "Subscribe";
                    await DisplayAlert(null, "Unsubscribed successfully", "Ok");
                } 
                subUnsubTxt.IsVisible = false;
                 

            }, async (message, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
                else { await DisplayAlert(null, message, "Ok"); }
            });
        }

        public void DeleteReply(string postId)
        {
            LoaderView.IsVisible = true;

            API.GetResponseFromServer(Constants.forumDeletePostAPI, new ForumDeletePostParam() { post_id = postId }, async (content) =>
            {
                LoaderView.IsVisible = false;
                await DisplayAlert(null, "Post removed successfully", "Ok");
                currentIndex = 0;
                GetForumDetail();

            }, async (message, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
                else { await DisplayAlert(null, message, "Ok"); }
            });
        }

        private string MakeStringForTitle(string str)
        {
            if (string.IsNullOrEmpty(str)) return "";
            else if (str.Length > 1) return str.ToCharArray().First().ToString().ToUpper() + str.Substring(1);
            else return str.ToUpper();
        } 
    }
}

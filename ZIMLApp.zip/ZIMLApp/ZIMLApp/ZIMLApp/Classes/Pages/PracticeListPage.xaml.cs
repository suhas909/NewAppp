﻿using System;
using System.Collections.Generic;
using System.Windows.Input;
using Newtonsoft.Json;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages to show the Practice list page.
    /// </summary>
    public partial class PracticeListPage : ContentPage
    {
        private List<Contest> SampleList = new List<Contest>();
        private List<Contest> MockList = new List<Contest>();
        private List<AMCContest> AMCList = new List<AMCContest>();
        private Dictionary<string, string> AMCDict = new Dictionary<string, string>();

        private string contest_type_Sample_ZIML = "ZIML";
        private string contest_type_Mock_AMC = "MockAMC";

        public PracticeListPage()
        {
            InitializeComponent();
            NavigationPage.SetBackButtonTitle(this, " ");
            AddToolbarItem();
            Title = "Practice";
            BindingContext = this;
            //PopulateData();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            NavigationPage navigationPage = (NavigationPage)((HomePage)Application.Current.MainPage).Detail;
            navigationPage.BarTextColor = Color.Black;
            HomePage home = (HomePage)Application.Current.MainPage;
            if (home != null)
            {
                home.IsGestureEnabled = true;
            }
            GetPracticeList(contest_type_Sample_ZIML);
        }

        protected override void OnDisappearing()
        {
            if (Application.Current.MainPage is HomePage)
            {
                base.OnDisappearing();
                HomePage home = (HomePage)Application.Current.MainPage;
                if (home != null)
                {
                    home.IsGestureEnabled = false;
                }
            }

        }

        void AddToolbarItem()
        {
            var info = new ToolbarItem
            {
                Icon = "info.png",
                Text = "Summary",
                Priority = 0
            };
            info.Clicked += async (s, e) => {
                await Navigation.PushAsync(new PracticeInfoPage());
            };
            ToolbarItems.Add(info);
        }
        /// <summary>
        /// Handles the value changed for Segmented Control.
        /// </summary>
        /// <param name="sender">SegmentedControl object.</param>
        /// <param name="e">Event arguments.</param>
        void Handle_ValueChanged(object sender, SegmentedControl.FormsPlugin.Abstractions.ValueChangedEventArgs e)
        {

            //SegContent.Children.Clear();

            switch (e.NewValue)
            {
                case 0:
                    {
                        SampleView.IsVisible = true;
                        MockView.IsVisible = false;
                        AMCView.IsVisible = false;
                    }
                    break;
                case 1:
                    {
                        if (MockList.Count == 0)
                        {
                            GetPracticeList(contest_type_Mock_AMC);
                        }
                        SampleView.IsVisible = false;
                        MockView.IsVisible = true;
                        AMCView.IsVisible = false;
                    }
                    break;
                case 2:
                    {

                        SampleView.IsVisible = false;
                        MockView.IsVisible = false;
                        AMCView.IsVisible = true;
                    }
                    break;
            }
        }
        /// <summary>
        /// Handles the sample list item tapped. And navigate to the parctice detail page.
        /// </summary>
        /// <param name="sender">List item object.</param>
        /// <param name="e">Event arguments.</param>
        async void Handle_SampleTapped(object sender, Xamarin.Forms.ItemTappedEventArgs e)
        {
            if (!Preference.IsUserLoggedIn)
            {
                await DisplayAlert(null, "Please sign in to attempt practice contest.", "Ok");
                Application.Current.MainPage = new NavigationPage(new SplashScreenPage());
            }
            else
            {
                Contest contestDetail = (Contest)SampleListView.SelectedItem;
                await Navigation.PushModalAsync(new PracticeDetailPage() { contest = contestDetail, isForSampleZiml = true });
            }
        }
        /// <summary>
        /// Handles the Mock AMC list item tapped. And navigate to the parctice detail page.
        /// </summary>
        /// <param name="sender">List item object.</param>
        /// <param name="e">Event arguments.</param>
        async void Handle_MockTapped(object sender, Xamarin.Forms.ItemTappedEventArgs e)
        {
            if (!Preference.IsUserLoggedIn)
            {
                await DisplayAlert(null, "Please sign in to attempt practice contest.", "Ok");
                Application.Current.MainPage = new NavigationPage(new SplashScreenPage());
            }
            else
            {
                Contest contestDetail = (Contest)MockListView.SelectedItem;
                await Navigation.PushModalAsync(new PracticeDetailPage() { contest = contestDetail });
            }

        }

        /// <summary>
        /// Handles the AMC contest list item tapped. And navigate to the list of AMC contest page .
        /// </summary>
        /// <param name="sender">List item object.</param>
        /// <param name="e">Event arguments.</param>
        void Handle_AMCTapped(object sender, Xamarin.Forms.ItemTappedEventArgs e)
        {
            AMCContest contestDetail = (AMCContest)AMCListView.SelectedItem;
            GetPracticeList(contestDetail.contest_type);
            //Navigation.PushAsync(new PracticeAMCListPage());
        }


        /// <summary>         /// This method manages the Try again button clicked, and try to reload the data.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void TryAgain_Clicked(object sender, System.EventArgs e)
        {
            LoaderView.IsVisible = true;
            ErrorView.IsVisible = false;
            GetPracticeList(contest_type_Sample_ZIML);
        }
        /// <summary>
        /// Gets the practice list from the API.
        /// </summary>
        /// <param name="contest_type">Contest type.</param>
        public void GetPracticeList(string contest_type)
        {
            LoaderView.IsVisible = true;
            PracticeListParam param = new PracticeListParam();
            param.contest_type = contest_type;

            API.GetResponseFromServer(Constants.practiceListAPI, param, (content) =>
            {
                PracticeListResponse practiceListResponse = JsonConvert.DeserializeObject<PracticeListResponse>(content.ToString());
                LoaderView.IsVisible = false;
                if (practiceListResponse != null)
                {
                    /*
                          "contest_types": {
                            "Sample ZIML": "ZIML",
                            "Mock AMC Series": "MockAMC",
                            "AMC Contest Series": {
                                "AMC 8": "AMC8",
                                "AMC 10": "AMC10",
                                "AMC 12": "AMC12",
                                "AIME": "AIME"
                            }
                        },
                    */
                    if (AMCDict.Count == 0)
                    {
                        AMCDict =  JsonConvert.DeserializeObject<Dictionary<string, string>>(practiceListResponse.contest_types["AMC Contest Series"].ToString());
                        foreach (KeyValuePair<string, string> entry in AMCDict)
                        {
                            AMCList.Add(new AMCContest(entry.Key, entry.Value));
                        }
                        AMCListView.ItemsSource = AMCList;
                    }

                    if (practiceListResponse.selected_contest_type == contest_type_Sample_ZIML)
                    {
                        SampleList = practiceListResponse.contests;
                        SampleListView.ItemsSource = SampleList;
                    }
                    else if (practiceListResponse.selected_contest_type == contest_type_Mock_AMC)
                    {
                        MockList = practiceListResponse.contests;
                        MockListView.ItemsSource = MockList;
                    }
                    else
                    {
                        Navigation.PushAsync(new PracticeAMCListPage(){
                            AMCContestList = practiceListResponse.contests,
                            amcContest = (AMCContest)AMCListView.SelectedItem
                        });
                    }

                }

            }, (message, errorType) =>
            {
                LoaderView.IsVisible = false;
                ErrorView.IsVisible = true;
                if (errorType == ErrorType.Network)
                {
                    ErrorTitle.Text = Constants.NetworkErrorTitle;
                    ErrorMessage.Text = Constants.NetworkErrorMessage;
                    ActionButton.Text = "Try again";
                }
                else
                {
                    ErrorTitle.Text = Constants.ServerErrorTitle;
                    ErrorMessage.Text = Constants.ServerErrorMessage;
                    ActionButton.Text = "Refresh";
                }
            });
        }

    }
}

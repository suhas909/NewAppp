﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class mamages to show the Practice result page.
    /// </summary>
    public partial class PracticeResultPage : ContentPage
    {

        List<string> answerOptionList = new List<string>()
        {
            "A","B","C","D","E"
        };
        private string Question_Type_MCQ = "multichoice";
        private string Question_Type_Numerical = "numerical";

        private int currentIndex = 0;
        public Contest contest;
        public bool isForSampleZiml = false;
        //public PracticeDetailResponse detailResponse;

        public List<Question> questions;
        public Attempts attempt;
        //private Dictionary<string, List<Answer>> answers = new Dictionary<string, List<Answer>>(); 

        private ObservableCollection<AnswerSummary> answerSummaryList = new ObservableCollection<AnswerSummary>();


        public PracticeResultPage()
        {
            InitializeComponent();
            if (Device.RuntimePlatform == Device.iOS) { Padding = new Thickness(0, 20, 0, 0); }
            initiaiizeView();
            LoaderView.IsVisible = true;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            //questions = detailResponse.questions;
            //attempts = detailResponse.attempts;
            //answers = detailResponse.answers;

            if (contest.name.Contains("AMC 10") || contest.name.Contains("AMC 12")) { answerOptionList.Add("Leave blank (1.5 points)"); }
            if (isForSampleZiml) viewSolutionBtn.IsVisible = true;
            if (answerSummaryList.Count == 0) 
            {
                InitSummaryData();
            }
            setDataOnView(questions[currentIndex].questiontext, questions[currentIndex].id);
            LoaderView.IsVisible = false;
            //if (questions.Count == 0)
                //GetQuizDeatil();
        }

        public void initiaiizeView()
        {
            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += async (s, e) => {
                if (summaryView.IsVisible == false)
                {
                    currentIndex = 0;
                    showSummaryView();
                }
                else
                {
                    await this.Navigation.PopModalAsync();
                }
            };
            closeImg.GestureRecognizers.Add(tapGestureRecognizer);
            tapGestureRecognizer.NumberOfTapsRequired = 1;

            var nextTGR = new TapGestureRecognizer();
            nextTGR.Tapped += NextClicked;
            nextImg.GestureRecognizers.Add(nextTGR);
            nextTGR.NumberOfTapsRequired = 1;

            var previousTGR = new TapGestureRecognizer();
            previousTGR.Tapped += PreviousClicked;
            previousImg.GestureRecognizers.Add(previousTGR);
            previousTGR.NumberOfTapsRequired = 1;

            titleTxt.Text = "Question Summary";
            previousImg.IsVisible = false;

        }

        public void setDataOnView(string html, string question_id)
        {
            string htmlstr = WebUtility.HtmlDecode(html);
            string baseurl = getBaseUrlForImages(question_id);
            htmlstr = htmlstr.Replace("@@PLUGINFILE@@/", baseurl);

            string htmlData = CommonClass.getHTMLContent(htmlstr);

            var url = new HtmlWebViewSource { Html = htmlData };
            questionWebview.Source = url;
        }
        /// <summary>
        /// Create the summary list data to show on the result page.
        /// </summary>
        void InitSummaryData()
        {
            
            for (int i = 0; i < questions.Count; i++)
            {
                string answerStr = "";
                string correctAnswer = "";
                if (questions[i].type == Question_Type_MCQ)
                {
                    Answer answerObj = questions[i].answers.Find((Answer obj) => Convert.ToInt32(Convert.ToDecimal(obj.fraction)) == 1);
                    answerStr = answerOptionList.IndexOf(answerObj.answer).ToString();
                    correctAnswer = answerObj.answer;
                }
                else
                {
                    if (questions[i].answers.Count > 0) correctAnswer = answerStr = questions[i].answers.Last().answer;
                }
                //Answer answerObj = questions[i].answers.Find((Answer obj) => Convert.ToInt32(Convert.ToDecimal(obj.fraction)) == 1);
                //string answerStr = answerOptionList.IndexOf(answerObj.answer).ToString();
                if (attempt.submitted_answers?.Count > 0)
                {
                    var submittedAnswerArr = attempt.submitted_answers;
                    List<SubmittedAnswer> submittedAnswer = submittedAnswerArr.FindAll((obj) => obj.slot == (i + 1).ToString());
                    if (submittedAnswer != null && submittedAnswer.Count > 0)
                    {
                        string sequence = (Convert.ToInt32(submittedAnswer.Last().sequence) + 1).ToString();
                        string submitedAnsStr = "";
                        if (questions[i].type == Question_Type_MCQ)
                            submitedAnsStr = answerOptionList[(int)Convert.ToInt64(submittedAnswer.Last().answer)];
                        else
                            submitedAnsStr = submittedAnswer.Last().answer;
                    
                        if (answerStr == submittedAnswer.Last().answer) 
                        {
                            AnswerSummary answerSummary = new AnswerSummary(i, sequence, submitedAnsStr, true);
                            answerSummary.correctAns = correctAnswer;
                            answerSummaryList.Add(answerSummary); 
                        }   
                        else
                        {
                            AnswerSummary answerSummary = new AnswerSummary(i, sequence, submitedAnsStr, false);
                            answerSummary.correctAns = correctAnswer;
                            answerSummaryList.Add(answerSummary); 
                        }
                            
                    }
                    else
                    {
                        AnswerSummary answerSummary = new AnswerSummary(i, "NA");
                        answerSummary.correctAns = correctAnswer;
                        answerSummaryList.Add(answerSummary);
                    }
                }
                else
                {
                    AnswerSummary answerSummary = new AnswerSummary(i, "NA");
                    answerSummary.correctAns = correctAnswer;
                    answerSummaryList.Add(answerSummary);
                }

            }
            summaryList.ItemsSource = answerSummaryList;
        }

        /// <summary>
        /// This method manages the Next button click and move to the next question.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void NextClicked(object sender, System.EventArgs e)
        {
            moveNext();
        }

        /// <summary>
        /// This method manages the Previous button click and move to the previous question.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void PreviousClicked(object sender, System.EventArgs e)
        {
            movePrivious();
        }

        /// <summary>
        /// This method manages the Summary cell item click and show question related to that cell item.
        /// </summary>
        /// <param name="sender">List item object</param>
        /// <param name="e">Event arguments.</param>
        void SummaryCellTapped(object sender, System.EventArgs e)
        {
            AnswerSummary answer = (AnswerSummary)summaryList.SelectedItem;
            int index = answerSummaryList.IndexOf(answer);
            currentIndex = index;
            hideSummaryView();
        }

        /// <summary>
        /// This method manages the View solution button click and navigate to the solution page where user can see the solution for the question.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        async void ViewSolutionClicked(object sender, System.EventArgs e)
        {
            ViewSolutionPage page = new ViewSolutionPage();
            page.title = "";
            string htmlstr = questions[currentIndex].generalfeedback + "<p>The correct answer is : " + answerSummaryList[currentIndex].correctAns + "</p>"; //WebUtility.HtmlDecode(questions[currentIndex].generalfeedback);
            page.solution = htmlstr;
            page.quiz_id = contest.quiz_id;
            page.question_id = questions[currentIndex].id;
            page.title = contest.name;
            await Navigation.PushModalAsync(page);
        }

        /// <summary>
        /// This method used to move to the next question.
        /// </summary>
        void moveNext()
        {
            if (summaryView.IsVisible == true)
            {
                hideSummaryView();
            }
            else if (currentIndex < questions.Count)
            {
                currentIndex++;
                setDataOnView(questions[currentIndex].questiontext, questions[currentIndex].id);
                titleTxt.Text = "Question " + (currentIndex + 1);
                previousImg.IsVisible = true;
                if (answerSummaryList[currentIndex].isCorrect == true)
                {
                    answerImage.Source = "happy_face.png";
                    if (questions[currentIndex].type == Question_Type_MCQ)
                        txtPoints.Text = "You chose (" + answerSummaryList[currentIndex].answer + ")";
                    else
                        txtPoints.Text = "Your answer: " + answerSummaryList[currentIndex].answer;
                    txtAnswerStatus.Text = "It's correct.";
                    txtAnswerStatus.TextColor = Color.Green;
                    txtAnswerStatus.IsVisible = true;
                    correctAnsText.Text = "";
                    correctAnsText.IsVisible = false;
                    txtPoints.IsVisible = true;
                }
                else
                {
                    correctAnsText.IsVisible = true;
                    answerImage.Source = "sad_face.png";
                    if (questions[currentIndex].type == Question_Type_MCQ)
                    {
                        if (answerSummaryList[currentIndex].answer == "Leave blank (1.5 points)")
                            txtPoints.Text = "You chose " + answerSummaryList[currentIndex].answer + ""; 
                        else
                            txtPoints.Text = "You chose (" + answerSummaryList[currentIndex].answer + ")"; 
                    }   
                    else
                        txtPoints.Text = "Your answer: " + answerSummaryList[currentIndex].answer;
                    txtAnswerStatus.Text = "It's wrong.";
                    if (answerSummaryList[currentIndex].answer == "NA")
                    {
                        txtAnswerStatus.Text = "Not Answered.";
                        txtPoints.Text = "";
                        txtPoints.IsVisible = false;
                    }
                    else
                    {
                        txtPoints.IsVisible = true;
                    }
                    txtAnswerStatus.TextColor = Color.Red;

                    if (answerSummaryList[currentIndex].answer == "Leave blank (1.5 points)") { txtAnswerStatus.IsVisible = false; }
                    else {txtAnswerStatus.IsVisible = true; }

                    if (questions[currentIndex].type == Question_Type_MCQ)
                        correctAnsText.Text = "Correct answer is (" + answerSummaryList[currentIndex].correctAns + ")";
                    else
                        correctAnsText.Text = "Correct answer is " + answerSummaryList[currentIndex].correctAns;
                }
                if (currentIndex == questions.Count - 1) { nextImg.IsVisible = false; }
            }

        }


        /// <summary>
        /// This method used to move to the previous question.
        /// </summary>
        void movePrivious()
        {
            if (currentIndex == 0)
            {
                showSummaryView();
            }
            else
            {
                currentIndex--;
                setDataOnView(questions[currentIndex].questiontext, questions[currentIndex].id);
                titleTxt.Text = "Question " + (currentIndex + 1);
                nextImg.IsVisible = true;
                if (answerSummaryList[currentIndex].isCorrect == true)
                {
                    answerImage.Source = "happy_face.png";
                    if (questions[currentIndex].type == Question_Type_MCQ)
                        txtPoints.Text = "You chose (" + answerSummaryList[currentIndex].answer + ")";
                    else
                        txtPoints.Text = "Your answer: " + answerSummaryList[currentIndex].answer;
                    
                    txtAnswerStatus.Text = "It's correct.";
                    txtAnswerStatus.TextColor = Color.Green;
                    txtAnswerStatus.IsVisible = true;
                    correctAnsText.Text = "";
                    correctAnsText.IsVisible = false;
                    txtPoints.IsVisible = true;
                }
                else
                {
                    correctAnsText.IsVisible = true;
                    answerImage.Source = "sad_face.png";
                    if (questions[currentIndex].type == Question_Type_MCQ)
                    {
                        if (answerSummaryList[currentIndex].answer == "Leave blank (1.5 points)")
                            txtPoints.Text = "You chose " + answerSummaryList[currentIndex].answer + "";
                        else
                            txtPoints.Text = "You chose (" + answerSummaryList[currentIndex].answer + ")";
                    }
                    else
                        txtPoints.Text = "Your answer: " + answerSummaryList[currentIndex].answer;
                    txtAnswerStatus.Text = "It's wrong.";
                    txtAnswerStatus.TextColor = Color.Red;
                    if (answerSummaryList[currentIndex].answer == "NA")
                    {
                        txtAnswerStatus.Text = "Not Answered.";
                        txtPoints.Text = "";
                        txtPoints.IsVisible = false;
                    }
                    else
                    {
                        txtPoints.IsVisible = true;
                    }

                    if (answerSummaryList[currentIndex].answer == "Leave blank (1.5 points)") { txtAnswerStatus.IsVisible = false; }
                    else { txtAnswerStatus.IsVisible = true; }

                    if (questions[currentIndex].type == Question_Type_MCQ)
                        correctAnsText.Text = "Correct answer is (" + answerSummaryList[currentIndex].correctAns + ")";
                    else
                        correctAnsText.Text = "Correct answer is " + answerSummaryList[currentIndex].correctAns;
                }
            }
        }

        /// <summary>
        /// This method is used to shows the summary view.
        /// </summary>
        void showSummaryView()
        {
            questionView.IsVisible = false;
            summaryView.IsVisible = true;
            nextImg.IsVisible = true;
            previousImg.IsVisible = false;
            titleTxt.Text = "Question Summary";
        }

        /// <summary>
        /// This method is used to hide the summary view.
        /// </summary>
        void hideSummaryView()
        {
            questionView.IsVisible = true;
            summaryView.IsVisible = false;
            nextImg.IsVisible = true;
            previousImg.IsVisible = true;
            setDataOnView(questions[currentIndex].questiontext, questions[currentIndex].id);
            titleTxt.Text = "Question " + (currentIndex + 1);
            if (answerSummaryList[currentIndex].isCorrect == true)
            {
                answerImage.Source = "happy_face.png";
                if (questions[currentIndex].type == Question_Type_MCQ)
                    txtPoints.Text = "You chose (" + answerSummaryList[currentIndex].answer + ")";
                else
                    txtPoints.Text = "Your answer: " + answerSummaryList[currentIndex].answer;
                txtAnswerStatus.Text = "It's correct.";
                txtAnswerStatus.TextColor = Color.Green;
                txtAnswerStatus.IsVisible = true;
                correctAnsText.Text = "";
                correctAnsText.IsVisible = false;
                txtPoints.IsVisible = true;
            }
            else
            {
                correctAnsText.IsVisible = true;
                answerImage.Source = "sad_face.png";
                if (questions[currentIndex].type == Question_Type_MCQ)
                {
                    if (answerSummaryList[currentIndex].answer == "Leave blank (1.5 points)")
                        txtPoints.Text = "You chose " + answerSummaryList[currentIndex].answer + "";
                    else
                        txtPoints.Text = "You chose (" + answerSummaryList[currentIndex].answer + ")";
                }
                else
                    txtPoints.Text = "Your answer: " + answerSummaryList[currentIndex].answer;
                txtAnswerStatus.Text = "It's wrong.";
                txtAnswerStatus.TextColor = Color.Red;
                if (answerSummaryList[currentIndex].answer == "NA")
                {
                    txtAnswerStatus.Text = "Not Answered.";
                    txtPoints.Text = "";
                    txtPoints.IsVisible = false;
                }
                else
                {
                    txtPoints.IsVisible = true;
                }

                if (answerSummaryList[currentIndex].answer == "Leave blank (1.5 points)") { txtAnswerStatus.IsVisible = false; }
                else { txtAnswerStatus.IsVisible = true; }

                if (questions[currentIndex].type == Question_Type_MCQ)
                    correctAnsText.Text = "Correct answer is (" + answerSummaryList[currentIndex].correctAns + ")";
                else
                    correctAnsText.Text = "Correct answer is " + answerSummaryList[currentIndex].correctAns;
            }
            if (currentIndex == questions.Count - 1) { nextImg.IsVisible = false; }

        }

        private string getBaseUrlForImages(string question_id)
        {
            // Eg: https://zimlapp.areteem.org/api/images/question.php?quiz_id=906&question_id=7522&filename=%5B180601%5D.png&filearea=questiontext

            string baseUrl = Constants.baseURL + "/api/images/question.php?quiz_id=" + contest.quiz_id + "&question_id=" + question_id + "&filearea=questiontext&filename=";
            return baseUrl;
        }
    
    }
}

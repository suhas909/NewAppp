﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Model;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages the menu list page in the app. This page opens when we click on the burger icon.
    /// </summary>
    public partial class MenuListPage : ContentPage
    {
        public ListView ListView { get { return listView; } }


        public MenuListPage()
        {
            InitializeComponent();
            Icon = "ic_menu_white.png";

            var masterPageItems = new List<MasterPageItem>();
            masterPageItems.Add(new MasterPageItem
            {
                Title = "Home",
                IconSource = "Home.png",
                TargetType = typeof(DashboardPage)
            });

            masterPageItems.Add(new MasterPageItem
            {
                Title = "Daily Magic Spells",
                IconSource = "daily_navbar.png",
                TargetType = typeof(DailyMagicSpellsPage)
            });
            masterPageItems.Add(new MasterPageItem
            {
                Title = "Monthly Contests",
                IconSource = "monthly_navbar.png",
                TargetType = typeof(MonthlyContestPage)
            });
            masterPageItems.Add(new MasterPageItem
            {
                Title = "Practice",
                IconSource = "practice_navbar.png",
                TargetType = typeof(PracticeListPage)
            });
            masterPageItems.Add(new MasterPageItem
            {
                Title = "Discussion Forum",
                IconSource = "forum_navbar.png",
                TargetType = typeof(ForumsListPage)
            });
            masterPageItems.Add(new MasterPageItem
            {
                Title = "Leaderboard",
                IconSource = "leaderboard_navbar.png",
                TargetType = typeof(LeaderboardPage)
            });
            masterPageItems.Add(new MasterPageItem
            {
                Title = "News and Announcements",
                IconSource = "news_navbar.png",
                TargetType = typeof(NewsListPage)
            });
            masterPageItems.Add(new MasterPageItem
            {
                Title = "Settings",
                IconSource = "settings_navbar.png",
                TargetType = typeof(SettingsPage)
            });
            //masterPageItems.Add(new MasterPageItem
            //{
            //    Title = "Help",
            //    IconSource = "help_navbar.png",
            //    TargetType = typeof(ContactUsDetailPage)
            //});

            listView.ItemsSource = masterPageItems;
        }

    }
}

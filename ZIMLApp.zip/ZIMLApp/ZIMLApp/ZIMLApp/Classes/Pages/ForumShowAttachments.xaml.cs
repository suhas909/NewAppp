﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration;

namespace ZIMLApp.Classes.Pages
{

    /// <summary>
    /// This class manages to show the Attachments in the discussion forums.
    /// </summary>
    public partial class ForumShowAttachments : ContentPage
    {

        public string url = "";
        public string titleTxt = "";

        public ForumShowAttachments()
        {
            InitializeComponent();
        }

		protected override void OnAppearing()
		{
            base.OnAppearing();
            LoaderView.IsVisible = true;
            Title = titleTxt;
            webView.Source = url; 

        }

        void Handle_Navigated(object sender, Xamarin.Forms.WebNavigatedEventArgs e)
        {
            LoaderView.IsVisible = false;
        }
	}
}

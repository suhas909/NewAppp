﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using System.Diagnostics;
using ZIMLApp.Classes.Utility;
using ZIMLApp.Classes.Model;
using System.Threading.Tasks;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages the Reply page for discussion forum.
    /// </summary>
    public partial class ForumReplyPage : ContentPage
    {
        public string discussion_id = "";
        public string parent_id = "";
        public string subject = "";
        public string summery = "";
        public string titleStr = "";
        public string username = "";

        public ForumReplyPage()
        {
            InitializeComponent();
            summaryTxt.MaxLines = 2;
            //replyEditor.Text = tempText;
        }

		protected override void OnAppearing()
		{
            base.OnAppearing();
            Title = titleStr;
            nameTxt.Text = username;
            subjectTE.Text = subject;
            summaryTxt.Text = summery;

		}

		protected override void OnDisappearing()
		{
            base.OnDisappearing();
		}
        /// <summary>
        /// This method manages Posts button clicks.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
		async void PostBtn_Clicked(object sender, System.EventArgs e)
        {
            if(string.IsNullOrWhiteSpace(subjectTE.Text))
            {
                await DisplayAlert(null, "Please add a subject.", "Ok");
                return;
            }
            else if (string.IsNullOrWhiteSpace(replyEditor.Text) || replyEditor.Text == "Write your comment here")
            {
                await DisplayAlert(null, "Please add message.", "Ok");
                return;
            }
            string htmlData = CreateHTMLFromString(replyEditor.Text);
            Debug.WriteLine("htmlData==> \n"+htmlData);
            PostReply(subjectTE.Text, htmlData);
        }


        string CreateHTMLFromString(string text)
        {
            string htmlData = "<p>";
            htmlData = htmlData + text;
            htmlData = htmlData + "</p>";

            return htmlData;
        }

        //private void replyEditor_Focused(object sender, FocusEventArgs e)
        //{
        //    scrollview.ScrollToAsync(0, 0, true);
        //}

        /// <summary>
        /// This method manages API call for Reply.
        /// </summary>
        /// <param name="subject">Subject for the Reply</param>
        /// <param name="message">Reply message</param>
        public void PostReply(string subject, string message)
        {
            LoaderView.IsVisible = true;

            var param = new ForumReplyPostParam()
            {
                subject = subject,
                message = message,
                discussion_id = discussion_id,
                parent_id = parent_id
            };
            API.GetResponseFromServer(Constants.forumReplyPostAPI, param, async (content) =>
            {
                LoaderView.IsVisible = false;
                await Navigation.PopAsync();

            }, async (msg, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
                else { await DisplayAlert(null, msg, "Ok"); }
            });
        }

    }
}

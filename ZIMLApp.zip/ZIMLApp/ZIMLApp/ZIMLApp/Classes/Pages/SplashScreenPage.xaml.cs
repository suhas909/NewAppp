﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using System.Net.NetworkInformation;
using Plugin.FacebookClient;

namespace ZIMLApp.Classes.Pages
{

    /// <summary>
    /// This class manages to show the Splash screen page.
    /// </summary>
    public partial class SplashScreenPage : ContentPage
    {
        public SplashScreenPage()
        {
            InitializeComponent();
            AddGestureRecognizer();
            NavigationPage.SetHasNavigationBar(this, false);

        }

        async public void Create_Account_Clicked(object sender, System.EventArgs e)
        {
            await this.Navigation.PushAsync(new CreateAccountPage());
        }


        async public void Sign_In_Clicked(object sender, System.EventArgs e)
        {
            await this.Navigation.PushAsync(new SignInPage());
        }

        void AddGestureRecognizer()
        {
            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += (s, e) =>
            {
                Application.Current.MainPage = new HomePage();
            };
            tapGestureRecognizer.NumberOfTapsRequired = 1;
            txtContinueAsGuest.GestureRecognizers.Add(tapGestureRecognizer);

        }


    }
}

﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using System.Diagnostics;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;
using Newtonsoft.Json;
using System.Net;
using System.Linq;


namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages to show the daily magic spell detail page.
    /// </summary>
    public partial class QuestionPage : ContentPage
    {
        public string QuestionName = "";
        public string QuestionId = "";

        private int recentAttemtsCount = 0;

        private QuestionDetail questionDetail;
        private QuestionDetailResponse questionDetailResponse;
        private bool isloadingFirstTime = true;
        private DateTime startTime;
        private bool isAnswerSubmitted = false;
        private string recentAttemptId = "";

		public override string ToString()
		{
            return QuestionName + "-" + QuestionId;
		}

		public QuestionPage()
        {   
            InitializeComponent();
            //loaderWebView.Source = CommonClass.GetLoaderWebViewSource();
            NavigationPage.SetBackButtonTitle(this, " ");
            LoaderView.IsVisible = true;
            initializeView();
            Title = QuestionName;
            startTime = DateTime.Now;
            AddToolbarItems();
            webView.HeightRequest = Application.Current.MainPage.Height - 100;

        }

        private void AddToolbarItems()
        {
            var share = new ToolbarItem
            {
                //Command = ViewModel.LoadItemsCommand,
                Icon = "ic_share_black.png",
                Priority = 0
                    
            };
            share.Command = new Command(() =>
            {
                var url = string.Empty;
               // string.IsNullOrEmpty(Preference.FacebookShareURL) ? Constants.baseURL + "/" : Preference.FacebookShareURL
                if (string.IsNullOrEmpty(Preference.FacebookShareURL))
                {
                    url = Constants.baseURL;
                }
                else
                {
                    url = Preference.FacebookShareURL;
                }
                DependencyService.Get<IShare>().Share("Ziml App", "https://ziml.areteem.org/ziml/dailymagicspells.php");
                //DependencyService.Get<IShare>().Share("Ziml App", Constants.QuizBaseUrl+ QuestionId);
            });
            ToolbarItems.Add(share);
        }

		protected override void OnAppearing()
		{
            base.OnAppearing();
            Title = QuestionName;

            if(isloadingFirstTime)
            {
                DailyMagicSpellsDetailParam param = new DailyMagicSpellsDetailParam();
                param.quiz_id = QuestionId;
                GetDailyMagicSpellsDetail(param);
                //isloadingFirstTime = false;
            }

		}

        private void initializeView()
        {
            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += (s, e) =>
            {
                if (recentAttemptList.IsVisible == true)
                {
                    showTxt.Text = "Show recent attempts";
                    showImg.Source = "ic_indicator_down.png";
                    recentAttemptList.HeightRequest = 0;
                    recentAttemptList.IsVisible = false;
                    //webView.IsVisible = true;
                }
                else
                {
                    showTxt.Text = "Hide recent attempts";
                    showImg.Source = "ic_indicator_up.png";
                    if (recentAttemtsCount >= 3) recentAttemptList.HeightRequest = 3 * 80 + 10;
                    else recentAttemptList.HeightRequest = recentAttemtsCount * 80 + 10;
                    recentAttemptList.IsVisible = true;
                    //webView.IsVisible = false;
                }
            };
            tapGestureRecognizer.NumberOfTapsRequired = 1;
            txtShowRecentAttempts.GestureRecognizers.Add(tapGestureRecognizer);

            var backTxtTGR = new TapGestureRecognizer();
            backTxtTGR.Tapped += (s, e) =>
            {
                webView.IsVisible = true;
                recentAttemptLayout.IsVisible = true;
                reviewShowAnswer.IsVisible = false;
                backTxt.IsVisible = false;
            };
            backTxtTGR.NumberOfTapsRequired = 1;
            backTxt.GestureRecognizers.Add(backTxtTGR);

        }
        /// <summary>
        /// Gets the daily magic spells detail from API.
        /// </summary>
        /// <param name="param">Daily magic spell API Parameter.</param>
        public void GetDailyMagicSpellsDetail(DailyMagicSpellsDetailParam param)
        {
            API.GetResponseFromServer(Constants.dailyMagicSpellsDetailAPI, param, HandleSuccess, HandleFailure);
        }
        /// <summary>         /// Handles the success for the detail API.         /// </summary>         /// <param name="contents">Contents object return from the API call.</param>
        void HandleSuccess(object contents)
        {
            questionDetailResponse = JsonConvert.DeserializeObject<QuestionDetailResponse>(contents.ToString());
            questionDetail = questionDetailResponse.details;
            if (questionDetail != null)
            {
                string questiontext = questionDetail.questiontext;
                Debug.WriteLine(questiontext);
                var attempts = questionDetailResponse.attempts;

                if ( attempts != null && attempts.Count >0)
                {
                    recentAttemptList.ItemsSource = attempts;
                    recentAttemtsCount = attempts.Count;
                    txtShowRecentAttempts.IsVisible = true;

                }
                else 
                {
                    txtShowRecentAttempts.IsVisible = false;
                }

                if(string.IsNullOrEmpty(questionDetail.generalfeedback))
                {
                    viewSolutionBtn.IsVisible = false;

                }
                else
                {
                    viewSolutionBtn.IsVisible = true;

                }

                if (isAnswerSubmitted)
                {
                    Attempt recentAttempt = attempts.Find(x => x.id == recentAttemptId);
                    if (recentAttempt != null)
                    {
                        int grades = Convert.ToInt32(Convert.ToDecimal(recentAttempt.sumgrades));
                        if(grades == 0)
                        {
                            answerImage.Source = "sad_face.png";
                            txtAnswerStatus.Text = "Your answer is wrong.";
                            txtAnswerStatus.TextColor = Color.Red;
                            txtPoints.IsVisible = false;
                            answerStatusLayout.IsVisible = true;
                        }
                        else
                        {
                            answerImage.Source = "happy_face.png";
                            txtAnswerStatus.Text = "Your answer is right.";
                            txtAnswerStatus.TextColor = Color.Green;
                            txtPoints.Text = "";//recentAttempt.getGrade();
                            txtPoints.IsVisible = true;
                            answerStatusLayout.IsVisible = true;
                        }
                    }
                    afterAnswerSubmissionLayout.IsVisible = true;
                    afterAnswerSubmissionLayout.FadeTo(1, 500);

                    submitbuttonLayout.IsVisible = false;
                    Title = "Result";                                                                            
                    LoaderView.IsVisible = false;
                } 
                else 
                {
                    if (isloadingFirstTime && attempts != null && attempts.Count > 0)
                    {
                        afterAnswerSubmissionLayout.IsVisible = true;
                        afterAnswerSubmissionLayout.Opacity = 1;
                        submitbuttonLayout.IsVisible = false;
                        LoaderView.IsVisible = false;
                        showTxt.Text = "Hide recent attempts";
                        showImg.Source = "ic_indicator_up.png";
                        if (recentAttemtsCount >= 3) recentAttemptList.HeightRequest = 3 * 80 + 10;
                        else recentAttemptList.HeightRequest = recentAttemtsCount * 80 + 10;
                        recentAttemptList.IsVisible = true;
                        answerStatusLayout.IsVisible = false;


                    }
                    else
                    {
                        recentAttemptList.IsVisible = false;
                        recentAttemptList.HeightRequest = 0;

                    }
                    string htmlstr = WebUtility.HtmlDecode(questiontext);
                    string baseurl = getBaseUrlForImages();
                    htmlstr = htmlstr.Replace("@@PLUGINFILE@@/", baseurl);
                    setDataOnView(htmlstr);
                    isloadingFirstTime = false;
                }
            }

        }

        /// <summary>         /// Handles the failure for the API call         /// </summary>         /// <param name="message">Message related to the failure.</param>         /// <param name="errorType">Error type.</param>
        void HandleFailure(string message, ErrorType errorType)
        {
            LoaderView.IsVisible = false;
            ErrorView.IsVisible = true;
            if (errorType == ErrorType.Network)
            {
                ErrorTitle.Text = Constants.NetworkErrorTitle;
                ErrorMessage.Text = Constants.NetworkErrorMessage;
                ActionButton.Text = "Try again";
            }
            else
            {
                ErrorTitle.Text = Constants.ServerErrorTitle;
                ErrorMessage.Text = Constants.ServerErrorMessage;
                ActionButton.Text = "Refresh";
            }
        }

        /// <summary>
        /// Sets the data on view.
        /// </summary>
        /// <param name="html">Question text.</param>
        public void setDataOnView(string html)
        {
            string htmlData = CommonClass.getHTMLContent(html);

            Debug.WriteLine(htmlData);
            var url = new HtmlWebViewSource
            {
                Html = htmlData
            };
            webView.IsVisible = true;
            webView.HeightRequest = Application.Current.MainPage.Height - 100;
            webView.Source = url;
            //afterAnswerSubmissionLayout.IsVisible = false;
            LoaderView.IsVisible = false;

        }

        /// <summary>         /// This method manages the Submit answer button click.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        async void Submit_Clicked(object sender, System.EventArgs e)
        {
            if (string.IsNullOrEmpty(edtAnswer.Text))
            {
                await DisplayAlert(null, "Please enter your answer.", "Ok");
                return;
            }
            
            if (!Preference.IsUserLoggedIn)
            {
                await DisplayAlert(null, "Please sign in to submit the answer.", "Ok");
                Application.Current.MainPage = new NavigationPage(new SplashScreenPage());
            }
            else
            {
                double ansValue;
                bool isDoubleVaue = double.TryParse(edtAnswer.Text, out ansValue);
                if (isDoubleVaue)
                {
                    isAnswerSubmitted = true;
                    SubmitAttempt();
                }
                else
                {
                    await DisplayAlert(null, "You must enter a valid number. Do not include a unit in your response.", "Ok");
                }

            }
        }

        /// <summary>         /// This method manages the Try again button clicked from the error screen, and try to reload the data.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void TryAgain_Clicked(object sender, System.EventArgs e)
        {
            LoaderView.IsVisible = true;
            ErrorView.IsVisible = false;
            DailyMagicSpellsDetailParam param = new DailyMagicSpellsDetailParam();
            param.quiz_id = QuestionId;
            GetDailyMagicSpellsDetail(param);
        }

        /// <summary>
        /// This method manages the Try again button clicked, show the UI to reattempt the question
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void TryAgainQuestion_Clicked(object sender, System.EventArgs e)
        {
            isAnswerSubmitted = false;
            submitbuttonLayout.IsVisible = true;
            showTxt.Text = "Show recent Attempts";
            showImg.Source = "ic_indicator_down.png";
            recentAttemptList.HeightRequest = 0;
            recentAttemptList.IsVisible = false;
            recentAttemptLayout.IsVisible = true;
            reviewShowAnswer.IsVisible = false;
            webView.IsVisible = true;
            edtAnswer.Text = "";
            Title = QuestionName;
            afterAnswerSubmissionLayout.IsVisible = false;
            afterAnswerSubmissionLayout.Opacity = 0;
            webView.IsVisible = true;
        }

        /// <summary>
        /// This method manages the View solution button click and navigate to the solution page where user can see the solution for the question.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        async void ViewSolution_Clicked(object sender, System.EventArgs e)
        {
            ViewSolutionPage page = new ViewSolutionPage();
            page.title = QuestionName;
            string htmlstr = WebUtility.HtmlDecode(questionDetail.generalfeedback);
            page.solution = htmlstr;
            page.quiz_id = QuestionId;
            page.question_id = questionDetail.id;
            await Navigation.PushModalAsync(page);
        }

        private string getBaseUrlForImages()
        {
            // Eg: https://zimlapp.areteem.org/api/images/question.php?quiz_id=906&question_id=7522&filename=%5B180601%5D.png&filearea=questiontext

            string question_id = questionDetail.id;
            string quiz_id = QuestionId;
            string baseUrl = Constants.baseURL + "/api/images/question.php?quiz_id="+quiz_id+"&question_id="+question_id+"&filearea=questiontext&filename=";
            return baseUrl;
        }

        /// <summary>
        /// Submits the attempt.
        /// </summary>
        public void SubmitAttempt()
        {
            LoaderView.IsVisible = true;
            var param = new SubmitAttemptParam();
            param.quiz_id = QuestionId;
            param.question_id = questionDetail.id;
            param.answer = edtAnswer.Text;
            param.time_taken = getTimeTaken();
            API.GetResponseFromServer(Constants.submitAttemptAPI, param,(content) => {
                SubmitAttemptResponse response = JsonConvert.DeserializeObject<SubmitAttemptResponse>(content.ToString());
                if (!string.IsNullOrEmpty(response.attempt_id))
                {
                    recentAttemptId = response.attempt_id;
                    FinishAttempt(response.attempt_id);
                }
            
            },
            async (message, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");}
                else { await DisplayAlert(null, message, "Ok"); }
            } );
        }

        /// <summary>
        /// Finishs the attempt.
        /// </summary>
        /// <param name="attemptId">Attempt identifier.</param>
        public void FinishAttempt(string attemptId)
        {
            var param = new FinishAttemptParam();
            param.attempt_id = attemptId;
            API.GetResponseFromServer(Constants.finishAttemptAPI, param, (content) => {
                DailyMagicSpellsDetailParam DMSparam = new DailyMagicSpellsDetailParam();
                DMSparam.quiz_id = QuestionId;
                GetDailyMagicSpellsDetail(DMSparam);
            },
            async (message, errorType) => {
                LoaderView.IsVisible = false;
                if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
                else { await DisplayAlert(null, message, "Ok"); }
            });
        }

        private string getTimeTaken()
        {
            DateTime endTime = DateTime.Now;
            var timeDiff = (endTime - startTime).TotalSeconds;
            int timeDiffInt = (int)Convert.ToInt64(timeDiff);
            return timeDiffInt.ToString();
        }

        /// <summary>
        /// This method manages to click on review button. After button click it shows the attempt detail for related item.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void Review_Clicked(object sender, System.EventArgs e)
        {
            var btn = (Button)sender;
            Attempt attempt = questionDetailResponse.attempts.Find(x => x.id == btn.CommandParameter.ToString());
            webView.IsVisible = true;
            recentAttemptLayout.IsVisible = false;
            reviewShowAnswer.IsVisible = true;
            backTxt.IsVisible = true;
            reviewShowAnswer.Text = attempt.submitted_answer;
            int grades = Convert.ToInt32(Convert.ToDecimal(attempt.sumgrades));
            if (grades == 0)
            {
                reviewShowAnswer.BackgroundColor = Color.FromHex("#f2dede");
                reviewShowAnswer.TextColor = Color.Red;
            }
            else
            {
                reviewShowAnswer.BackgroundColor = Color.FromHex("#dff0d8");
                reviewShowAnswer.TextColor = Color.Green;
            }
        }
    }
}

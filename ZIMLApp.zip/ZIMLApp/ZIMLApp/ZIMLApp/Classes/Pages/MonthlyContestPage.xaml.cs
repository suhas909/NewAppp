﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Xamarin.Forms;
using ZIMLApp.Classes.Model;
using ZIMLApp.Classes.Utility;
using System.Linq;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages to show the list of Monthly contest.
    /// </summary>
    public partial class MonthlyContestPage : ContentPage
    {
        //private List<ContestDetail> contestDetails = new List<ContestDetail>();
        private List<ContestDetail> upcomingContestList = new List<ContestDetail>();
        private List<ContestDetail> previousContestList = new List<ContestDetail>();
        private DateTime currentTime = DateTime.Now.ToUniversalTime();

        public MonthlyContestPage()
        {
            InitializeComponent();
            //loaderWebView.Source = CommonClass.GetLoaderWebViewSource();
            NavigationPage.SetBackButtonTitle(this, " ");
            AddToolbarItem();
            Title = "Monthly Contests";
            LoaderView.IsVisible = true;
            GetPreviousContestList();
        }

		protected override void OnAppearing()
		{
            base.OnAppearing();
            NavigationPage navigationPage = (NavigationPage)((HomePage)Application.Current.MainPage).Detail;
            navigationPage.BarTextColor = Color.Black;
            HomePage home = (HomePage)Application.Current.MainPage;
            if (home != null)
            {
                home.IsGestureEnabled = true;
            }
            gridView.Children.Clear();
            GetUpcomingContestList();
		}

		protected override void OnDisappearing()
		{
            base.OnDisappearing();
            if (Application.Current.MainPage is HomePage)
            {
                HomePage home = (HomePage)Application.Current.MainPage;
                if (home != null)
                {
                    home.IsGestureEnabled = false;
                }
            }
		}

		void AddToolbarItem()
        {
            var info = new ToolbarItem
            {
                Icon = "info.png",
                Text = "Summary",
                Priority = 0
            };

            info.Clicked  += async (s, e) => {
                await Navigation.PushAsync(new MonthlyContestInfoPage());
            };
                   
            ToolbarItems.Add(info);
        }

        /// <summary>
        /// Create the UI for upcoming monthly contest list.
        /// </summary>
        public void GetUpcomingMonthlyContestList()
        {
            var parentStackLayout = new StackLayout();
            gridView.ColumnDefinitions.Clear();
            gridView.RowDefinitions.Clear();

            gridView.ColumnDefinitions.Add(new ColumnDefinition());
            gridView.ColumnDefinitions.Add(new ColumnDefinition());

            var numberOfRows = (upcomingContestList.Count / 2) + (upcomingContestList.Count % 2);

            for (int i = 0; i < numberOfRows; i++)
            {
                var rowDef = new RowDefinition();
                rowDef.Height = 84;
                gridView.RowDefinitions.Add(rowDef);
            }

            var productIndex = 0;
            for (int rowIndex = 0; rowIndex < numberOfRows; rowIndex++)
            {
                for (int columnIndex = 0; columnIndex < 2; columnIndex++)
                {
                    if (productIndex >= upcomingContestList.Count)
                    {
                        break;
                    }
                    var product = upcomingContestList[productIndex];


                    var label = new Label
                    {
                        Text = product.display_name != null ? product.display_name.Trim() : "",
                        TextColor = Color.FromHex("#1C4277"),
                        FontAttributes = FontAttributes.Bold,
                        FontSize = 17,
                        VerticalOptions = LayoutOptions.Center,
                        HorizontalOptions = LayoutOptions.Start
                    };


                    var subLabel = new Label
                    {
                        Text = product.name,
                        FontSize = 12,
                        TextColor = Color.Silver,
                        VerticalOptions = LayoutOptions.Center,
                        HorizontalOptions = LayoutOptions.Start
                    };
                    var indexLabel = new Label
                    {
                        Text = "" + productIndex,
                        FontSize = 12,
                        TextColor = Color.Transparent,
                        VerticalOptions = LayoutOptions.Center,
                        HeightRequest = 0,
                        WidthRequest = 0,
                        HorizontalOptions = LayoutOptions.Start
                                                         
                    };
                    //label.SetBinding(Label.TextProperty, product.name);
                    var subStackLayout = new StackLayout();
                    subStackLayout.Orientation = StackOrientation.Vertical;



                    var mainStackLayout = new StackLayout();
                    mainStackLayout.Orientation = StackOrientation.Horizontal;

                    subStackLayout.Children.Add(label);
                    subStackLayout.Children.Add(subLabel);

                    var image = new Image();
                    image.HorizontalOptions = LayoutOptions.EndAndExpand;
                    image.VerticalOptions = LayoutOptions.Center;
                    // image.Margin = new Thickness(50, 0, 0, 0);
                    image.Source = "ic_indicator_right.png";


                    mainStackLayout.Children.Add(subStackLayout);
                    mainStackLayout.Children.Add(indexLabel);
                    mainStackLayout.Children.Add(image);

                    var frame = new Frame();
                    frame.CornerRadius = 10;
                    frame.HasShadow = false;
                    frame.BorderColor = Color.FromHex("#D9D9D9"); //Color.Silver;
                    frame.Padding = 8;
                    frame.Content = mainStackLayout;

                    var tapGestureRecognizer = new TapGestureRecognizer();
                    tapGestureRecognizer.Tapped += async (s, e) => {
                        if (!Preference.IsUserLoggedIn)
                        {
                            await DisplayAlert(null, "Please sign in to attempt monthly contest.", "Ok");
                            Application.Current.MainPage = new NavigationPage(new SplashScreenPage());
                        }
                        else
                        {
                            int index = Convert.ToInt32(indexLabel.Text);
                            var contestdetail = upcomingContestList[index];
                            if (contestdetail.is_enrolled == true)
                            {
                                //GetQuizDeatil(contestdetail);
                                var page = new MonthlyContestDetailPage();
                                page.contestDetail = contestdetail;
                                await Navigation.PushAsync(page);
                            }
                            else
                            {
                                if (CheckForContestOpen(contestdetail.timeclose) == true)
                                {
                                    var page = new MonthlyContestDetailPage();
                                    page.contestDetail = contestdetail;
                                    await Navigation.PushAsync(page); 
                                }
                                else
                                {
                                    await DisplayAlert(null, "Enrollment is closed for this contest.", "Ok");
                                }

                            }

                        }

                    };
                    frame.GestureRecognizers.Add(tapGestureRecognizer);

                    tapGestureRecognizer.NumberOfTapsRequired = 1;

                    gridView.Children.Add(frame, columnIndex, rowIndex);

                    productIndex += 1;
                }
            }
        }
        /// <summary>
        /// This method manages the click event for Previouse contest cell.
        /// </summary>
        /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        async void PreviousContestCellTapped(object sender, System.EventArgs e)
        {
            var contestdetail = (ContestDetail)previousContestListView.SelectedItem;

            if (contestdetail.is_enrolled == true)
            {
                //GetQuizDeatil(contestdetail);
                var page = new MonthlyContestDetailPage();
                page.contestDetail = contestdetail;
                await Navigation.PushAsync(page);
            }
            else
            {
                await DisplayAlert(null, "Enrollment is closed for this contest.", "Ok");
            }
        }

        /// <summary>         /// This method manages the Try again button clicked, and try to reload the data.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        void TryAgain_Clicked(object sender, System.EventArgs e)
        {
            LoaderView.IsVisible = true;
            ErrorView.IsVisible = false;
            GetPreviousContestList();
            GetUpcomingContestList();
        }


        /// <summary>
        /// Gets the previous contest list from the API.
        /// </summary>
        public void GetPreviousContestList()
        {
            LoaderView.IsVisible = true;

            API.GetResponseFromServer(Constants.monthlyContestListAPI, new MonthlyContestListParam(){is_archived = "yes"}, (content) =>
            {
                MonthlyContestListResponse response = JsonConvert.DeserializeObject<MonthlyContestListResponse>(content.ToString());
                previousContestList = response.contests;
                LoaderView.IsVisible = false;
                if (previousContestList != null)
                {
                    previousContestListView.ItemsSource = previousContestList;
                    previousContestListView.HeightRequest = previousContestList.Count * previousContestListView.RowHeight;
                }
            },  (message, errorType) => {
                LoaderView.IsVisible = false;
                ErrorView.IsVisible = true;
                if (errorType == ErrorType.Network)
                {
                    ErrorTitle.Text = Constants.NetworkErrorTitle;
                    ErrorMessage.Text = Constants.NetworkErrorMessage;
                    ActionButton.Text = "Try again";
                }
                else
                {
                    ErrorTitle.Text = Constants.ServerErrorTitle;
                    ErrorMessage.Text = Constants.ServerErrorMessage;
                    ActionButton.Text = "Refresh";
                }

            });
        }
        /// <summary>
        /// Gets the upcoming contest list from the API.
        /// </summary>
        public void GetUpcomingContestList()
        {
            LoaderView.IsVisible = true;

            API.GetResponseFromServer(Constants.monthlyContestListAPI, new MonthlyContestListParam(), (content) =>
            {
                MonthlyContestListResponse response  = JsonConvert.DeserializeObject<MonthlyContestListResponse>(content.ToString());
                upcomingContestList = response.contests;
                currentTime = CommonClass.FromUnixTime(response.current_timestamp);
                LoaderView.IsVisible = false;
                if (upcomingContestList != null)
                {
                    GetUpcomingMonthlyContestList();
                }
            }, (message, errorType) => {
                LoaderView.IsVisible = false;
                ErrorView.IsVisible = true;
                if (errorType == ErrorType.Network)
                {
                    ErrorTitle.Text = Constants.NetworkErrorTitle;
                    ErrorMessage.Text = Constants.NetworkErrorMessage;
                    ActionButton.Text = "Try again";
                }
                else
                {
                    ErrorTitle.Text = Constants.ServerErrorTitle;
                    ErrorMessage.Text = Constants.ServerErrorMessage;
                    ActionButton.Text = "Refresh";
                }

            });
        }

        //public void GetQuizDeatil(ContestDetail contestDetail)
        //{
        //    LoaderView.IsVisible = true;
        //    MonthlyContestDetailParam param = new MonthlyContestDetailParam();
        //    param.quiz_id = contestDetail.quiz_id;
        //    param.start_attempt = "no";

        //    API.GetResponseFromServer(Constants.monthlyContestDetailAPI, param, async (content) => {
        //        MonthlyContestDetailResponse detail = JsonConvert.DeserializeObject<MonthlyContestDetailResponse>(content.ToString());
        //        LoaderView.IsVisible = false;
        //        if (detail != null)
        //        {
        //             var quizStatus = QuizStatus.Not_Started;
        //             Attempts attempt;
        //            bool isAttemptOver = false;
        //            if (detail.attempts != null && detail.attempts.Count > 0)
        //            {
        //                attempt = detail.attempts[0];
        //                if (attempt.timefinish == "0")
        //                {
        //                    quizStatus = QuizStatus.On_Going;
        //                    isAttemptOver = CheckAttemptTimeOver(attempt.timestart, contestDetail.getTotalMinutes());
        //                    if (isAttemptOver == true)
        //                    {
        //                        FinishAttempt(attempt.id, contestDetail);
        //                    }
        //                }
        //                else
        //                {
        //                    quizStatus = QuizStatus.Result_Open;
        //                }
        //            }
        //            if (isAttemptOver == true)
        //            {
        //                return;
        //            }
        //            else if (quizStatus == QuizStatus.Not_Started || quizStatus == QuizStatus.On_Going)
        //            {
        //                var introPage = new MonthlyContestIntroductionPage();
        //                introPage.quizStatus = quizStatus;
        //                introPage.contestDetail = contestDetail;
        //                introPage.detailResponse = detail;
        //                await Navigation.PushModalAsync(introPage);
        //            }
        //            else
        //            {
        //                var resultPage = new MonthlyContestResultPage();
        //                resultPage.quizStatus = quizStatus;
        //                //resultPage.Title = this.Title;
        //                resultPage.contestDetail = contestDetail;
        //                resultPage.detailResponse = detail;
        //                await Navigation.PushAsync(resultPage);
        //            }
        //        }
        //    }, (message, errorType) => {
        //        LoaderView.IsVisible = false;
        //        ErrorView.IsVisible = true;
        //        if (errorType == ErrorType.Network)
        //        {
        //            ErrorTitle.Text = Constants.NetworkErrorTitle;
        //            ErrorMessage.Text = Constants.NetworkErrorMessage;
        //            ActionButton.Text = "Try again";
        //        }
        //        else
        //        {
        //            ErrorTitle.Text = Constants.ServerErrorTitle;
        //            ErrorMessage.Text = Constants.ServerErrorMessage;
        //            ActionButton.Text = "Refresh";
        //        }

        //    });
        //}

        bool CheckForContestOpen(string timeclose)
        {
            DateTime closeTime = CommonClass.FromUnixTime(Convert.ToInt64(timeclose));
            //DateTime currentTime = DateTime.Now.ToUniversalTime();
            var diff = closeTime.Subtract(currentTime).TotalMinutes;
            if (diff < 0)
            {
                return false;
            }
            return true;
        }

        //bool CheckAttemptTimeOver(string timestart, int totalMinutes)
        //{
        //    DateTime startTime = CommonClass.FromUnixTime(Convert.ToInt64(timestart));
        //    //DateTime currentTime = DateTime.Now.ToUniversalTime();
        //    var diff = currentTime.Subtract(startTime).TotalMinutes;
        //    int remainingTime = (int)Convert.ToInt64(totalMinutes - diff);
        //    if (remainingTime < 0)
        //    {
        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}

        //public void FinishAttempt(string attemptId, ContestDetail contestDetail)
        //{
        //    var param = new FinishAttemptParam();
        //    param.attempt_id = attemptId;
        //    LoaderView.IsVisible = true;
        //    API.GetResponseFromServer(Constants.monthlyContestFinishAttemptAPI, param, (content) => {
        //        GetQuizDeatil(contestDetail);
        //    },
        //    async (message, errorType) => {
        //        LoaderView.IsVisible = false;
        //        if (errorType == ErrorType.Network) { await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok"); }
        //        else { await DisplayAlert(null, message, "Ok"); }
        //    });
        //}

    }
}

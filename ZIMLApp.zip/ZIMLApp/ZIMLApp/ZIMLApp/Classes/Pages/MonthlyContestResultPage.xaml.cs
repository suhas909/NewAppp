﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Model;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages to show the contest result page if the contest was attempted
    /// </summary>
    public partial class MonthlyContestResultPage : ContentPage
    {
        public QuizStatus quizStatus = QuizStatus.Not_Started;
        public ContestDetail contestDetail;
        public MonthlyContestDetailResponse detailResponse;

        //public string time = "1 hour";
        //public string date = "Sunday, 3 June 2018, 11:59 PM";


        public MonthlyContestResultPage()
        {
            InitializeComponent();
            if (Device.RuntimePlatform == Device.iOS) { Padding = new Thickness(0, 20, 0, 0); }
        }


        protected override void OnAppearing()
        {
            base.OnAppearing();
            var attempt = detailResponse.attempts[0];
            string html = "The competition has 20 questions and lasts " + contestDetail.getTime() + ". The answer to each question is a number.For example, \"20\", \" - 5\", \"3.14\" are all valid answers while \"20 mph\", \"5 / 2\" are not valid.";
            html = html + "\n\nNote: Once you start the competition you have one hour to complete the test.Please plan your time so you can finish the competition in a single session.";
            html = html + "\n\nAttempts allowed: 1";
            var timeopen = contestDetail.getStartDateFull();
            if (!string.IsNullOrEmpty(timeopen)) { html = html + "\n\nThis quiz opened at " + timeopen + ", 12:01 AM"; }

            FormattedString formattedhtml = new FormattedString();
            formattedhtml.Spans.Add(new Span { Text = html });
            var timeclose = contestDetail.getEndDateFull();
            if (!string.IsNullOrEmpty(timeclose)) { formattedhtml.Spans.Add(new Span { Text = "\n\nThis quiz will close at " + timeclose + ", 11:59 PM", FontAttributes = FontAttributes.None }); }
            formattedhtml.Spans.Add(new Span { Text = "\n\nTime limit: " + contestDetail.getTime() });

            introText.FormattedText = formattedhtml;
            Title = contestDetail.quiz_name;

            if (detailResponse.shouldShowAnswer == true) quizStatus = QuizStatus.Result_Open;
            else quizStatus = QuizStatus.Result_Pending;

            if (quizStatus == QuizStatus.Result_Open) actionBtn.Text = "Review";
            if (quizStatus == QuizStatus.Result_Pending)
            {   
                actionBtn.Text = "Pending";
                attemptDetail.IsVisible = false;
                actionBtn.BackgroundColor = Color.FromHex("#cccccc");
                actionBtn.TextColor = Color.FromHex("#4A4A4A");
                actionBtn.IsEnabled = false;
            }
            else if (attempt != null)
            {
                attemptDetail.IsVisible = true;
                TxtDate.Text = attempt.getDate();
                TxtGrade.Text = attempt.getGrade();
                var timeTaken = attempt.getTimeTaken(); 
                if (timeTaken > contestDetail.getTotalMinutes())
                {
                    TxtTimeTaken.Text = contestDetail.getTotalMinutes() + " mins";
                }
                else
                {
                    TxtTimeTaken.Text = timeTaken + " mins";
                }
            }
        }


        /// <summary>         /// This method manages the Review button click. On click it navigate to the contest result summary page.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        async void ReviewClicked(object sender, System.EventArgs e)
        {
            if (quizStatus == QuizStatus.Result_Open)
            {
                var page = new MonthlyContestResultSummaryPage();
                page.contestDetail = contestDetail;
                page.detailResponse = detailResponse;
                await Navigation.PushModalAsync(page);
            }
        }
    }
}

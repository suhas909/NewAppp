﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class used to show Monthly contest info page.
    /// </summary>
    public partial class MonthlyContestInfoPage : ContentPage
    {
        public MonthlyContestInfoPage()
        {
            InitializeComponent();
        }
    }
}

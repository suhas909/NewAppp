﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using System.IO;

namespace ZIMLApp.Classes.Pages
{
    public partial class ImageCropPage : ContentPage
    {
        public event EventHandler<DoneCroppingEventArgs> DoneCropping;

        public ImageSource ImageSourceForCrop;

        public ImageCropPage()
        {
            InitializeComponent();
            cropView.HeightRequest = Application.Current.MainPage.Width;
            cropView.WidthRequest = Application.Current.MainPage.Width;

            AddToolbarItem();
        }

        void AddToolbarItem()
        {
            var doneBtn = new ToolbarItem
            {
                Text = "Done",
                Priority = 0
            };

            doneBtn.Clicked += async (s, e) => {
                
                EventHandler<DoneCroppingEventArgs> handler = DoneCropping;
                if (handler != null)
                {
                    var result = await cropView.GetImageAsJpegAsync();

                    DoneCroppingEventArgs eventArgs = new DoneCroppingEventArgs(){stream = result};
                    handler(this, eventArgs);
                }
                await Navigation.PopAsync();
            };

            ToolbarItems.Add(doneBtn);
        }

		protected override void OnAppearing()
		{
            base.OnAppearing();

            cropView.Source = ImageSourceForCrop;
		}

	}

    public class DoneCroppingEventArgs : EventArgs
    {
        public Stream stream;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Xamarin.Forms;
using ZIMLApp.Classes.Utility;

namespace ZIMLApp.Classes.Pages
{

    /// <summary>
    /// This class manages to show the solution page for the question.
    /// </summary>
    public partial class ViewSolutionPage : ContentPage
    {
        public string solution = "";
        public string title = "";
        public string question_id = "";
        public string quiz_id = "";

        public ViewSolutionPage()
        {
            InitializeComponent();
            if (Device.RuntimePlatform == Device.iOS) { Padding = new Thickness(0, 20, 0, 0); }
            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += async (s, e) => {
                await this.Navigation.PopModalAsync();
            };
            closeImg.GestureRecognizers.Add(tapGestureRecognizer);
            tapGestureRecognizer.NumberOfTapsRequired = 1;
        }

		protected override void OnAppearing()
		{
            base.OnAppearing();
            titleLb.Text = title;
            setDataOnView();
		}

		public void setDataOnView()
        {
            if (solution == null) return;

            string baseurl = getBaseUrlForSolutionImages();
            solution = solution.Replace("@@PLUGINFILE@@/", baseurl);

            string htmlData = CommonClass.getHTMLContent(solution);

            Debug.WriteLine(htmlData);
            var url = new HtmlWebViewSource
            {
                Html = htmlData
            };
            webView.Source = url;
        }

        private string getBaseUrlForSolutionImages()
        {
            // Eg:  https://zimlapp.areteem.org/api/images/question.php?quiz_id=906&question_id=7522&filename=%5B180601%5DSoln.png&filearea=generalfeedback

            string baseUrl = Constants.baseURL + "/api/images/question.php?quiz_id=" + quiz_id + "&question_id=" + question_id + "&filearea=generalfeedback&filename=";
            return baseUrl;
        }
    }
}

﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Utility;
using ZIMLApp.Classes.Model;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Linq;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages the varification of OTP.
    /// </summary>
    public partial class VerifyOTPPage : ContentPage
    {
        public string emailId = "";
        public string oauthId;
        public string registrationToken;
        public string picture_url;
        public bool isFromCreateAccount = true;
        public string password = "";
        public string firstName = "";
        public string lastName = "";
        private RequestOTPDetail requestedOTPDetail;
        private bool isloadingFirstTime = true;
       

        public VerifyOTPPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            initView();
            LoaderView.IsVisible = true;

        }

        public void initView()
        {
            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += (s, e) => {
                this.Navigation.PopModalAsync();
            };
            imgBack.GestureRecognizers.Add(tapGestureRecognizer);
            tapGestureRecognizer.NumberOfTapsRequired = 1;

            var resendOTPGR = new TapGestureRecognizer();
            resendOTPGR.Tapped += (s, e) => {
                edtOTP.Text = "";
                RequestOTP();
            };
            txtResendCode.GestureRecognizers.Add(resendOTPGR);
            resendOTPGR.NumberOfTapsRequired = 1;

            //loaderWebView.Source = CommonClass.GetLoaderWebViewSource();
        }

		protected override void OnAppearing()
		{
            base.OnAppearing();
            txtEmail.Text = emailId;
            edtOTP.Text = "";
            Debug.WriteLine(emailId);
            if (isloadingFirstTime)
            {
                RequestOTP();
                isloadingFirstTime = false;
            }
            else
            {
                LoaderView.IsVisible = false;
            }
		}

        /// <summary>
        /// This method call the API to request the OTP.
        /// </summary>
		public void RequestOTP()
        {
            LoaderView.IsVisible = true;
            if (isFromCreateAccount)
            {
                API.GetResponseFromServer(Constants.requestOTPAPI, new RequestOTPParam(emailId, false), HandleSuccessForRequestOTP, HandleFailureForRequestOTP);
            }
            else
            {
                API.GetResponseFromServer(Constants.requestOTPAPI, new RequestOTPParam(emailId, true), HandleSuccessForRequestOTP, HandleFailureForRequestOTP);
            }

        }
        /// <summary>
        /// Handles the success for request otp.
        /// </summary>
        /// <param name="contents">Contents object return from the API call.</param>
        void HandleSuccessForRequestOTP(object contents)
        {
            requestedOTPDetail = JsonConvert.DeserializeObject<RequestOTPDetail>(contents.ToString());
            Debug.WriteLine(requestedOTPDetail.otp_id);
            LoaderView.IsVisible = false;
        }
        /// <summary>
        /// Handles the failure for request otp.
        /// </summary>
        /// <param name="message">Message related to the failure.</param>         /// <param name="errorType">Error type.</param>
        async void HandleFailureForRequestOTP(string message, ErrorType errorType)
        {
            LoaderView.IsVisible = false;
            if (errorType == ErrorType.Network)
            {
                await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
            }
            else
            {
                await DisplayAlert(null, message, "Ok");
            }
            await this.Navigation.PopModalAsync();
        }

        /// <summary>         /// This method manages the verify OTP button click.         /// </summary>         /// <param name="sender">Button object.</param>         /// <param name="e">Event arguments.</param>
        public void VerifyOTP_Clicked(object sender, System.EventArgs e)
        {
            if (CheckValidations())
            {
                ValidateOTPParam param = new ValidateOTPParam();
                param.email_id = emailId;
                param.otp = edtOTP.Text;
                param.otp_id = requestedOTPDetail.otp_id;
                VerifyOTPFromServer(param);
            }
        }

        /// <summary>
        /// Verifies the OTP from server.
        /// </summary>
        /// <param name="param">Validate OTP API Parameter.</param>
        public void VerifyOTPFromServer(ValidateOTPParam param)
        {
            LoaderView.IsVisible = true;
            API.GetResponseFromServer(Constants.validateOTPAPI, param, HandleSuccessForVerifyOTPAsync, HandleFailureForVerifyOTP);
        }

        /// <summary>
        /// Handles the success for verify OTPA sync.
        /// </summary>
        /// <param name="contents">Contents object return from the API call.</param>
        async void HandleSuccessForVerifyOTPAsync(object contents)
        {
            ValidateOTPDetail detail = JsonConvert.DeserializeObject<ValidateOTPDetail>(contents.ToString());
            Debug.WriteLine(detail.otp_successful_validation_token);
            //LoaderView.IsVisible = false;
            if (isFromCreateAccount)
            {
                CreateAccountParam param = new CreateAccountParam();
                param.email_id = emailId;
                param.password = password;
                param.otp_successful_validation_token = detail.otp_successful_validation_token;
                param.first_name = firstName;
                param.last_name = lastName;
                if(registrationToken != null)
                {
                    param.oauth_id = oauthId;
                    param.oauth_registration_token = registrationToken;
                }
                CreateUsersAccount(param); 
            }
            else
            {
                ResetPasswordPage resetPasswordPage = new ResetPasswordPage();
                resetPasswordPage.EmailId = emailId;
                resetPasswordPage.otp_successful_validation_token = detail.otp_successful_validation_token;
                await Navigation.PushModalAsync(resetPasswordPage);
            }
        }

        /// <summary>
        /// Handles the failure for verify otp.
        /// </summary>
        /// <param name="message">Message related to the failure.</param>         /// <param name="errorType">Error type.</param>
        async void HandleFailureForVerifyOTP(string message, ErrorType errorType)
        {
            LoaderView.IsVisible = false;
            if (errorType == ErrorType.Network)
            {
                await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
            }
            else
            {
                await DisplayAlert(null, message, "Ok");
            }
        }

        /// <summary>
        /// This method calls the Creates users account API.
        /// </summary>
        /// <param name="param">Parameter.</param>
        public void CreateUsersAccount(CreateAccountParam param)
        {
            //LoaderView.IsVisible = true;
            API.GetResponseFromServer(Constants.createAccountAPI, param, HandleSuccess, HandleFailure);
        }
        /// <summary>
        /// Handles success for create accout API call.
        /// </summary>
        /// <param name="contents">Contents.</param>
        void HandleSuccess(object contents)
        {
            CreateAccountDetail createAccountDetail = JsonConvert.DeserializeObject<CreateAccountDetail>(contents.ToString());
            Debug.WriteLine(createAccountDetail.access_token);
            SaveUserDataToPreference(createAccountDetail);
            if (!string.IsNullOrEmpty(picture_url)) Preference.UploadProfileUrl = picture_url;
            LoaderView.IsVisible = false;
            Preference.IsLoginWithEmail = true;
            Preference.EmailId = emailId;
            if (!string.IsNullOrEmpty(Preference.PushId))
            {
                ValidateDeviceId();
            }
            else
            {
                Application.Current.MainPage = new HomePage();
            }
        }

        /// <summary>         /// Handles the failure for the API call         /// </summary>         /// <param name="message">Message related to the failure.</param>         /// <param name="errorType">Error type.</param>
        async void HandleFailure(string message, ErrorType errorType)
        {
            LoaderView.IsVisible = false;
            if (errorType == ErrorType.Network)
            {
                await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
            }
            else
            {
                await DisplayAlert(null, message, "Ok");
            }
        }

        /// <summary>
        /// Saves the user data to preference.
        /// </summary>
        /// <param name="createAccountDetail">Create account detail.</param>
        public void SaveUserDataToPreference(CreateAccountDetail createAccountDetail)
        {
            Preference.IsUserLoggedIn = true;
            Preference.FirstName = firstName;
            Preference.LastName = lastName;
            Preference.DeviceId = createAccountDetail.device_id;
            Preference.AccessToken = createAccountDetail.access_token;
        }

        /// <summary>
        /// Checks the validations.
        /// </summary>
        /// <returns><c>true</c>, if validations was checked, <c>false</c> otherwise.</returns>
        private bool CheckValidations()
        {
            bool returnValue = true;

            if (string.IsNullOrEmpty(edtOTP.Text))
            {
                otpErrorLb.Text = "Please enter 4 digit OTP";
                returnValue = false;
            }
            else
            {
                otpErrorLb.Text = "";
            }

            return returnValue;
        }

        /// <summary>
        /// Validates the device identifier and Update the push id for the user on server
        /// </summary>
        public void ValidateDeviceId()
        {
            LoaderView.IsVisible = true;
            var param = new ValidateDeviceParams();
            Debug.WriteLine("-----------\n" + param.access_auth_key + "\n" + param.access_device_id + "\n" + param.push_id);
            API.GetResponseFromServer(Constants.validateDeviceAPI, param, HandleSuccessForValidateDeviceId, HandleFailureForValidateDeviceId);
        }

        /// <summary>
        /// Handles the success for validate device identifier.
        /// </summary>
        /// <param name="contents">Contents.</param>
        void HandleSuccessForValidateDeviceId(object contents)
        {
            LoaderView.IsVisible = false;
            Application.Current.MainPage = new HomePage();
        }

        /// <summary>
        /// Handles the failure for validate device identifier.
        /// </summary>
        /// <param name="message">Error Message.</param>
        /// <param name="errorType">Error type.</param>
        async void HandleFailureForValidateDeviceId(string message, ErrorType errorType)
        {
            LoaderView.IsVisible = false;
            if (errorType == ErrorType.Network)
            {
                await DisplayAlert(Constants.NetworkErrorTitle, Constants.NetworkErrorMessage, "Ok");
            }
            else
            {
                await DisplayAlert(null, message, "Ok");
            }
        }


    }
}

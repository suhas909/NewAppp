﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using ZIMLApp.Classes.Utility;
using ZIMLApp.Classes.Model;
using Newtonsoft.Json;

namespace ZIMLApp.Classes.Pages
{
    /// <summary>
    /// This class manages Contact us detail page.
    /// </summary>
    public partial class ContactUsDetailPage : ContentPage
    {
        public ContactUsDetailPage()
        {
            InitializeComponent();
            LoaderView.IsVisible = true;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            NavigationPage navigationPage = (NavigationPage)((HomePage)Application.Current.MainPage).Detail;
            navigationPage.BarTextColor = Color.Black;
            HomePage home = (HomePage)Application.Current.MainPage;
            if (home != null)
            {
                home.IsGestureEnabled = true;
            }
            GetContactDetail();
        }

        protected override void OnDisappearing()
        {
            if (Application.Current.MainPage is HomePage)
            {
                base.OnDisappearing();
                HomePage home = (HomePage)Application.Current.MainPage;
                if (home != null)
                {
                    home.IsGestureEnabled = false;
                }
            }

        }

        public void initView()
        {
            var TelephoneTapGR = new TapGestureRecognizer();
            TelephoneTapGR.Tapped += (s, e) => {
                Device.OpenUri(new Uri(String.Format("tel:{0}", "+49000000")));
            };
            TelephoneLb.GestureRecognizers.Add(TelephoneTapGR);
            TelephoneTapGR.NumberOfTapsRequired = 1;
           
        }
        /// <summary>
        /// This method manages the Try again button clicked, And try to reload the data.
        /// </summary>
        /// <param name="sender">Button object.</param>
        /// <param name="e">Event arguments.</param>
        void TryAgain_Clicked(object sender, System.EventArgs e)
        {
            LoaderView.IsVisible = true;
            ErrorView.IsVisible = false;
            GetContactDetail();
        }
        /// <summary>
        /// This method manages the contact detail API call.
        /// </summary>
        void GetContactDetail()
        {
            LoaderView.IsVisible = true;

            API.GetResponseFromServer(Constants.contactUsDetailAPI, new RequestParam(), (content) =>
            {
                ContactDetail detail = JsonConvert.DeserializeObject<ContactDetail>(content.ToString());
                LoaderView.IsVisible = false;
                addressLb.Text = detail.address;
                TelephoneLb.Text = detail.telephone;
                EmailLb.Text = detail.email;
                WebsiteLb.Text = detail.website;
                WeChatLb.Text = detail.wechat;

                var TelephoneTapGR = new TapGestureRecognizer();
                TelephoneTapGR.Tapped += (s, e) => {
                    Device.OpenUri(new Uri(String.Format("tel:{0}", "+" + detail.telephone)));
                };
                TelephoneLb.GestureRecognizers.Add(TelephoneTapGR);
                TelephoneTapGR.NumberOfTapsRequired = 1;

                var EmailTapGR = new TapGestureRecognizer();
                EmailTapGR.Tapped += (s, e) => {
                    Device.OpenUri(new Uri(String.Format("mailto:{0}", detail.email)));
                };
                EmailLb.GestureRecognizers.Add(EmailTapGR);
                EmailTapGR.NumberOfTapsRequired = 1;

                var WebsiteTapGR = new TapGestureRecognizer();
                WebsiteTapGR.Tapped += (s, e) => {
                    Device.OpenUri(new Uri("http://" + detail.website));
                };
                WebsiteLb.GestureRecognizers.Add(WebsiteTapGR);
                WebsiteTapGR.NumberOfTapsRequired = 1;

            }, (message, errorType) =>
            {
                LoaderView.IsVisible = false;
                ErrorView.IsVisible = true;
                if (errorType == ErrorType.Network)
                {
                    ErrorTitle.Text = Constants.NetworkErrorTitle;
                    ErrorMessage.Text = Constants.NetworkErrorMessage;
                    ActionButton.Text = "Try again";
                }
                else
                {
                    ErrorTitle.Text = Constants.ServerErrorTitle;
                    ErrorMessage.Text = Constants.ServerErrorMessage;
                    ActionButton.Text = "Refresh";
                }
            });
        }
    }
}

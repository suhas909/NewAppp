﻿using System;
namespace ZIMLApp
{
    public interface IShare
    {
        void Share(string subject, string message);
    }
}

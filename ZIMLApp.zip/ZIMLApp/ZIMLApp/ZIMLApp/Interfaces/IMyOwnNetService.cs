﻿using System;
using System.Net.Http;

namespace ZIMLApp.Interfaces
{
	public interface IMyOwnNetService
	{
        HttpClientHandler GetHttpClientHandler();
    }
}


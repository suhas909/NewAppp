﻿using Plugin.FirebasePushNotification;
using Xamarin.Forms;
using ZIMLApp.Classes.Pages;
using ZIMLApp.Classes.Utility;
using System.Diagnostics;
using ZIMLApp.Classes.Model;


namespace ZIMLApp
{
    /// <summary>
    /// The Application class for app. 
    /// This class works as an application delegate in iOS or the main application class in android.
    /// This class manages the Application life cycle. 
    /// </summary> 

    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            if (Preference.IsUserLoggedIn)
            {
                MainPage = new HomePage();
            }
            else
            {
                if (Preference.IsProductWalkthroughDone)
                {
                    MainPage = new NavigationPage(new SplashScreenPage()); 
                }
                else
                {
                    MainPage = new NavigationPage(new ProductWalkthroughPage());
                }

            }


            CrossFirebasePushNotification.Current.OnTokenRefresh += (s, p) =>
            {
                System.Diagnostics.Debug.WriteLine($"TOKEN : {p.Token}");
                Preference.PushId = p.Token;
                if (Preference.IsUserLoggedIn)
                {
                    if (!string.IsNullOrEmpty(Preference.PushId))
                    {
                        ValidateDeviceId();
                    }
                }

            };

            CrossFirebasePushNotification.Current.OnNotificationReceived += (s, p) =>
            {

                System.Diagnostics.Debug.WriteLine("Received");

            };

            //CrossFirebasePushNotification.Current.OnNotificationOpened += (s, p) =>
            //{
            //    System.Diagnostics.Debug.WriteLine("Opened");
            //    //MainPage = new HomePage();
            //    foreach (var data in p.Data)
            //    {
            //        System.Diagnostics.Debug.WriteLine($"{data.Key} : {data.Value}");
            //    }

            //    if (!string.IsNullOrEmpty(p.Identifier))
            //    {
            //        System.Diagnostics.Debug.WriteLine($"ActionId: {p.Identifier}");
            //    }

            //};

            CrossFirebasePushNotification.Current.OnNotificationOpened += (s, p) =>
            {
                if (p != null && p.Data.ContainsKey("quiz_id"))
                {
                    //var QuestionName = "";
                    //QuestionName = (string)p.Data["quiz_title"];
                    //Debug.WriteLine(p.Data.ToString());

                    //var QuestionId = (string)p.Data["quiz_id"];
                    //Debug.WriteLine("questionPage " + QuestionName + "\n" + QuestionId);
                    //var home = new HomePage(); //new HomePage(true, QuestionName, QuestionId);

                    //MainPage = home; //new NavigationPage(questionPage);

                    System.Diagnostics.Debug.WriteLine("Opened");
                    foreach (var data in p.Data)
                    {
                        System.Diagnostics.Debug.WriteLine($"{data.Key} : {data.Value}");

                    }

                    if (!string.IsNullOrEmpty(p.Identifier))
                    {
                        System.Diagnostics.Debug.WriteLine($"ActionId: {p.Identifier}");
                    }   
                }
            };

            CrossFirebasePushNotification.Current.OnNotificationError += (source, e) => {
                System.Diagnostics.Debug.WriteLine("OnNotificationError =>" + e.Message);
                if (e.Type == FirebasePushNotificationErrorType.PermissionDenied || e.Type ==FirebasePushNotificationErrorType.RegistrationFailed)
                {
                    Preference.IsNotificationAllowed = false;
                }
            };


        }



        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }

        private void updatePushId()
        {
            
        }

        /// <summary>
        /// Validates the device identifier.
        /// </summary>
        public void ValidateDeviceId()
        {
            var param = new ValidateDeviceParams();
            Debug.WriteLine("-----------\n" + param.access_auth_key + "\n" + param.access_device_id + "\n" + param.push_id);
            API.GetResponseFromServer(Constants.validateDeviceAPI, param, HandleSuccessForValidateDeviceId, HandleFailureForValidateDeviceId);
        }

        /// <summary>
        /// Handles the success for validate device identifier.
        /// </summary>
        /// <param name="contents">Contents.</param>
        void HandleSuccessForValidateDeviceId(object contents)
        {
            Debug.WriteLine("Success " + contents);
        }

        /// <summary>
        /// Handles the failure for validate device identifier.
        /// </summary>
        /// <param name="message">Message.</param>
        /// <param name="errorType">Error type.</param>
        void HandleFailureForValidateDeviceId(string message, ErrorType errorType)
        {
            Debug.WriteLine(message);

        }
    }


}

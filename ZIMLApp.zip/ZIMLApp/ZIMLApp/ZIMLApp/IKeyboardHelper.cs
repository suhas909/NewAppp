﻿using System;
namespace ZIMLApp
{
    public interface IKeyboardHelper
    {
        void HideKeyboard();
    }
}

﻿using System;
using Android.App;
using Android.Content;
using Plugin.CurrentActivity;
using Xamarin.Forms;
using ZIMLApp.Droid;

[assembly: Dependency(typeof(ShareClass))]
namespace ZIMLApp.Droid
{
    public class ShareClass : Activity, IShare
    {

        public void Share(string subject, string message)
        {

            Intent intent = new Intent(Intent.ActionSend);
            //intent.PutExtra(Intent.ExtraSubject, subject);
            intent.SetType("text/plain");
            intent.PutExtra(Intent.ExtraText, message);
            intent.PutExtra(Intent.ExtraSubject, subject);
            // intent.PutExtra(Intent.ExtraStream,message);
            intent.PutExtra(Intent.ExtraTitle, "extra title");
            intent.PutExtra(Intent.ExtraHtmlText, "<p>html text</p>");


            //ImageLoaderSourceHandler handler = new
            //ImageLoaderSourceHandler();
            //Bitmap bitmap = await handler.LoadImageAsync(imageSource, this);

            //using (Java.IO.File path = Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryDownloads + Java.IO.File.Separator + "logo.png"))
            //{
            //    using (System.IO.FileStream os = new System.IO.FileStream(path.AbsolutePath, System.IO.FileMode.Create))
            //    {
            //        bitmap.Compress(Bitmap.CompressFormat.Png, 100, os);
            //    }

            //    intent.PutExtra(Intent.ExtraStream, Android.Net.Uri.FromFile(path));
            //}

            CrossCurrentActivity.Current.Activity.StartActivity(Intent.CreateChooser(intent, "Share Image"));
        }

    }
}

﻿using System;
using System.Net.Http;
using Xamarin.Forms;

using ZIMLApp.Droid.DependencyServices;
using ZIMLApp.Interfaces;

[assembly: Dependency(typeof(MyOwnNetService))]
namespace ZIMLApp.Droid.DependencyServices
{
    public class MyOwnNetService : IMyOwnNetService
    {
        public HttpClientHandler GetHttpClientHandler()
        {
            return new Xamarin.Android.Net.AndroidClientHandler();
        }
    }
}


﻿using System;

using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android;
using Android.Util;
using Android.Support.V4.App;
using Plugin.FirebasePushNotification;
using Xamarin.Forms.PlatformConfiguration.AndroidSpecific;
using Xamarin.Forms.Platform.Android;
using Plugin.FacebookClient;
using Xamarin.Auth.Presenters.XamarinAndroid;
using Plugin.CurrentActivity;
using Lottie.Forms.Platforms.Android;
using Plugin.InAppBilling;

namespace ZIMLApp.Droid
{
    [Activity(Label = "ZIML", Icon = "@drawable/ic_launcher", Theme = "@style/ZimlTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation, ScreenOrientation = ScreenOrientation.Portrait)]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
    {
        protected override void OnCreate(Bundle bundle)
        {
            TabLayoutResource = Resource.Layout.Tabbar;
            ToolbarResource = Resource.Layout.Toolbar;

            base.OnCreate(bundle);
           
            FacebookClientManager.Initialize(this);
            global::Xamarin.Forms.Forms.Init(this, bundle);

            AuthenticationConfiguration.Init(this, bundle);
            CrossCurrentActivity.Current.Init(this, bundle);

            LoadApplication(new App());
            FirebasePushNotificationManager.ProcessIntent(this, Intent);

            Xamarin.Forms.Application.Current.On<Xamarin.Forms.PlatformConfiguration.Android>().UseWindowSoftInputModeAdjust(WindowSoftInputModeAdjust.Resize);
            if (Build.VERSION.SdkInt >= BuildVersionCodes.Lollipop)
            {
                Window.DecorView.SystemUiVisibility = 0;
                var statusBarHeightInfo = typeof(FormsAppCompatActivity).GetField("_statusBarHeight", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
                statusBarHeightInfo?.SetValue(this, 0);
                Window.SetStatusBarColor(new Android.Graphics.Color(0, 0, 0, 255)); // Change color as required.
            }

            showHashKey();

        }

        protected override void OnNewIntent(Intent intent)
        {
            base.OnNewIntent(intent);
            FirebasePushNotificationManager.ProcessIntent(this, intent);
        }

        protected override void OnActivityResult(int requestCode, Result resultCode, Intent intent)
        {
            base.OnActivityResult(requestCode, resultCode, intent);
            // https://github.com/jamesmontemagno/InAppBillingPlugin/blob/master/src/Plugin.InAppBilling.Android/InAppBillingImplementation.cs
            // const int PURCHASE_REQUEST_CODE = 1001;
            if (requestCode == 1001)
            {
                //TODO Suhas has commented code
                //InAppBillingImplementation.HandleActivityResult(requestCode, resultCode, intent);
                //InAppBillingImplementation.OnAndroidPurchasesUpdated.
            }
            else
            {
                FacebookClientManager.OnActivityResult(requestCode, resultCode, intent);
            }

        }

        public void showHashKey()
        {
            try
            {
                PackageInfo info = PackageManager.GetPackageInfo("com.GyroD.ZIMLApp", PackageInfoFlags.Signatures);
                foreach (Android.Content.PM.Signature signature in info.Signatures)
                {
                    Java.Security.MessageDigest md = Java.Security.MessageDigest.GetInstance("SHA");
                    md.Update(signature.ToByteArray());

                    var sign = Base64.EncodeToString(md.Digest(), Base64Flags.Default);
                    Log.Info("KeyHash:", sign);
                }
                Log.Info("KeyHash:", "****------------***");
            }
            catch (PackageManager.NameNotFoundException e)
            {
                e.PrintStackTrace();
            }
            catch (Java.Security.NoSuchAlgorithmException e)
            {
                e.PrintStackTrace();
            }
        }

    }
}
